﻿using System.IO;
using System.Reflection.Emit;
using System.Xml.Linq;

namespace RegistryAlten.SHARED
{
    public class RegistryCountCVDTO : RegistryDTO
    {
        public int? CVPresence { get; set; }
        public string Condition { get; set; }
       

        public RegistryCountCVDTO(RegistryDTO registryDTO, int cvPresence, string condition)
        {
            Id = registryDTO.Id;
            IdKeycloak = registryDTO.IdKeycloak;
            Email = registryDTO.Email;
            Name = registryDTO.Name;
            Surname = registryDTO.Surname;
            BirthDate = registryDTO.BirthDate;
            FiscalCode = registryDTO.FiscalCode;
            City = registryDTO.City;
            Province = registryDTO.Province;
            Street = registryDTO.Street;
            StreetNumber = registryDTO.StreetNumber;
            ZIPCode = registryDTO.ZIPCode;
            Gender = registryDTO.Gender;
            BusinessManager = registryDTO.BusinessManager;
            ConditionId = registryDTO.ConditionId;
            IsDeleted = registryDTO.IsDeleted;
            Technician = registryDTO.Technician;
            CVPresence = cvPresence;
            Condition = condition;
           
        }
    }
}
