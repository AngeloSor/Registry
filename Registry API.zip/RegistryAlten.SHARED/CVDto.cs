﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public record CVDTO
    (
        int Id,
        int RegistryId,
        IList<CVFileDTO>? CVFiles,
        IList<EducationAndTrainingExperienceDTO>? EducationAndTrainingExperiences,
        IList<WorkExperienceDTO>? WorkExperiences,
        IList<PersonalSkillDTO>? PersonalSkills,
        IList<PivotDigitalSkillDTO>? PivotDigitalSkills
    );
}
