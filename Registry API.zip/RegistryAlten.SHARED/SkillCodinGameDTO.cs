﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public record SkillCodinGameDTO
    (
        int Id,
        string Name,
        int Points,
        double score,
        int TotalPoints,
        int TechnologyId      
    );
    
}
