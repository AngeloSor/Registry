﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public record ReportDTO
    (
        int Id,
        int Duration,
        int Points,
        double Score,
        int TotalDuration,
        int TotalPoints,
        double ComparativeScore,
        int CodinGameId
    );
}
