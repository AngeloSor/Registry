﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public record CandidateDTO
    (
      string candidate_email,
      string? candidate_name,
      string? recruiter_email,
      string? tags,
      bool? send_invitation_email,
      bool? send_notification_email_on_bounce
    );
       
    
}
