﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public class SendFeedbackDTO
    {
        //public MimeMessageDTO MailMessage { get; set; }
        public List<string>? To { get; set; }
        public List<string>? Cc { get; set; }
        public string CandidateName { get; set; }
        public string CandidateSurmame { get; set; }
        public string TechName { get; set; }
        public string TechSurname { get; set; }

        public bool IsPassed { get; set; }
    }
}
