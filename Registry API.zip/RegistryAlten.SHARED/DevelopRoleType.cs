﻿namespace RegistryAlten.SHARED;

public enum DevelopRoleType
{
    Frontend,
    Backend
}