﻿namespace RegistryAlten.SHARED
{
    public class DigitalSkillGroupDTO
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public List<SkillDTO>? DigitalSkills { get; set; }
        public DigitalSkillGroupDTO(int id, string? name)
        {
            Id = id;
            Name = name;
        }
    }

    public class SkillDTO
    {
        public string? CurrentName { get; set; }

        public string Name { get; set; }
        public DevelopRoleType DevelopRole { get; set; }
        public SkillDTO(string name, DevelopRoleType developRole)
        {
            Name = name;
            DevelopRole = developRole;
        }
    }
}
