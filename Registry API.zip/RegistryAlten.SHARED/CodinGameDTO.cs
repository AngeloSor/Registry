﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public class CodinGameDTO
    {
        public int Id { get; set; }
        [property: JsonPropertyName("status")]
        public string Status { get; set; }
        [property: JsonPropertyName("url")]
        public string Url { get; set; }
        [property: JsonPropertyName("report")]
        [JsonConverter(typeof(InfoToStringConverter))]
        public string Report { get; set; }
        [property: JsonPropertyName("id_test")]
        public int IdTest { get; set; }
        [property: JsonPropertyName("campaign_id")]
        public int CampaignId { get; set; }
        [property: JsonPropertyName("candidate_name")]
        public string CandidateName { get; set; }
        [property: JsonPropertyName("candidate_email")]
        public string CandidateEmail { get; set; }
        [property: JsonPropertyName("tags")]
        [JsonConverter(typeof(InfoToStringConverter))]
        public string Tags { get; set; }
        [property: JsonPropertyName("send_time")]
        public long SendTime { get; set; }
        [property: JsonPropertyName("start_time")]
        public long StartTime { get; set; }
        [property: JsonPropertyName("end_time")]
        public long EndTime { get; set; }
        [property: JsonPropertyName("test_url")]
        public string TestUrl { get; set; }
        [property: JsonPropertyName("candidate_language")]
        public string CandidateLanguage { get; set; }
        public int RegistryId { get; set; }
    }

    public class InfoToStringConverter : JsonConverter<string>
    {
        public override string Read(
            ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            using (var jsonDoc = JsonDocument.ParseValue(ref reader))
            {
                return jsonDoc.RootElement.GetRawText();
            }
        }

        public override void Write(
            Utf8JsonWriter writer, string value, JsonSerializerOptions options)
        {
            throw new NotImplementedException();
        }
    }
}
