﻿namespace RegistryAlten.SHARED
{
    public record DefaultDigitalSkillDTO
    (
        string Name,
        string DigitalSkillGroupName,
        DevelopRoleType DevelopeRole
    );
}
