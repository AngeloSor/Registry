﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public class RegistryCGStatusDTO : RegistryCountCVDTO
    {
        public string IsCGExecuted { get; set; }
        public RegistryCGStatusDTO(RegistryDTO registryDTO, int cvPresence, string condition, string cgExecuted) : base(registryDTO, cvPresence, condition)
        {
            IsCGExecuted = cgExecuted;
        }
    }
}
