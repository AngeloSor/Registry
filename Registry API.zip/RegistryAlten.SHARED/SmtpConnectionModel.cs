﻿namespace RegistryAlten.API.Models
{
    public class SmtpConnectionModel
    {
        public string Hostname { get; set; }
        public int Port { get; set; }
    }
}
