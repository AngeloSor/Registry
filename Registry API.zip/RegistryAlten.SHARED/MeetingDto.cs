﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper.Configuration.Annotations;

namespace RegistryAlten.SHARED
{
    public class MeetingDTO
    {
        public int? Id { get; set; }
        public int? InterviewerId { get; set; }
        public string? NameInterviewer { get; set; }
        public string? NameUser { get; set; }
        public int? UserId { get; set; }
        public DateTime Date { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
