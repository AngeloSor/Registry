﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public record CVFileDTO
    (
        int Id,
        string Name,
        string? File,
        int CVRegistryId
    );
}
