﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public record WorkExperienceDTO
    (
        int Id,
        string? WorkingPosition,
        string? Agency,
        string? Location,
        DateTime? StartDate,
        DateTime? EndDate,
        int CVRegistryId
    );
}
