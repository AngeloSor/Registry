﻿namespace RegistryAlten.SHARED
{
    public class RegistryDTO
    {
        public int Id { get; set; }
        public string IdKeycloak { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public DateTime? BirthDate { get; set; }
        public string? FiscalCode { get; set; }
        public string? City { get; set; }
        public string? Province { get; set; }
        public string? Street { get; set; }
        public string? StreetNumber { get; set; }
        public int? ZIPCode { get; set; }
        public GenderType? Gender { get; set; }
        public string? BusinessManager { get; set; }
        public bool Technician { get; set; }
        public int ConditionId { get; set; }
        public bool IsDeleted { get; set; }

        public enum GenderType
        {
            Male,
            Female,
            NotSpecified
        }
    }
}
