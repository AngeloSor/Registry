﻿using System.Xml.Linq;

namespace RegistryAlten.SHARED;

//public enum Esito
//{
//    Negativo,
//    Positivo
//}

public enum Esperienza
{
    Stagista,
    Apprendista,
    Junior,
    Medior,
    Senior,
    Architect
}

public enum Ruolo
{
    Frontend,
    Backend,
    FullStack
}

public enum Valutazione
{
    A,
    B,
    C,
    D
}

public class FeedbackDTO
{
    public int Id { get; set; }
    public string? NameUser { get; set; }

    public PivotDigitalSkillDTO PivotDigitalSkillDTO;
    public MimeMessageDTO MailMessage { get; set; }
    public bool IsPassed { get; set; }
    public Esperienza Esperienza { get; set; }
    public Ruolo Ruolo { get; set; }

    public string Conclusioni { get; set; }

    public Valutazione DesignEvaluation { get; set; }
    public Valutazione CodeEvaluation { get; set; }
    public Valutazione ArchitectureEvaluation { get; set; }

    
    public int FeedbackUserId { get; set; }
    public int FeedbackInterviewerId { get; set; }

    public DateTime? DateFeedback { get; set; }

    //Input
    //public IList<DigitalSkillFeedback> DigitalSkillFeedback { get; set; }


    //public override string ToString()
    //{
    //    return string.Concat(new List<string>
    //    {
    //        $"Esito: {Esito}\n",
    //        $"Esperienza: {Esperienza}\n",
    //        $"Profilo: {Profilo}\n",
    //        $"Conclusioni: {Conclusioni}\n\n",

    //        $"Valutazione Design: {DesignEvaluation}\n",
    //        $"Valutazione Codice: {CodeEvaluation}\n",
    //        $"Valutazione Architettura: {ArchitectureEvaluation}\n\n",

    //        "-Backend:\n",
    //       EvaluationListBuilder(Profilo.Backend),

    //        "\nFrontend:\n",
    //        EvaluationListBuilder(Profilo.Frontend),

    //        $"\nNote: {Note}"
    //    });
    //}

//    private string EvaluationListBuilder(Ruolo developRole)
//    {
//        var digitalSkillFeedbackGroup = DigitalSkillFeedback.GroupBy(x => x.Category);
//        string list = "";
//        foreach (var digitalSkillCategoryList in digitalSkillFeedbackGroup)
//        {
//            var digitalSkillFeedbackCategory = digitalSkillCategoryList.Where(x => x.DevelopRole == developRole);
//            if (digitalSkillFeedbackCategory.Any())
//            {
//                list += $"\n --{digitalSkillFeedbackCategory.First().Category}:\n";
//                digitalSkillFeedbackCategory.ToList().ForEach(eval => list += $"---- {eval.Name} : {eval.Evaluation}\n");
//            }
//        }

//        return list;
//    }
//}

//public class DigitalSkillFeedback
//{
//    public string Name { get; set; }
//    public string Category { get; set; }
//    public Ruolo DevelopRole { get; set; }
//    public Valutazione Evaluation { get; set; }
}
