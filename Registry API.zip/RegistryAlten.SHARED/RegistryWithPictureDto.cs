﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public class RegistryWithPictureDTO : RegistryDTO
    {
        public PictureProfileDTO? PictureProfile { get; set; }
        public string Condition { get; set; }
        public RegistryWithPictureDTO() { }
        public RegistryWithPictureDTO(RegistryDTO registryDTO, PictureProfileDTO pictureProfile, string condition)
        {
            Id = registryDTO.Id;
            IdKeycloak = registryDTO.IdKeycloak;
            Email = registryDTO.Email;
            Name = registryDTO.Name;
            Surname = registryDTO.Surname;
            BirthDate = registryDTO.BirthDate;
            FiscalCode = registryDTO.FiscalCode;
            City = registryDTO.City;
            Province = registryDTO.Province;
            Street = registryDTO.Street;
            StreetNumber = registryDTO.StreetNumber;
            ZIPCode = registryDTO.ZIPCode;
            Gender = registryDTO.Gender;
            BusinessManager = registryDTO.BusinessManager;
            ConditionId = registryDTO.ConditionId;
            IsDeleted = registryDTO.IsDeleted;
            Technician = registryDTO.Technician;
            PictureProfile = pictureProfile;
            Condition = condition;
        }
    }
}
