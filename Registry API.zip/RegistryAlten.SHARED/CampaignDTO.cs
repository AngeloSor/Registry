﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.SHARED
{
    public class CampaignDTO
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string[]? Languages { get; set; }
        public bool Archived { get; set; }
        public bool Pinned { get; set; }
        public CampaignCat? Category { get; set; }
    }

     public enum CampaignCat
    {
        FE,
        BE,
        FS,
        ALTRO
    }
}
