﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace RegistryAlten.SHARED;

public class MimeMessageDTO
{
    public class MailAddress
    {
        [ValidateNever]
        public string? Name { get; set; }

        [Required]
        [EmailAddress]
        public string Address {get; set; }
    }

    [ValidateNever]
    public MailAddress? From { get; set; }
    [Required]
    public List<string> To { get; set; }
    public List<string>? Cc { get; set; }
    public string Subject { get; set; } = String.Empty;
    public string Body { get; set; } = String.Empty;
}
