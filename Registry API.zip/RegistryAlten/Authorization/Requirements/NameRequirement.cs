﻿using Microsoft.AspNetCore.Authorization;

namespace RegistryAlten.API.Authorization.Requirements;

public class NameRequirement : IAuthorizationRequirement
{
    public string Name { get; }

    public NameRequirement(string Name) => this.Name = Name;
}
