﻿using System.Security.Claims;
using RegistryAlten.API.Authorization.Requirements;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.API.Authorization.Handlers
{
    public class NameHandler : AuthorizationHandler<NameRequirement>
    {
        
        private readonly DbContext _context;
        public NameHandler(DbContext context)
        {
            _context = context;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, NameRequirement requirement)
        {
            var nameClaim = context.User.FindFirst(c => c.Type == "name");

            if (nameClaim is not null && 
                nameClaim.Value.Contains(requirement.Name) && 
                nameClaim.Issuer.StartsWith("https://recruitingkeycloak.azurewebsites.net/auth"))
                context.Succeed(requirement);

            return Task.CompletedTask;
        }
    }
}
