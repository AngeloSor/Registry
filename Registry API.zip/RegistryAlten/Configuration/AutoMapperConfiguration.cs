﻿using AutoMapper;
using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Routing.Constraints;
using MimeKit;

namespace RegistryAlten.API.Configuration
{
    public class AutoMapperConfiguration : Profile
    {
        public AutoMapperConfiguration()
        {
            CreateMap<Registry, RegistryDTO>().ReverseMap();
            CreateMap<Registry, RegistryCountCVDTO>().ReverseMap();
            CreateMap<Registry, RegistryWithPictureDTO>().ReverseMap();
            CreateMap<CVRegistry, CVRegistryDTO>().ReverseMap();
            CreateMap<CVRegistry, CVDTO>().ReverseMap();
            CreateMap<EducationAndTrainingExperience, EducationAndTrainingExperienceDTO>().ReverseMap();
            CreateMap<WorkExperience, WorkExperienceDTO>().ReverseMap();
            CreateMap<PersonalSkill, PersonalSkillDTO>().ReverseMap();
            CreateMap<DefaultDigitalSkill, DefaultDigitalSkillDTO>().ReverseMap();
            CreateMap<DigitalSkillGroup, DigitalSkillGroupDTO>().ReverseMap();
            CreateMap<CVFile, CVFileDTO>().ReverseMap();
            CreateMap<PivotDigitalSkill, PivotDigitalSkillDTO>().ReverseMap();
            CreateMap<Meeting, MeetingDTO>().
                ForMember(dest => dest.NameInterviewer,
                opt => opt.MapFrom(src => $"{src.Interviewer.Name}" + " " + $"{src.Interviewer.Surname}")
                ).ForMember(dest => dest.NameUser,
                opt => opt.MapFrom(src => $"{src.User.Name}" + " " + $"{src.User.Surname}")
                ).ReverseMap();
            CreateMap<PictureProfile, PictureProfileDTO>().ReverseMap();
            CreateMap<Registry, PictureProfileDTO>().ReverseMap();
            CreateMap<PivotDigitalSkill, PivotDigitalSkillDTO>().ReverseMap();
            CreateMap<Condition, ConditionDTO>().ReverseMap();
            CreateMap<CodinGameDTO, CodinGame>().ReverseMap();
            CreateMap<InvitationResponseDTO, CodinGame>().ForMember(
                dest => dest.IdTest,
                opt => opt.MapFrom(src => src.id)).ForMember(
                dest => dest.TestUrl,
                opt => opt.MapFrom(src => src.test_url)).
                ForMember(x => x.Id, opt => opt.Ignore()
                );
            CreateMap<Feedback, FeedbackDTO>().ForMember(dest => dest.NameUser,
                opt => opt.MapFrom(src => $"{src.FeedbackUser.Name}" + " " + $"{src.FeedbackUser.Surname}")).ReverseMap();
            CreateMap<CampaignDTO, Campaign>().ReverseMap();
            CreateMap<FeedbackDTO, SendFeedback>().ReverseMap();
        }
    }
}
