﻿using System.Security.Claims;
using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using RegistryAlten.DAL.Entities;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class CVRegistryController : ControllerBase
    {
        private readonly ICVRegistryRepository _cvRegistryRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IMapper _mapper;

        public CVRegistryController(ICVRegistryRepository repository, IHttpContextAccessor httpContextAccessor, IMapper mapper)
        {
            _cvRegistryRepository = repository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _mapper = mapper;
        }

        [HttpPost("CreateCVRegistry")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<CVRegistryDTO>> Create(CVRegistryDTO cvRegistryDTO) 
        {
            var cv = _mapper.Map<CVRegistry>(cvRegistryDTO);
            if (await _cvRegistryRepository.Exists(cv.Id)) return StatusCode(400,"BadRequestCVExists");
            if (!await _cvRegistryRepository.FindRegistry(cv.RegistryId)) return StatusCode(400, "BadRequestRegistryId");
            var cvRegistryDTOWithId = await _cvRegistryRepository.Create(cv);
            var cvRegistryWithId = _mapper.Map<CVRegistryDTO>(cvRegistryDTOWithId);
            return cvRegistryWithId;
        }
        [HttpGet("GetCVRegistryById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<CVRegistryDTO>> GetById(int id)
        {
            var cv = await _cvRegistryRepository.GetById(id);
            var cvDTO = _mapper.Map<CVRegistryDTO>(cv);
            if (roles.Any(x => x.Equals("user")) && !_cvRegistryRepository.IsUserAuthorized(keycloakId, cvDTO.RegistryId)) return StatusCode(403, "UserNotAuthorized");
            return cvDTO is null ? StatusCode(404, "CVRegistryNotFound") : cvDTO;
        }
        [HttpGet("GetCVRegistryByRegistryId")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<CVDTO>> GetByIdRegistry(int id)
        {
            var cv = await _cvRegistryRepository.GetByIdRegistry(id);
            var cvDTO = _mapper.Map<CVDTO>(cv);
            if (roles.Any(x => x.Equals("user")) && !_cvRegistryRepository.IsUserAuthorized(keycloakId, cvDTO.RegistryId)) return StatusCode(403, "UserNotAuthorized");

            return cvDTO is null ? StatusCode(404, "CVRegistryNotFound") : cvDTO;
        }
        [HttpGet("GetAllCVRegistries")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<CVRegistryDTO>>> GetAll()
        {
            var cv = await _cvRegistryRepository.GetAll();
            var cvDTO = cv.Select(c => _mapper.Map<CVRegistryDTO>(c)).ToList();
            return cvDTO is null ? StatusCode(404,"CVRegistryNotFound") : cvDTO;
        }
        [HttpPut("PutCVRegistry")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<CVRegistryDTO>> Put(CVRegistryDTO cvRegistryDTO)
        {
            var cvRegistyToSave = _mapper.Map<CVRegistry>(cvRegistryDTO);
            if (!await _cvRegistryRepository.Exists(cvRegistyToSave.Id)) return StatusCode(400,"BadRequestPutCV");
            if (!await _cvRegistryRepository.FindRegistry(cvRegistyToSave.RegistryId)) return StatusCode(400, "BadRequestRegistryId");
            var cvRegistryDTOWithId = await _cvRegistryRepository.Update(cvRegistyToSave);
            var cvRegistryWithId = _mapper.Map<CVRegistryDTO>(cvRegistryDTOWithId);
            return cvRegistryWithId;
        }
        [HttpDelete("DeleteCVRegistryById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<CVRegistryDTO>> Delete(int id)
        {
            var cv = await _cvRegistryRepository.Find(id);
            if (cv is null) return StatusCode(404, "CVRegistryNotFound");
            var response = await _cvRegistryRepository.Delete(cv);
            var cvDTO = _mapper.Map<CVRegistryDTO>(cv);
            return response ? cvDTO : StatusCode(500, "InternalServerErrorDelete");
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
