﻿using System.Security.Claims;
using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using RegistryAlten.DAL.Entities;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class MeetingController : ControllerBase
    {
        private readonly IMeetingRepository _meetingRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IRegistryRepository _registryRepository;
        private readonly IMapper _mapper;

        public MeetingController(IMeetingRepository meetingRepository, IHttpContextAccessor httpContextAccessor, IRegistryRepository registryRepository, IMapper mapper)
        {
            _meetingRepository = meetingRepository;
            _httpContextAccessor = httpContextAccessor;
            _registryRepository = registryRepository;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _mapper = mapper;
        }
        

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        [HttpPost("CreateMeeting")]
        public async Task<ActionResult<MeetingDTO>> CreateMeeting(MeetingDTO meetingDTO)
        {
            var userId = meetingDTO.UserId;
            var existMeet = await _meetingRepository.GetMeetingById(userId);
            if (existMeet != null) 
            {
                return StatusCode(400, "BadRequestMeetingExists");
            }
            var meeting = _mapper.Map<Meeting>(meetingDTO);
            if (meeting is null) return StatusCode(400, "BadRequestCreateMeeting");
            if (await _meetingRepository.ConflictDateCheck(meeting)) return StatusCode(400, "BadRequestConflictDateCheck");
            if (!await _meetingRepository.UserExists(meeting)) return StatusCode(400, "BadRequestUserExists");
            if (!await _meetingRepository.InterviewerExists(meeting)) return StatusCode(400, "BadRequestInterviewerExists");
            if (!_meetingRepository.DataTimeCheck(meetingDTO.Date)) return StatusCode(400, "BadRequestTimeNotValid");
            var meetingDTOWithId = await _meetingRepository.Create(meeting);
            var meetingWithId = _mapper.Map<MeetingDTO>(meetingDTOWithId);
            return meetingWithId;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        [HttpGet("GetMeetingById")]
        public async Task<ActionResult<MeetingDTO>> GetById(int id)
        {
            var meeting = await _meetingRepository.GetById(id);
            var meetingDTO = _mapper.Map<MeetingDTO>(meeting);
            return meetingDTO is null ? StatusCode(404,"NotFoundMeeting") : meetingDTO;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "user,administrator")]
        [HttpGet("GetMeetingsByInterviewer")]
        public async Task<ActionResult<List<MeetingDTO>>> GetByInterviewer()
        {
            var meetings = await _meetingRepository.GetByInterviewer(keycloakId);
            var meetingDTO = meetings.Select(m => _mapper.Map<MeetingDTO>(m)).ToList();
            return meetingDTO is null ? StatusCode(404, "NotFoundMeeting") : meetingDTO;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "user,administrator")]
        [HttpGet("GetMeetingsByUser")]
        public async Task<ActionResult<List<MeetingDTO>>> GetByInterviewedUser()
        {
            var meetings = await _meetingRepository.GetByInterviewedUser(keycloakId);
            var meetingDTO = meetings.Select(m => _mapper.Map<MeetingDTO>(m)).ToList();
            return meetingDTO is null ? StatusCode(404, "NotFoundMeeting") : meetingDTO;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        [HttpGet("GetAllMeetings")]
        public async Task<ActionResult<List<MeetingDTO>>> GetAll()
        {
         
            var meetings = await _meetingRepository.GetAll();
            var meetingDTO = meetings.Select(m => _mapper.Map<MeetingDTO>(m)).ToList();
            return meetingDTO is null ? StatusCode(404, "NotFoundMeeting") : meetingDTO;
        }
        
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "user,administrator")]
        [HttpPut("PutMeeting")]
        public async Task<ActionResult<MeetingDTO>> PutMeeting(MeetingDTO meetingDTO)
        {
            var meetings = _mapper.Map<Meeting>(meetingDTO);
            var meeting = await _meetingRepository.Find(meetings.Id);
            if (meetings is null) return StatusCode(400,"BadRequestPutMeeting");
            if (await _meetingRepository.ConflictDateCheck(meetings)) return StatusCode(400, "BadRequestConflictDateCheck");
            if (!await _meetingRepository.UserExists(meetings)) return StatusCode(400, "BadRequestUserExists");
            if (!await _meetingRepository.InterviewerExists(meetings)) return StatusCode(400, "BadRequestInterviewerExists");
            if (!_meetingRepository.DataTimeCheck(meetingDTO.Date)) return StatusCode(400, "BadRequestTimeNotValid");
            if (roles.Any(x => x.Equals("user")))
            {
                if (roles.Any(x => x.Equals("user")) && !_meetingRepository.IsUserAuthorized(keycloakId, (int)meetings.UserId)) return StatusCode(403, "UserNotAuthorized");

                if (meetings.Id != meetingDTO.Id ||
                    meetings.InterviewerId != meetingDTO.InterviewerId ||
                    meetings.UserId != meetingDTO.UserId)
                    return StatusCode(403, "ForbiddenUpdateMeeting");
            }
            var meetingDTOWithId = await _meetingRepository.Update(meetings);
            var meetingWithId = _mapper.Map<MeetingDTO>(meetingDTOWithId);
            return meetingWithId;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "user, administrator")]
        [HttpPut("ChangeStatusMeeting")]
        public async Task<ActionResult<MeetingDTO>> ChangeStatusMeeting(int id)
        {
            var meeting = await _meetingRepository.Find(id);
            if (meeting is null) return StatusCode(404, "NotFoundMeeting");
            var response = await _meetingRepository.ChangeStatus(meeting);
            var meetingDTO = _mapper.Map<MeetingDTO>(response);
            return response is not null ? meetingDTO : StatusCode(500, "InternalServerErrorDisable");
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "user,administrator")]
        [HttpDelete("DeleteMeetingById")]
        public async Task<ActionResult<MeetingDTO>> DeleteMeetingById(int id)
        {
            var meeting = await _meetingRepository.Find(id);
            //var meetingDTO = _mapper.Map<Meeting>(meeting);
            if (meeting is null) return StatusCode(400, "BadRequestDeleteMeeting");

            if (roles.Any(x => x.Equals("user")) && !_meetingRepository.IsUserAuthorized(keycloakId, (int)meeting.UserId)) return StatusCode(403, "UserNotAuthorized");

            var response = await _meetingRepository.Delete(meeting);

            var updateCandidate = await _registryRepository.SetCandidateToFirstInterview((int)meeting.UserId);
            var meeetingToSave = _mapper.Map<MeetingDTO>(meeting);
            return (response && updateCandidate) ? meeetingToSave : StatusCode(500,"InternalServerErrorDelete");
            return (response) ? meeetingToSave : StatusCode(500, "InternalServerErrorDelete");
        }
        private string GetClaim(string claimType) 
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }

        
    }
}
