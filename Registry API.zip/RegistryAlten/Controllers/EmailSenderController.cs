﻿using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using RegistryAlten.DAL.Entities;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmailSenderController : ControllerBase
    {
        private readonly IEmailSender _emailSender;
        private readonly IMapper _mapper;

        public EmailSenderController(IEmailSender emailSender, IMapper mapper)
        {
            _emailSender = emailSender;
            _mapper = mapper;
        }

        //[HttpPost("SendEmail")]
        //[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        //public async Task<ActionResult<int>> SendEmail(MimeMessageDTO mimeMessageDTO)
        //{
        //    mimeMessageDTO.From ??= new()
        //    {
        //        Name = "noreply - test",
        //        Address = "noreply@test.it"
        //    };

        //    var response = await _emailSender.SendEmailAsync(mimeMessageDTO);

        //    return response ? StatusCode(200, "OkSendEmail") : StatusCode(500, "InternalServerErrorSendEmail") ;
        //}

        //[HttpPost("Send/InterviewFeedback")]
        //[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        //public async Task<ActionResult<int>> SendTechInterviewFeedbackEmail(FeedbackDTO techInterviewFeedback)
        //{
        //    techInterviewFeedback.MailMessage.Subject = "Feedback Colloquio";
        //    techInterviewFeedback.MailMessage.Body = techInterviewFeedback.ToString();

        //    return await SendEmail(techInterviewFeedback.MailMessage);
        //}

        //[HttpPost("SendEmailFeedback")]
        //[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        //public async Task<ActionResult<SendFeedbackDTO>> SendMailFeedback([Required] SendFeedbackDTO candidateProfileDTO)
        //{
        //    var emailtoDTO = _mapper.Map<SendFeedback>(candidateProfileDTO);
        //    var response = await _emailSender.SendForm(emailtoDTO);
        //    var email = _mapper.Map<SendFeedbackDTO>(response);
        //    return email;
        //}

    }
}
