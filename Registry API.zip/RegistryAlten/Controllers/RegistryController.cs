﻿using System.Security.Claims;
using System.Text.RegularExpressions;
using RegistryAlten.DAL.Interface;
using RegistryAlten.DAL.Repository;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using RegistryAlten.DAL.Entities;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class RegistryController : ControllerBase
    {
        private readonly IRegistryRepository _registryRepository;
        private readonly IMeetingRepository _meetingRepository;
        private readonly ICodinGameRepository _codingameRepository;
        private readonly IPictureProfileRepository _pictureProfileRepository;
        private readonly ICVRegistryRepository _cvRegistryRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IMapper _mapper;

        public RegistryController(IRegistryRepository registryRepository, IMeetingRepository meetingRepository, ICodinGameRepository codingameRepository, IPictureProfileRepository pictureProfileRepository, ICVRegistryRepository cvRegistryRepository, IHttpContextAccessor httpContextAccessor, IMapper mapper)
        {
            _registryRepository = registryRepository;
            _meetingRepository = meetingRepository;
            _codingameRepository = codingameRepository;
            _pictureProfileRepository = pictureProfileRepository;
            _cvRegistryRepository = cvRegistryRepository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _mapper = mapper;
        }

        [HttpPost("CreateRegistry")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<RegistryDTO>> CreateRegistry(CreateRegistryDTO createRegistryDTO)
        {
            PictureProfile pictureProfile;
            if (createRegistryDTO.registryDTO.Technician) createRegistryDTO.registryDTO.ConditionId = 2;
            string formatCheck = FormatCheck(createRegistryDTO.registryDTO);
            if (formatCheck != "") return StatusCode(400, formatCheck);
            var registryDTOs = _mapper.Map<Registry>(createRegistryDTO.registryDTO);
            var registryCheck = await _registryRepository.RegistryExists(registryDTOs.Email);
            if (registryCheck != 0) return StatusCode(400, "BadRequestRegistryCheck");
            var registryDTOWithId = await _registryRepository.Create(registryDTOs);

            CVRegistry cvRegistryDTO = new CVRegistry { Id = 0, RegistryId = registryDTOWithId.Id };

            await _cvRegistryRepository.Create(cvRegistryDTO);
            pictureProfile = new PictureProfile { Id = 0, Picture = createRegistryDTO.pictureProfileDTO.Picture, RegistryId = registryDTOWithId.Id };


            if (createRegistryDTO.pictureProfileDTO != null) await _pictureProfileRepository.Create(pictureProfile);
            var registryWithId = _mapper.Map<RegistryDTO>(registryDTOWithId);

            return registryWithId;
            //return StatusCode(400, "BadRequestRegistryCheck");
        }

        [HttpGet("GetRegistryByEmail")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<RegistryDTO>> GetRegistryByEmail(string email)
        {
            var registry = await _registryRepository.GetByEmail(email);
            if (registry is null) return StatusCode(404, "RegistryNotFound");
            if (roles.Any(x => x.Equals("user")) && !_registryRepository.IsUserAuthorized(keycloakId, registry.Id)) return StatusCode(403, "UserNotAuthorized");
            var registryToSave = _mapper.Map<RegistryDTO>(registry);
            return registryToSave;
        }
        [HttpGet("GetRegistryById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<RegistryWithPictureDTO>> GetRegistryById(int id)
        {
            var registry = await _registryRepository.GetByIdWithPicture(id);
            
            if (roles.Any(x => x.Equals("user")) && !_registryRepository.IsUserAuthorized(keycloakId, registry.Id)) return StatusCode(403, "UserNotAuthorized");
            var registryDTO = _mapper.Map<RegistryWithPictureDTO>(registry);
            return registryDTO is null ? StatusCode(404, "RegistryNotFound") : registryDTO;
        }

        [HttpGet("GetAllRegistriesPage")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<RegistryCGStatusDTO>>> GetAll(int pageSize, int pageNumber, bool isDeleted = false)
        {
            var registry = await _registryRepository.GetAll(pageSize, pageNumber, isDeleted);

            var registryDTO = registry.Select(user => new RegistryCGStatusDTO(_mapper.Map<RegistryDTO>(user), user.CVRegistry?.CVFiles?.Count ?? 0, user.Condition?.Name, user.CodinGame?.Status)).ToList();
            return registryDTO is null ? StatusCode(404, "RegistryNotFound") : registryDTO;
            //return registryDTO;
        }

        [HttpGet("GetAllRegistries")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<RegistryCGStatusDTO>>> GetAllRegistries(bool isDeleted = false)
        {
            var registry = await _registryRepository.GetAllCG(isDeleted);

            var registryDTO = registry.Select(user => new RegistryCGStatusDTO( _mapper.Map<RegistryDTO>(user), user.CVRegistry?.CVFiles?.Count ?? 0, user.Condition?.Name, user.CodinGame?.Status)).ToList();
            return registryDTO is null ? StatusCode(404, "RegistryNotFound") : registryDTO;
            //return registryDTO;
        }

        [HttpGet("GetAllInterviewUsers")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<RegistryCountCVDTO>>> GetAllInterviewUsers()
        {
            var user = await _registryRepository.GetAllInterview();
            var userInterview = user.Select(user => new RegistryCountCVDTO((_mapper.Map<RegistryDTO>(user)), user.CVRegistry?.CVFiles?.Count ?? 0, user.Condition?.Name)).ToList();
            if (userInterview is null) return StatusCode(404, "RegistryNotFound");
            return userInterview;
        }

        [HttpGet("GetAllTechnicianUsers")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<RegistryCountCVDTO>>> GetAllTechnicianUsers()
        {
            var user = await _registryRepository.GetAllTechnician();
            var userInterview = user.Select(user => new RegistryCountCVDTO(_mapper.Map<RegistryDTO>(user), user.CVRegistry?.CVFiles?.Count ?? 0, user.Condition?.Name)).ToList();
            if (userInterview is null) return StatusCode(404, "RegistryNotFound");
            return userInterview;
        }

        [HttpGet("GetAllTechnicianUsersPage")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<RegistryCountCVDTO>>> GetAllTechnicianUsersPage(int pageSize, int pageNumber)
        {
            var user = await _registryRepository.GetAllTechnicianPage(pageSize, pageNumber);
            var userInterview = user.Select(user => new RegistryCountCVDTO(_mapper.Map<RegistryDTO>(user), user.CVRegistry?.CVFiles?.Count ?? 0, user.Condition?.Name)).ToList();
            if (userInterview is null) return StatusCode(404, "RegistryNotFound");
            return userInterview;
        }

        [HttpPut("PutRegistry")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<RegistryDTO>> PutUser(RegistryDTO registryDTO)
        {
            if (registryDTO.Technician) registryDTO.ConditionId = 2;
            string formatCheck = FormatCheck(registryDTO);
            if (formatCheck != "") return StatusCode(400, formatCheck);
            var registry = _mapper.Map<Registry>(registryDTO);
            var id = await _registryRepository.RegistryExists(registry.Email);
            if (id == 0) return StatusCode(404, "RegistryNotFound");
            else
            {
                registry.Id = id;
                if (await _registryRepository.IsTechnician(id))
                {
                    return StatusCode(400, "Can't Modify Technician Condition");
                }
                else
                {
                    var registryDTOWithId = await _registryRepository.Update(registry);
                    var registryWithId = _mapper.Map<RegistryDTO>(registryDTOWithId);
                    return registryWithId;
                }
            }
        }

        [HttpPut("RehabilitateRegistryById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<RegistryDTO>> RehabilitateRegistry(int id)
        {
            var registry = await _registryRepository.Find(id);
            if (registry is null) return StatusCode(404, "RegistryNotFound");
            var registryDTO = _mapper.Map<Registry>(registry);
            var response = await _registryRepository.Rehabilitate(registryDTO);
            var registryToSave = _mapper.Map<RegistryDTO>(response);
            return response ? registryToSave : StatusCode(500, "InternalServerErrorDelete");
        }

        [HttpDelete("DeleteRegistryById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<RegistryDTO>> DeleteRegistry(int id)
        {
            var registry = await _registryRepository.Find(id);
            if (registry is null) return StatusCode(404, "RegistryNotFound");
            //var registryDTO = _mapper.Map<Registry>(registry);
            var response = await _registryRepository.Delete(registry);
            var registryToSave = _mapper.Map<RegistryDTO>(registry);
            return response ? registryToSave : StatusCode(500, "InternalServerErrorDelete");
        }

        [HttpDelete("DeletePermanentRegistryById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<RegistryDTO>> DeletePermanentRegistry(int id)
        {
            var registry = await _registryRepository.Find(id);
            if (registry is null) return StatusCode(404, "RegistryNotFound");

            if (registry.Technician == false)
            {
                var meetingsToDelete = await _meetingRepository.GetByInterviewedUser(registry.IdKeycloak);
                if (meetingsToDelete != null) await _meetingRepository.DeleteAll(meetingsToDelete);
            }
            else
            {
                var meetingsToDelete = await _meetingRepository.GetByInterviewer(registry.IdKeycloak);
                if (meetingsToDelete != null) await _meetingRepository.DeleteAll(meetingsToDelete);
            }

            var codingamesToDelete = await _codingameRepository.GetUserCodinGames(registry.Id);
            if (codingamesToDelete != null) await _codingameRepository.DeleteAll(codingamesToDelete);

            var response = await _registryRepository.DeletePermanent(registry);
            var registryToSave = _mapper.Map<RegistryDTO>(registry);
            return response ? registryToSave : StatusCode(500, "InternalServerErrorDelete");
            //return StatusCode(500, "InternalServerErrorDelete");
        }

        private string FormatCheck(RegistryDTO registryDTO)
        {
            string check = "";
            if (registryDTO.Email == "" || registryDTO.Name == "" || registryDTO.Surname == "") return check = "BadRequestFormatCheckFields";
            if (!_registryRepository.ConditionExists(registryDTO.ConditionId).Result) return check = "BadRequestFormatCheckCondition";
            string strRegex = @"^([A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST]{1}[0-9LMNPQRSTUV]{2}[A-Z]{1}[0-9LMNPQRSTUV]{3}[A-Z]{1})$|([0-9]{11})$";
            Regex regex = new Regex(strRegex);
            if (!regex.IsMatch(registryDTO.FiscalCode)) return "BadRequestFormatFiscalCode";
            string bRegex = @"^[0-9]{1,4}$|^[0-9]{1,4}\/[A-Za-z]$";
            Regex buildingRegex = new Regex(bRegex);
            if (!buildingRegex.IsMatch(registryDTO.StreetNumber)) return check = "BadRequestFormatStreetNumber";
            return check;
        }
        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
