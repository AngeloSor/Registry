﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.DAL.Repository;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Utilities.Zlib;
using System.Data;
using System.IO;
using System.Net.Http.Headers;
using System.Security.Claims;
using static System.Net.Mime.MediaTypeNames;
using System.Text;
using Newtonsoft.Json;
using System.Linq.Expressions;
using Microsoft.Win32;
using AutoMapper;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class CodinGameController : ControllerBase
    {
        private readonly ICodinGameRepository _codinGameRepository;
        private readonly HttpClient codinGameClient = new HttpClient();
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IMapper _mapper;

        public CodinGameController(ICodinGameRepository codinGameRepository, IHttpContextAccessor httpContextAccessor, IMapper mapper)
        {
            _codinGameRepository = codinGameRepository;
            codinGameClient.DefaultRequestHeaders.Accept.Clear();
            codinGameClient.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json")
                );
            codinGameClient.DefaultRequestHeaders.Add("API-Key", "66919bd5-47ee-4125-9b80-ba8ed36f71dc");
            codinGameClient.DefaultRequestHeaders.Add("Accept",
              "text/html, application/xhtml+xml, application/xml;q=0.9, image/webp, */*;q=0.8");
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _mapper = mapper;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        [HttpGet("GetAllCampaign")]
        public async Task<ActionResult<String>> GetAllCampaign()
        {
            var campaigns = await _codinGameRepository.GetAllCampaigns(codinGameClient);
            StreamReader reader = new StreamReader(campaigns);
            string text = reader.ReadToEnd();
            if (text.Length == 0) return StatusCode(500, "NotFoundTestSessionStatus");
            return text;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, user")]
        [HttpGet("GetTestSessionStatus")]
        public async Task<ActionResult<string>> GetTestSessionStatus(int registryId)
        {
            if (roles.Any(x => x.Equals("user")) && !_codinGameRepository.IsUserAuthorized(keycloakId, registryId)) return StatusCode(403, "UserNotAuthorized");
            var campaigns = await _codinGameRepository.GetTestSessionStatus(codinGameClient, registryId);
            if (campaigns == "NotFoundRegistryId") return StatusCode(404, "NotFoundRegistryId");
            if (campaigns == "NotFoundTestSessionStatus") return StatusCode(404, "NotFoundTestSessionStatus");
            return campaigns;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator, user")]
        [HttpGet("GetTestReport")]
        public async Task<ActionResult<string>> GetTestReport(int registryId)
        {
            if (roles.Any(x => x.Equals("user")) && !_codinGameRepository.IsUserAuthorized(keycloakId, registryId)) return StatusCode(403, "UserNotAuthorized");
            var campaigns = await _codinGameRepository.GetTestReport(codinGameClient, registryId);
            if (campaigns == "NotFoundRegistryId") return StatusCode(404, "NotFoundRegistryId");
            if (campaigns == "NotFoundTestSessionStatus") return StatusCode(404, "NotFoundTestSessionStatus");
            return  "\"" + campaigns + "\"";
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        [HttpPost("SendAnInvitation")]
        public async Task<ActionResult<string>> SendAnInvitation(CandidateDTO candidate, int idCampaign)
        {
            var campaigns = await _codinGameRepository.SendInvitation(codinGameClient, candidate, idCampaign);
            if (campaigns == "testExist") return StatusCode(400, "BadRequestTestAlreadyExist");
            if (campaigns == "UserNotExist") return StatusCode(400, "BadRequestUserNotExist");
            if (campaigns == "TechnicianNotExist") return StatusCode(400, "BadRequestTechnicianNotExist");
            if (campaigns == "BadRequest") return StatusCode(500, "InternalErrorCodinGame");

            return campaigns;
        }

        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        [HttpGet("GetAllCampaignsWithTags")]
        public async Task<ActionResult<List<CampaignDTO>>> GetAllCampaignsWithCampaign(string category)
        {
            if (category.ToUpper() != "BE" && category.ToUpper() != "FE" && category.ToUpper() != "FS" && category.ToUpper() != "ALTRO")
            {

                return StatusCode(400, "TagNotExists");

            }

            List<CampaignDTO> campaigns = await _codinGameRepository.GetCampaigns(codinGameClient, category);

            return campaigns;
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
