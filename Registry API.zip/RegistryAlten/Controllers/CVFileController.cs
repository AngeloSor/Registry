﻿using System.Security.Claims;
using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class CVFileController : ControllerBase
    {
        private readonly ISectionCVRegistryRepository<CVFileDTO> _sectionCVRegistryRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;

        public CVFileController(ISectionCVRegistryRepository<CVFileDTO> sectionCVRegistryRepository, IHttpContextAccessor httpContextAccessor)
        {
            _sectionCVRegistryRepository = sectionCVRegistryRepository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
        }

        [HttpPost("CreateCVFile")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user ")]
        public async Task<ActionResult<CVFileDTO>> CreateCVFile(CVFileDTO cvFileDTO)
        {
            if (!await _sectionCVRegistryRepository.FindCVRegistry(cvFileDTO.CVRegistryId)) return StatusCode(400, "BadRequestFindCVRegistry");
            var cvFileDTOWithId = await _sectionCVRegistryRepository.Create(cvFileDTO);
            return cvFileDTOWithId;
        }
        [HttpGet("GetCVFileById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<CVFileDTO>> GetById(int id)
        {
            var cvFile = await _sectionCVRegistryRepository.GetById(id);

            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, cvFile.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");

            return cvFile is null ? StatusCode(404, "CVFileNotFound") : cvFile;
        }

        [HttpGet("GetAllCVFiles")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<CVFileDTO>>> GetAllCVFile()
        {
            var user = await _sectionCVRegistryRepository.GetAll();
            if (user is null) return StatusCode(404, "CVFileNotFound");
            return user;
        }

        [HttpPut("PutCVFile")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<CVFileDTO>> PutCVFile(CVFileDTO cvFileDTO)
        {
            if (!(await _sectionCVRegistryRepository.Exists(cvFileDTO.Id))) return StatusCode(400, "BadRequestPutCVFile");
            if (!await _sectionCVRegistryRepository.FindCVRegistry(cvFileDTO.CVRegistryId)) return StatusCode(400, "BadRequestFindCVRegistry");
            var cvFileDTOWithId = await _sectionCVRegistryRepository.Update(cvFileDTO);
            return cvFileDTOWithId;
        }

        [HttpDelete("DeleteCVFileById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<CVFileDTO>> DeleteCVFile(int id)
        {
            var cvFile = await _sectionCVRegistryRepository.Find(id);
            if (cvFile is null) return StatusCode(400, "BadRequestDeleteCVFile");
            var response = await _sectionCVRegistryRepository.Delete(cvFile);
            if (!response) return StatusCode(500, "InternalServerErrorDelete");
            return cvFile;
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
