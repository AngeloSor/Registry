﻿using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class PersonalSkillController : ControllerBase
    {
        private readonly IPersonalSkillRepository _personalSkillRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;

        public PersonalSkillController(IPersonalSkillRepository personalSkillRepository, IHttpContextAccessor httpContextAccessor)
        {
            _personalSkillRepository = personalSkillRepository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
        }
        [HttpPost("CreatePersonalSkills")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<PersonalSkillDTO[]>> CreateSkills(PersonalSkillDTO[] personalSkillsDTO)
        {
            foreach (PersonalSkillDTO personalSkillDTO in personalSkillsDTO)
            {
                if (roles.Any(x => x.Equals("user")) && !_personalSkillRepository.IsUserAuthorized(keycloakId, personalSkillDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
                if (!await _personalSkillRepository.FindCVRegistry(personalSkillDTO.CVRegistryId)) return StatusCode(400,"BadRequestFindCVRegistry");
                var formatCheckResponse = FormatCheck(personalSkillDTO);
                if (formatCheckResponse != "") return StatusCode(400,formatCheckResponse);
            }

            var personalSkillsDTOWithId = await _personalSkillRepository.CreateSkills(personalSkillsDTO);
            return personalSkillsDTO;
        }
        [HttpGet("GetPersonalSkillById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<PersonalSkillDTO>> GetById(int id)
        {
            var personalSkill = await _personalSkillRepository.GetById(id);
            if (roles.Any(x => x.Equals("user")) && !_personalSkillRepository.IsUserAuthorized(keycloakId, personalSkill.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");

            return personalSkill is null ? StatusCode(404,"NotFoundSection") : personalSkill;
        }
        [HttpGet("GetAllPersonalSkills")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<PersonalSkillDTO>>> GetAll()
        {
            var personalSkill = await _personalSkillRepository.GetAll();
            return personalSkill is null ? StatusCode(404, "NotFoundSection") : personalSkill;
        }
        [HttpPut("PutPersonalSkill")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<PersonalSkillDTO>> Put(PersonalSkillDTO personalSkillDTO)
        {
            if (roles.Any(x => x.Equals("user")) && !_personalSkillRepository.IsUserAuthorized(keycloakId, personalSkillDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (!(await _personalSkillRepository.Exists(personalSkillDTO.Id))) return StatusCode(400, "BadRequestPutSection");
            if (!await _personalSkillRepository.FindCVRegistry(personalSkillDTO.CVRegistryId)) return StatusCode(400,"BadRequestFindCVRegistry");
            var formatCheckResponse = FormatCheck(personalSkillDTO);
            if (formatCheckResponse != "") return StatusCode(400,formatCheckResponse);
            var personalSkillDTOWithId = await _personalSkillRepository.Update(personalSkillDTO);
            return personalSkillDTOWithId;
        }

        [HttpDelete("DeletePersonalSkillById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<PersonalSkillDTO>> Delete(int id)
        {
            var personalSkill = await _personalSkillRepository.Find(id);
            if (personalSkill is null) return StatusCode(400,"BadRequestDeleteSection");
            if (roles.Any(x => x.Equals("user")) && !_personalSkillRepository.IsUserAuthorized(keycloakId, personalSkill.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            var response = await _personalSkillRepository.Delete(personalSkill);

            return response ? personalSkill : StatusCode(500,"InternalServerErrorDelete");
        }
        private string FormatCheck(PersonalSkillDTO personalSkillDTO)
        {
            string check = "";
            if (personalSkillDTO.Property != "MotherTongue" && personalSkillDTO.Property != "OtherLanguage" && personalSkillDTO.Property != "OrganizationalAndManagementSkill" && personalSkillDTO.Property != "ProfessionalSkill" && personalSkillDTO.Property != "SoftSkill" && personalSkillDTO.Property != "DriveLicense") return check = "BadRequestFormatCheckProperty";
            return check;
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
