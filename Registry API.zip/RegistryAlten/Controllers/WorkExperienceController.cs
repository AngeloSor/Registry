﻿using System.Security.Claims;
using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class WorkExperienceController : ControllerBase
    {
        private readonly ISectionCVRegistryRepository<WorkExperienceDTO> _sectionCVRegistryRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;

        public WorkExperienceController(ISectionCVRegistryRepository<WorkExperienceDTO> sectionCVRegistryRepository, IHttpContextAccessor httpContextAccessor)
        {
            _sectionCVRegistryRepository = sectionCVRegistryRepository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
        }
        [HttpPost("CreateWorkExperience")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<WorkExperienceDTO>> Create(WorkExperienceDTO workExperienceDTO)
        {
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, workExperienceDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (!await _sectionCVRegistryRepository.FindCVRegistry(workExperienceDTO.CVRegistryId)) return StatusCode(400,"BadRequestFindCVRegistry");
            var workExperienceDTOWithId = await _sectionCVRegistryRepository.Create(workExperienceDTO);
            return workExperienceDTOWithId;
        }
        [HttpGet("GetWorkExperienceById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<WorkExperienceDTO>> GetById(int id)
        {
            var workExperience = await _sectionCVRegistryRepository.GetById(id);
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, workExperience.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            return workExperience is null ? StatusCode(404,"NotFoundSection") : workExperience;
        }
        [HttpGet("GetAllWorkExperiences")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<WorkExperienceDTO>>> GetAll()
        {
            var workExperience = await _sectionCVRegistryRepository.GetAll();
            return workExperience;
        }
        [HttpPut("PutWorkExperience")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<WorkExperienceDTO>> Put(WorkExperienceDTO workExperienceDTO)
        {
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, workExperienceDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (!await _sectionCVRegistryRepository.Exists(workExperienceDTO.Id)) return StatusCode(400,"BadRequestPutSection");
            if (!await _sectionCVRegistryRepository.FindCVRegistry(workExperienceDTO.CVRegistryId)) return StatusCode(400,"BadRequestFindCVRegistry");
            var workExperienceDTOWithId = await _sectionCVRegistryRepository.Update(workExperienceDTO);
            return workExperienceDTOWithId;
        }
        [HttpDelete("DeleteWorkExperienceById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<WorkExperienceDTO>> Delete(int id)
        {
            var workExperience = await _sectionCVRegistryRepository.Find(id);
            if (workExperience is null) return StatusCode(400,"BadRequestDeleteSection");
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, workExperience.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            var response = await _sectionCVRegistryRepository.Delete(workExperience);
            if (!response) return StatusCode(500, "InternalServerErrorDelete");
            return workExperience;
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
