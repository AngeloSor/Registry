﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using RegistryAlten.API.Models;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.DAL.Repository;
using RegistryAlten.SHARED;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackController : ControllerBase
    {
        private readonly IFeedbackRepository _feedbackRepository;
        private readonly IRegistryRepository _registryRepository;
        private readonly IEmailSender _emailrepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IMapper _mapper;
        public FeedbackController(IFeedbackRepository feedbackRepository, IHttpContextAccessor httpContextAccessor, IRegistryRepository registryRepository, IEmailSender emailSender, IMapper mapper)
        {
            _httpContextAccessor = httpContextAccessor;
            _feedbackRepository = feedbackRepository;
            _registryRepository = registryRepository;
            _emailrepository = emailSender;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _mapper = mapper;
           

        }

        [HttpPost("CreateFeedback")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<FeedbackDTO>> CreateFeedback(FeedbackDTO interviewFeedbackDTO)
        {
            var formatCheck = FormatCheck(interviewFeedbackDTO);
            if (formatCheck != "") return StatusCode(400, formatCheck);
            var feedToSendDTO = _mapper.Map<Feedback>(interviewFeedbackDTO);
            var feedToSend = await _feedbackRepository.Create(feedToSendDTO);
            var feedTo = _mapper.Map<FeedbackDTO>(feedToSend);
            var registryUser = await _registryRepository.Find(interviewFeedbackDTO.FeedbackUserId);
            var registryTech = await _registryRepository.Find(interviewFeedbackDTO.FeedbackInterviewerId);
            var sendFeed = new SendFeedbackDTO
            {
                Cc = interviewFeedbackDTO.MailMessage.Cc,
                To = interviewFeedbackDTO.MailMessage.To,
                CandidateName = registryUser.Name,
                CandidateSurmame = registryUser.Surname,
                TechName = registryTech.Name,
                TechSurname = registryTech.Surname,
                IsPassed = interviewFeedbackDTO.IsPassed,
            };
            
            var sendFeedback = _emailrepository.SendMail(sendFeed);
            return feedTo;
        }

        [HttpGet("GetById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<FeedbackDTO>> GetByFeedbackId(int id)
        {
            var feedbacks = await _feedbackRepository.GetById(id);
            var feedbackDTO = _mapper.Map<FeedbackDTO>(feedbacks);
            return feedbackDTO is null ? StatusCode(404, "NotFoundFeedback") : feedbackDTO;
        }



        [HttpGet("GetByTechnicianId")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<List<FeedbackDTO>>> GetByTechnicianId(int id)
        {
            var feedbacks = await _feedbackRepository.GetByTechnicianId(id);
            var feedbacksDTO = feedbacks.Select(feed => _mapper.Map<FeedbackDTO>(feed)).ToList();
            return feedbacksDTO is null ? StatusCode(404, "NotFoundInteriew") : feedbacksDTO;
        }

        [HttpGet("GetByInterviewId")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<List<FeedbackDTO>>> GetByInterviewId(int id)
        {
            var feedbacks = await _feedbackRepository.GetByInterviewId(id);
            var feedbacksDTO = feedbacks.Select(feed => _mapper.Map<FeedbackDTO>(feed)).ToList();
            return feedbacksDTO is null ? StatusCode(404, "NotFoundInteriew") : feedbacksDTO;
        }



        [HttpGet("GetAllInterview")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<List<FeedbackDTO>>> GetAll()
        {
            var feedbacks = await _feedbackRepository.GetAll();
            var feedbacksDTO = feedbacks.Select(feed => _mapper.Map<FeedbackDTO>(feed)).ToList();
            return feedbacksDTO is null ? StatusCode(404, "NotFoundInteriew") : feedbacksDTO;
        }

        [HttpPut("PutFeedback")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<FeedbackDTO>> PutFeedback(FeedbackDTO feedbackDTO) 
        { 
            var feedbackToSave =_mapper.Map<Feedback>(feedbackDTO);
            var id = await _feedbackRepository.FeedbackExists(feedbackDTO.Id);
            if (!id) return StatusCode(404, "FeedbackNotFound");
            else
            {
                var feedbackWithId = await _feedbackRepository.Update(feedbackToSave);
                var feedbackDTOWithId = _mapper.Map<FeedbackDTO>(feedbackWithId);
                return feedbackDTOWithId;
 
            }
        }

        [HttpDelete("DeleteFeedback")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<FeedbackDTO>> DeleteFeedback(int id)
        {
            var feedback = await _feedbackRepository.Find(id);
            if (feedback is null) return StatusCode(404, "ConditionNotFound");
            var response = await _feedbackRepository.Delete(feedback);
            var feedbackDTO = _mapper.Map<FeedbackDTO>(feedback);
            return response ? feedbackDTO : StatusCode(500, "InternalServerErrorDelete");
        }

        private string FormatCheck(FeedbackDTO interviewFeedbackDTO)
        {
            string check = "";
            if (interviewFeedbackDTO.FeedbackInterviewerId == 0 || interviewFeedbackDTO.FeedbackUserId == 0) return check = "BadRequestFormatCheckFields";

            return check;
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
