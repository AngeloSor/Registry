﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.DAL.Repository;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using RegistryAlten.API;
using System.Data;
using System.Security.Claims;
using Org.BouncyCastle.Bcpg.OpenPgp;
using AutoMapper;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    //[Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
    [ApiController]
    public class ConditionController : ControllerBase
    {
        private readonly IConditionRepository _conditionRepository;
        private readonly IMapper _mapper;

        public ConditionController(IConditionRepository conditionRepository, IMapper mapper)
        {
            _conditionRepository = conditionRepository;
            _mapper = mapper;
        }

        [HttpPost("CreateCondition")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<ConditionDTO>> CreateCondition(ConditionDTO conditionDTO)
        {
            var conditionToSave = _mapper.Map<Condition>(conditionDTO);
            var conditionWithId = await _conditionRepository.Create(conditionToSave);
            var conditionDTOWithId = _mapper.Map<ConditionDTO>(conditionWithId);
            return conditionDTOWithId;
        }

        [HttpPut("PutCondition")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<ConditionDTO>> PutCondition(ConditionDTO conditionDTO)
        {
            var conditionToSave = _mapper.Map<Condition>(conditionDTO);
            var id = await _conditionRepository.ConditionExists(conditionToSave.Id);
            if (!id) return StatusCode(404, "ConditionNotFound");
            else
            {
                var conditionWithId = await _conditionRepository.Update(conditionToSave);
                var conditionDTOWithId = _mapper.Map<ConditionDTO>(conditionWithId);
                return conditionDTOWithId;
            }
        }

        [HttpDelete("DeleteCondition")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<ConditionDTO>> DeleteCondition(int id)
        {
            
            var condition = await _conditionRepository.Find(id);
            if (condition is null) return StatusCode(404, "ConditionNotFound");
            var response = await _conditionRepository.Delete(condition);
            var conditionDTO = _mapper.Map<ConditionDTO>(condition);
            return response ? conditionDTO : StatusCode(500, "InternalServerErrorDelete");
        }
        [HttpGet("GetAllCondition")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "user,administrator")]
        public async Task<ActionResult<List<ConditionDTO>>> GetAllCondition()
        {
            var condition = await _conditionRepository.GetAll();
            if (condition is null) return StatusCode(404, "ConditionNotFound");
            var conditionDTO = condition.Select(cond => _mapper.Map<ConditionDTO>(cond)).ToList();
            return conditionDTO;
        }
    }
}
