﻿using RegistryAlten.BLL;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class StatusDictionaryController : ControllerBase
    {
        [HttpGet("GetStatusDictionary")]
        public Dictionary<string, string> GetDictionary(string language)
        {
            if (language == "it")
            {
                return StatusDictionaryResponse.StatusDictionary;
            }
            else 
            {
                return StatusDictionaryResponse.StatusDictionaryEN;
            }
        }
    }
}
