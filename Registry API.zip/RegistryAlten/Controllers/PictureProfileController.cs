﻿using System.Security.Claims;
using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using RegistryAlten.DAL.Entities;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class PictureProfileController : ControllerBase
    {
        private readonly IPictureProfileRepository _pictureProfileRepository;
        private readonly string keycloakId;
        private readonly List<string> roles;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IMapper _mapper;

        public PictureProfileController(IPictureProfileRepository pictureProfileRepository, IHttpContextAccessor httpContextAccessor, IMapper mapper)
        {
            _pictureProfileRepository = pictureProfileRepository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
            _mapper = mapper;
        }

        [HttpPost("CreatePictureProfile")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<PictureProfileDTO>> CreatePictureProfile(PictureProfileDTO pictureProfileDTO)
        {
            var pictProfileDTO = _mapper.Map<PictureProfile>(pictureProfileDTO);
            if (!await _pictureProfileRepository.FindRegistry(pictProfileDTO.RegistryId)) return StatusCode(400, "BadRequestRegistryId");
            var createPictureProfileDTO = await _pictureProfileRepository.Create(pictProfileDTO);
            var picturProfileToSave = _mapper.Map<PictureProfileDTO>(createPictureProfileDTO);
            return picturProfileToSave;
        }
        [HttpGet("GetPictureProfileById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<PictureProfileDTO>> GetById(int id)
        {
            var picture = await _pictureProfileRepository.GetById(id);
            //var pictureDTO = _mapper.Map<PictureProfile>(picture);
            if (roles.Any(x => x.Equals("user")) && !_pictureProfileRepository.IsUserAuthorized(keycloakId, picture.Id)) return StatusCode(403, "UserNotAuthorized");
            var pictureToSave = _mapper.Map<PictureProfileDTO>(picture);
            if (pictureToSave is null) return StatusCode(404, "NotFoundProfilePicture");
            return pictureToSave;
        }

        [HttpGet("GetAllPicturesProfile")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<PictureProfileDTO>>> GetAllPictureProfile()
        {
            var user = await _pictureProfileRepository.GetAll();
            var userDTO = user.Select(u => _mapper.Map<PictureProfileDTO>(u)).ToList();
            if (userDTO is null) return StatusCode(404, "NotFoundProfilePicture");
            return userDTO;
        }

        [HttpPut("PutPictureProfile")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<PictureProfileDTO>> PutPictureProfile(PictureProfileDTO pictureProfileDTO)
        {
            var pictureDTO = _mapper.Map<PictureProfile>(pictureProfileDTO);
            if (!(await _pictureProfileRepository.Exists(pictureDTO.Id))) return StatusCode(400, "BadRequestPutPictureProfile");
            if (!await _pictureProfileRepository.FindRegistry(pictureDTO.RegistryId)) return StatusCode(400, "badRequestRegistryId");
            var pictureProfileToSave = await _pictureProfileRepository.Update(pictureDTO);
            var picToSave = _mapper.Map<PictureProfileDTO>(pictureProfileToSave);
            return picToSave;
        }

        [HttpDelete("DeletePictureProfileById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<PictureProfileDTO>> DeletePictureProfile(int id)
        {
            var pictureProfile = await _pictureProfileRepository.Find(id);
            if (pictureProfile is null) return StatusCode(400, "BadRequestDeletePictureProfile");
            var response = await _pictureProfileRepository.Delete(pictureProfile);
            var picture = _mapper.Map<PictureProfileDTO>(pictureProfile);
            //if (!picture) return StatusCode(500, "InternalServerErrorDelete");
            //return picture;
            return response ? picture : StatusCode(500, "InternalServerErrorDelete");
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
