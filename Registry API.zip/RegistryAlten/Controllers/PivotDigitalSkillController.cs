﻿using System.Security.Claims;
using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class PivotDigitalSkillController : ControllerBase
    {
        private readonly IPivotDigitalSkillRepository _pivotDigitalSkillsRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;

        public PivotDigitalSkillController(IPivotDigitalSkillRepository pivotDigitalSkillsRepository, IHttpContextAccessor httpContextAccessor)
        {
            _pivotDigitalSkillsRepository = pivotDigitalSkillsRepository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
        }

        [HttpPost("CreatePivotDigitalSkill")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<PivotDigitalSkillDTO>> Create(PivotDigitalSkillDTO pivotDigitalSkillDTO) 
        {
            if (roles.Any(x => x.Equals("user")) && !_pivotDigitalSkillsRepository.IsUserAuthorized(keycloakId, pivotDigitalSkillDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (await _pivotDigitalSkillsRepository.SkillExists(pivotDigitalSkillDTO.Id)) return StatusCode(400,"BadRequestPivotDigitalSkill");
            if (!await _pivotDigitalSkillsRepository.FindCVRegistry(pivotDigitalSkillDTO.CVRegistryId)) return StatusCode(400,"BadRequestFindCVRegistry");
            var pivotDigitalSkillDTOWithId = await _pivotDigitalSkillsRepository.Create(pivotDigitalSkillDTO);
            return pivotDigitalSkillDTOWithId;
        }
        [HttpGet("GetAllPivotDigitalSkills")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<PivotDigitalSkillDTO>>> GetAll() 
        { 
            var pivotDigitalSkill = await _pivotDigitalSkillsRepository.GetAll();
            if (pivotDigitalSkill is null) return StatusCode(404,"NotFoundDefaultDigitalSkill");
            return pivotDigitalSkill;
        }

        [HttpPut("PutPivotDigitalSkill")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<PivotDigitalSkillDTO>> PutPivotDigitalSkill(PivotDigitalSkillDTO pivotDigitalSkillDTO) 
        {
            if (roles.Any(x => x.Equals("user")) && !_pivotDigitalSkillsRepository.IsUserAuthorized(keycloakId, pivotDigitalSkillDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (!await _pivotDigitalSkillsRepository.SkillExists(pivotDigitalSkillDTO.Id)) return StatusCode(400,"BadRequestPutPictureProfile");
            if (!await _pivotDigitalSkillsRepository.FindCVRegistry(pivotDigitalSkillDTO.CVRegistryId)) return StatusCode(400,"BadRequestFindCVRegistry");
            var pivotDigitalSkillDTOWithId= await _pivotDigitalSkillsRepository.Update(pivotDigitalSkillDTO);
            return pivotDigitalSkillDTOWithId;
        }
        [HttpDelete("DeletePivotDigitalSkill")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult> DeletePivotDigitalSkill(int id) 
        {
            var pivotDigitalSkill = _pivotDigitalSkillsRepository.Find(id).Result;
            if (roles.Any(x => x.Equals("user")) && !_pivotDigitalSkillsRepository.IsUserAuthorized(keycloakId, pivotDigitalSkill.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (pivotDigitalSkill is not null)
                return await _pivotDigitalSkillsRepository.Delete(pivotDigitalSkill.Id) ? Ok() : StatusCode(500, "InternalServerErrorDelete");
            return StatusCode(404,"NotFoundDefaultDigitalSkill");
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
