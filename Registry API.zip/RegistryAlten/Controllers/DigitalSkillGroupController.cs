﻿using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;



namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
    [Route("api/[controller]")]
    [ApiController]
    public class DigitalSkillGroupController : ControllerBase
    {
        private readonly IDigitalSkillGroupsRepository _digitalSkillGroupRepository;



        public DigitalSkillGroupController(IDigitalSkillGroupsRepository digitalSkillGroupRepository)
        {
            _digitalSkillGroupRepository = digitalSkillGroupRepository;
        }



        [HttpPost("CreateDigitalSkillGroup")]
        public async Task<ActionResult<List<DigitalSkillGroupDTO>>> Create(DigitalSkillGroupDTO digitalSkillGroupDTO)
        {
            if (await _digitalSkillGroupRepository.Get(digitalSkillGroupDTO.Name) != null)
            {
                return StatusCode(400, "BadRequestCreateDigitalSkillGroup");
            }
            var res = await _digitalSkillGroupRepository.Create(digitalSkillGroupDTO.Name);
            return res;
        }



        [HttpGet("GetDigitalSkillGroupList")]
        public async Task<ActionResult<List<DigitalSkillGroupDTO>>> GetAll()
        {
            var res = await _digitalSkillGroupRepository.GetAll();
            return res;
        }



        [HttpPut("UpdateDigitalSkillGroup")]
        public async Task<ActionResult<List<DigitalSkillGroupDTO>>> Update(DigitalSkillGroupDTO digitalSkillGroupDTO)
        {
            if (await _digitalSkillGroupRepository.Get(digitalSkillGroupDTO.Name) != null)
            {
                return StatusCode(400, "BadRequestPutDigitalSkillGroup");
            }
            var existingDigitalSkillGroup = await _digitalSkillGroupRepository.ExistingSkill(digitalSkillGroupDTO.Id);
            if (existingDigitalSkillGroup == null)
            {
                return StatusCode(404, "NotFoundDigitalSkillGroup");
            }
            existingDigitalSkillGroup.Name = digitalSkillGroupDTO.Name;
            var res = await _digitalSkillGroupRepository.Update(existingDigitalSkillGroup);
            return res;
        }



        [HttpDelete("DeleteDigitalSkillGroup")]
        public async Task<ActionResult<List<DigitalSkillGroupDTO>>> Delete(DigitalSkillGroupDTO digitalSkillGroupDTO)
        {
            var existingDigitalSkillGroup = await _digitalSkillGroupRepository.Get(digitalSkillGroupDTO.Name);



            if (existingDigitalSkillGroup == null)
            {
                return StatusCode(404, "NotFoundDigitalSkillGroup");
            }
            var res = _digitalSkillGroupRepository.Delete(existingDigitalSkillGroup);
            if (await res)
            {
                return await GetAll();
            }
            return StatusCode(400, "BadRequestDeleteDigitalSkillGroup");
        }
    }
}