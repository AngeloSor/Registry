﻿using RegistryAlten.BLL;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Route("api/[controller]")]
    [ApiController]
    public class EducationAndTrainingExperienceController : ControllerBase
    {
        private readonly ISectionCVRegistryRepository<EducationAndTrainingExperienceDTO> _sectionCVRegistryRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string keycloakId;
        private readonly List<string> roles;

        public EducationAndTrainingExperienceController(ISectionCVRegistryRepository<EducationAndTrainingExperienceDTO> sectionCVRegistryRepository, IHttpContextAccessor httpContextAccessor)
        {
            _sectionCVRegistryRepository = sectionCVRegistryRepository;
            _httpContextAccessor = httpContextAccessor;
            keycloakId = GetClaim(ClaimTypes.NameIdentifier);
            roles = GetClaimRole("resource_access");
        }
        [HttpPost("CreateEducationAndTrainingExperience")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<EducationAndTrainingExperienceDTO>> Create(EducationAndTrainingExperienceDTO educationAndTrainingExperienceDTO)
        {
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, educationAndTrainingExperienceDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (!await _sectionCVRegistryRepository.FindCVRegistry(educationAndTrainingExperienceDTO.CVRegistryId)) return StatusCode(400,"BadRequestFindCVRegistry");
            var educationAndTrainingExperienceDTOWithId = await _sectionCVRegistryRepository.Create(educationAndTrainingExperienceDTO);
            return educationAndTrainingExperienceDTOWithId;
        }
        [HttpGet("GetEducationAndTrainingExperienceById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<EducationAndTrainingExperienceDTO>> GetById(int id)
        {
            var educationAndTrainingExperience = await _sectionCVRegistryRepository.GetById(id);
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, educationAndTrainingExperience.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");

            return educationAndTrainingExperience is null ? StatusCode(404,"NotFoundSection") : educationAndTrainingExperience;
        }
        [HttpGet("GetAllEducationAndTrainingExperiences")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator")]
        public async Task<ActionResult<List<EducationAndTrainingExperienceDTO>>> GetAll()
        {
            var educationAndTrainingExperience = await _sectionCVRegistryRepository.GetAll();
            return educationAndTrainingExperience;
        }
        [HttpPut("PutEducationAndTrainingExperience")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<EducationAndTrainingExperienceDTO>> Put(EducationAndTrainingExperienceDTO educationAndTrainingExperienceDTO)
        {
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, educationAndTrainingExperienceDTO.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (!(await _sectionCVRegistryRepository.Exists(educationAndTrainingExperienceDTO.Id))) return StatusCode(400, "BadRequestPutSection");
            if (!await _sectionCVRegistryRepository.FindCVRegistry(educationAndTrainingExperienceDTO.CVRegistryId)) return StatusCode(400, "BadRequestFindCVRegistry");
            var educationAndTrainingExperienceDTOWithId = await _sectionCVRegistryRepository.Update(educationAndTrainingExperienceDTO);
            return educationAndTrainingExperienceDTOWithId;
        }

        [HttpDelete("DeleteEducationAndTrainingExperienceById")]
        [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
        public async Task<ActionResult<EducationAndTrainingExperienceDTO>> Delete(int id)
        {
            var educationAndTrainingExperience = await _sectionCVRegistryRepository.Find(id);
            if (roles.Any(x => x.Equals("user")) && !_sectionCVRegistryRepository.IsUserAuthorized(keycloakId, educationAndTrainingExperience.CVRegistryId)) return StatusCode(403, "UserNotAuthorized");
            if (educationAndTrainingExperience is null) return StatusCode(400,"BadRequestDeleteSection");
            var response = await _sectionCVRegistryRepository.Delete(educationAndTrainingExperience);

            return response ? educationAndTrainingExperience : StatusCode(500, "InternalServerErrorDelete");
        }

        private string GetClaim(string claimType)
        {
            return ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType)!.Value;
        }

        private List<string> GetClaimRole(string claimType)
        {
            List<string> rolesList = new List<string>();
            var userRole = ((ClaimsIdentity)_httpContextAccessor.HttpContext.User.Identity!).FindFirst(claim => claim.Type == claimType);
            var content = Newtonsoft.Json.Linq.JObject.Parse(userRole.Value);
            foreach (var role in content["RegistryAlten"]["roles"])
            {
                rolesList.Add(role.ToString());
            }
            return rolesList;
        }
    }
}
