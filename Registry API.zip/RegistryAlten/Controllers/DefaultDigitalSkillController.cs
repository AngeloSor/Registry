﻿using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace RegistryAlten.API.Controllers
{
    [EnableCors("default")]
    [Authorize(AuthenticationSchemes = "Bearer", Roles = "administrator,user")]
    [Route("api/[controller]")]
    [ApiController]
    public class DefaultDigitalSkillController : ControllerBase
    {
        private readonly IDefaultDigitalSkillsRepository _digitalSkillsRepository;
        private readonly IDigitalSkillGroupsRepository _digitalSkillGroupsRepository;
        public DefaultDigitalSkillController(
            IDefaultDigitalSkillsRepository digitalSkillsRepository,
            IDigitalSkillGroupsRepository digitalSkillGroupsRepository )
        {
            _digitalSkillsRepository = digitalSkillsRepository;
            _digitalSkillGroupsRepository = digitalSkillGroupsRepository;
        }
        [HttpPost("CreateDefaultDigitalSkill")]
        public async Task<ActionResult<List<DigitalSkillGroupDTO>>> Create(DefaultDigitalSkillDTO digitalSkill)
        {
            var existingGroup = await _digitalSkillGroupsRepository.Get(digitalSkill.DigitalSkillGroupName);
            if (existingGroup is null)
            {
                return StatusCode(400, "BadRequestCreateGroupDefaultDigitalSkill");
            }
            var existingSkill = await _digitalSkillsRepository.Get(digitalSkill.Name);
            if (existingSkill is not null)
            {
                return StatusCode(400, "BadRequestCreateDefaultDigitalSkill");
            }
            return await _digitalSkillsRepository.Create(existingGroup, digitalSkill);
        }
        [HttpPut("UpdateDefaultDigitalSkill")]
        public async Task<ActionResult<List<DigitalSkillGroupDTO>>> Update(SkillDTO newSkill)
        {
            var existingSkill = await _digitalSkillsRepository.Get(newSkill.CurrentName);
            if (existingSkill == null) return StatusCode(404, "NotFoundDefaultDigitalSkill");
            var existingSkillName = await _digitalSkillsRepository.Get(newSkill.Name);
            if (existingSkillName != null && existingSkillName.DevelopRole == newSkill.DevelopRole) return StatusCode(400, "BadRequestDevelopRole");
            return await _digitalSkillsRepository.Update(existingSkill!, newSkill);
            
        }
        [HttpDelete("DeleteDefaultDigitalSkill")]
        public async Task<ActionResult<List<DigitalSkillGroupDTO>>> Delete(SkillDTO newSkill)
        {
            var existingSkill = await _digitalSkillsRepository.Get(newSkill.Name);
            if (existingSkill == null) return StatusCode(404, "NotFoundDefaultDigitalSkill");
            if(await _digitalSkillsRepository.Delete(existingSkill)) return await _digitalSkillGroupsRepository.GetAll();
            return BadRequest();
        }
    }
}
