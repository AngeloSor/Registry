using System.Net.Http.Headers;
using System.Text.Json.Serialization;
using AutoMapper;
using RegistryAlten.API.Configuration;
using RegistryAlten.API.Models;
using RegistryAlten.BLL;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Interface;
using RegistryAlten.DAL.Repository;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using MyWebApi.Authentication;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var key = builder.Configuration.GetSection("keycloak").Value;
var realm = builder.Configuration.GetSection("Realm").Value;
builder.Services.ConfigureJWT(builder.Environment.IsDevelopment(), key, realm);
builder.Services.AddControllersWithViews()
    .AddNewtonsoftJson(options =>
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
);
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "MyWebApi", Version = "v1" });
    c.AddSecurityDefinition(
        "Bearer",
        new OpenApiSecurityScheme
        {
         Description = "JWT Authorization header using the Bearer scheme.",
         Type = SecuritySchemeType.Http,
         Scheme = JwtBearerDefaults.AuthenticationScheme
        });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
              Reference = new OpenApiReference
              {
                  Id = JwtBearerDefaults.AuthenticationScheme,
                  Type = ReferenceType.SecurityScheme
              }
            }
            ,new List<string>()
        }
    });
});

builder.Services.AddMvc().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.WriteIndented = true;
    options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

builder.Services.Configure<SmtpConnectionModel>(builder.Configuration.GetSection("SmtpServer"));
//builder.Services.AddSingleton<IEmailSender, EmailSenderRepository>();

builder.Services.AddScoped<IRegistryRepository, RegistryRepository>();
builder.Services.AddScoped<ICVRegistryRepository, CVRegistryRepository>();
builder.Services.AddScoped<ISectionCVRegistryRepository<EducationAndTrainingExperienceDTO>, EducationAndTrainingExperienceRepository>();
builder.Services.AddScoped<IPersonalSkillRepository, PersonalSkillRepository>();
builder.Services.AddScoped<ISectionCVRegistryRepository<WorkExperienceDTO>, WorkExperienceRepository>();
builder.Services.AddScoped<IDigitalSkillGroupsRepository, DigitalSkillGroupRepository>();
builder.Services.AddScoped<IDefaultDigitalSkillsRepository, DefaultDigitalSkillsRepository>();
builder.Services.AddScoped<ISectionCVRegistryRepository<CVFileDTO>, CVFileRepository>();
builder.Services.AddScoped<IPivotDigitalSkillRepository, PivotDigitalSkillRepository>();
builder.Services.AddScoped<IPictureProfileRepository, PictureProfileRepository>();
builder.Services.AddScoped<IMeetingRepository, MeetingRepository>();
builder.Services.AddScoped<IConditionRepository, ConditionRepository>();
builder.Services.AddScoped<ICodinGameRepository, CodinGameRepository>();
builder.Services.AddScoped<IFeedbackRepository, FeedbackRepository>();
builder.Services.AddScoped<IEmailSender, EmailSenderRepository>();

builder.Services.AddHttpContextAccessor();

builder.Services.AddDbContext<KeycloakAuthDbContext>(
  options => options.UseSqlServer(
     builder.Configuration.GetConnectionString("DbConn")
  )
);

var services = new ServiceCollection();
builder.Services.AddDbContext<KeycloakAuthDbContext>();
builder.Services.AddAutoMapper(typeof(AutoMapperConfiguration));
var mapperConfig = new MapperConfiguration(cfg =>
{
    cfg.AddProfile(new AutoMapperConfiguration());
});
IMapper mapper = mapperConfig.CreateMapper();
services.AddSingleton(mapper);
var serviceProvider = services.BuildServiceProvider();
builder.Services.AddCors(core =>
{
    core.AddPolicy("default", options =>
    {
        options.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
    });
});

builder.Services.AddTransient<IClaimsTransformation, ClaimsTransformer>();
var app = builder.Build();

StatusDictionaryResponse.AddStatusDictionary();

app.UseCors("default");

app.UseSwagger();
app.UseSwaggerUI();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.MapGet("/", () =>  DateTime.UtcNow);

app.Run();
