﻿using RegistryAlten.DAL.Entities;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Data
{
    public class KeycloakAuthDbContext : DbContext
    {
        public KeycloakAuthDbContext(DbContextOptions<KeycloakAuthDbContext> options) : base(options)
        {
        }
        public DbSet<Registry>? Registry { get; set; }
        public DbSet<CVRegistry>? CVRegistry { get; set; }
        public DbSet<WorkExperience>? WorkExperience { get; set; }
        public DbSet<EducationAndTrainingExperience>? EducationAndTrainingExperience { get; set; }
        public DbSet<PersonalSkill>? PersonalSkill { get; set; }
        public DbSet<DigitalSkillGroup>? DigitalSkillGroups { get; set; }
        public DbSet<DefaultDigitalSkill>? DigitalSkills { get; set; }
        public DbSet<CVFile>? CVFile { get; set; }
        public DbSet<PivotDigitalSkill>? PivotDigitalSkills { get; set; }
        public DbSet<Meeting>? Meeting { get; set; }
        public DbSet<PictureProfile>? PictureProfile { get; set; }
        public DbSet<Condition>? Condition { get; set; }
        public DbSet<CodinGame>? CodinGame { get; set; }

        public DbSet<Feedback>? Feedback { get; set; }
    }
}
