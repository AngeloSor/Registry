﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RegistryAlten.DAL.Migrations
{
    public partial class Initialize : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DigitalSkillGroups",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DigitalSkillGroups", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Registry",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdKeycloak = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BirthDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FiscalCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Province = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Street = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StreetNumber = table.Column<int>(type: "int", nullable: true),
                    ZIPCode = table.Column<int>(type: "int", nullable: true),
                    Gender = table.Column<int>(type: "int", nullable: true),
                    BusinessManager = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Condition = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Technician = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Registry", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DigitalSkills",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DevelopRole = table.Column<int>(type: "int", nullable: false),
                    DigitalSkillGroupId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DigitalSkills", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DigitalSkills_DigitalSkillGroups_DigitalSkillGroupId",
                        column: x => x.DigitalSkillGroupId,
                        principalTable: "DigitalSkillGroups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CVRegistry",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RegistryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CVRegistry", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CVRegistry_Registry_RegistryId",
                        column: x => x.RegistryId,
                        principalTable: "Registry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Meeting",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InterviewerId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Time = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Meeting", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Meeting_Registry_InterviewerId",
                        column: x => x.InterviewerId,
                        principalTable: "Registry",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Meeting_Registry_UserId",
                        column: x => x.UserId,
                        principalTable: "Registry",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "PictureProfile",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Picture = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RegistryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PictureProfile", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PictureProfile_Registry_RegistryId",
                        column: x => x.RegistryId,
                        principalTable: "Registry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CVFile",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    File = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CVRegistryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CVFile", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CVFile_CVRegistry_CVRegistryId",
                        column: x => x.CVRegistryId,
                        principalTable: "CVRegistry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EducationAndTrainingExperience",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QualificationAwarded = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OrganisationOrSchool = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VotesObtained = table.Column<int>(type: "int", nullable: false),
                    CVRegistryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EducationAndTrainingExperience", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EducationAndTrainingExperience_CVRegistry_CVRegistryId",
                        column: x => x.CVRegistryId,
                        principalTable: "CVRegistry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PersonalSkill",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Property = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CVRegistryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersonalSkill", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PersonalSkill_CVRegistry_CVRegistryId",
                        column: x => x.CVRegistryId,
                        principalTable: "CVRegistry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PivotDigitalSkills",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Category = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DevelopRole = table.Column<int>(type: "int", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CVRegistryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PivotDigitalSkills", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PivotDigitalSkills_CVRegistry_CVRegistryId",
                        column: x => x.CVRegistryId,
                        principalTable: "CVRegistry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WorkExperience",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WorkingPosition = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Agency = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Location = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CVRegistryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkExperience", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WorkExperience_CVRegistry_CVRegistryId",
                        column: x => x.CVRegistryId,
                        principalTable: "CVRegistry",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CVFile_CVRegistryId",
                table: "CVFile",
                column: "CVRegistryId");

            migrationBuilder.CreateIndex(
                name: "IX_CVRegistry_RegistryId",
                table: "CVRegistry",
                column: "RegistryId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DigitalSkills_DigitalSkillGroupId",
                table: "DigitalSkills",
                column: "DigitalSkillGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_EducationAndTrainingExperience_CVRegistryId",
                table: "EducationAndTrainingExperience",
                column: "CVRegistryId");

            migrationBuilder.CreateIndex(
                name: "IX_Meeting_InterviewerId",
                table: "Meeting",
                column: "InterviewerId");

            migrationBuilder.CreateIndex(
                name: "IX_Meeting_UserId",
                table: "Meeting",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_PersonalSkill_CVRegistryId",
                table: "PersonalSkill",
                column: "CVRegistryId");

            migrationBuilder.CreateIndex(
                name: "IX_PictureProfile_RegistryId",
                table: "PictureProfile",
                column: "RegistryId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PivotDigitalSkills_CVRegistryId",
                table: "PivotDigitalSkills",
                column: "CVRegistryId");

            migrationBuilder.CreateIndex(
                name: "IX_WorkExperience_CVRegistryId",
                table: "WorkExperience",
                column: "CVRegistryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CVFile");

            migrationBuilder.DropTable(
                name: "DigitalSkills");

            migrationBuilder.DropTable(
                name: "EducationAndTrainingExperience");

            migrationBuilder.DropTable(
                name: "Meeting");

            migrationBuilder.DropTable(
                name: "PersonalSkill");

            migrationBuilder.DropTable(
                name: "PictureProfile");

            migrationBuilder.DropTable(
                name: "PivotDigitalSkills");

            migrationBuilder.DropTable(
                name: "WorkExperience");

            migrationBuilder.DropTable(
                name: "DigitalSkillGroups");

            migrationBuilder.DropTable(
                name: "CVRegistry");

            migrationBuilder.DropTable(
                name: "Registry");
        }
    }
}
