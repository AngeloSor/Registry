﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RegistryAlten.DAL.Migrations
{
    public partial class CreateConditionTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Condition",
                table: "Registry");

            migrationBuilder.AddColumn<int>(
                name: "ConditionId",
                table: "Registry",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "Registry",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "Condition",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Condition", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Registry_ConditionId",
                table: "Registry",
                column: "ConditionId");

            migrationBuilder.AddForeignKey(
                name: "FK_Registry_Condition_ConditionId",
                table: "Registry",
                column: "ConditionId",
                principalTable: "Condition",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Registry_Condition_ConditionId",
                table: "Registry");

            migrationBuilder.DropTable(
                name: "Condition");

            migrationBuilder.DropIndex(
                name: "IX_Registry_ConditionId",
                table: "Registry");

            migrationBuilder.DropColumn(
                name: "ConditionId",
                table: "Registry");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "Registry");

            migrationBuilder.AddColumn<string>(
                name: "Condition",
                table: "Registry",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
