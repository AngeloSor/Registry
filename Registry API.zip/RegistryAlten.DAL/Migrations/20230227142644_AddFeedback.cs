﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RegistryAlten.DAL.Migrations
{
    public partial class AddFeedback : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Feedback",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Esito = table.Column<int>(type: "int", nullable: false),
                    Esperienza = table.Column<int>(type: "int", nullable: false),
                    Profilo = table.Column<int>(type: "int", nullable: false),
                    Conclusioni = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DesignEvaluation = table.Column<int>(type: "int", nullable: false),
                    CodeEvaluation = table.Column<int>(type: "int", nullable: false),
                    ArchitectureEvaluation = table.Column<int>(type: "int", nullable: false),
                    Note = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FeedbackInterviewerId = table.Column<int>(type: "int", nullable: true),
                    FeedBackUserId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Feedback", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Feedback_Registry_FeedbackInterviewerId",
                        column: x => x.FeedbackInterviewerId,
                        principalTable: "Registry",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Feedback_Registry_FeedBackUserId",
                        column: x => x.FeedBackUserId,
                        principalTable: "Registry",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Feedback_FeedbackInterviewerId",
                table: "Feedback",
                column: "FeedbackInterviewerId");

            migrationBuilder.CreateIndex(
                name: "IX_Feedback_FeedBackUserId",
                table: "Feedback",
                column: "FeedBackUserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Feedback");
        }
    }
}
