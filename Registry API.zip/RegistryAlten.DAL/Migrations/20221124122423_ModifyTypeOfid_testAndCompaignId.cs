﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RegistryAlten.DAL.Migrations
{
    public partial class ModifyTypeOfid_testAndCompaignId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame");

            migrationBuilder.DropIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame");

            migrationBuilder.AlterColumn<int>(
                name: "RegistryId",
                table: "CodinGame",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "IdTest",
                table: "CodinGame",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<int>(
                name: "CampaignId",
                table: "CodinGame",
                type: "int",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                unique: true,
                filter: "[RegistryId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                principalTable: "Registry",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame");

            migrationBuilder.DropIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame");

            migrationBuilder.AlterColumn<int>(
                name: "RegistryId",
                table: "CodinGame",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IdTest",
                table: "CodinGame",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "CampaignId",
                table: "CodinGame",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                principalTable: "Registry",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
