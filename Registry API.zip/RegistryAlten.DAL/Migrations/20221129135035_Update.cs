﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RegistryAlten.DAL.Migrations
{
    public partial class Update : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame");

            migrationBuilder.DropIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame");

            migrationBuilder.AlterColumn<int>(
                name: "RegistryId",
                table: "CodinGame",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                principalTable: "Registry",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame");

            migrationBuilder.DropIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame");

            migrationBuilder.AlterColumn<int>(
                name: "RegistryId",
                table: "CodinGame",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_CodinGame_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                unique: true,
                filter: "[RegistryId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_CodinGame_Registry_RegistryId",
                table: "CodinGame",
                column: "RegistryId",
                principalTable: "Registry",
                principalColumn: "Id");
        }
    }
}
