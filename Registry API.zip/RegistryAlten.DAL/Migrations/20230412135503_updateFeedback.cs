﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RegistryAlten.DAL.Migrations
{
    public partial class updateFeedback : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Note",
                table: "Feedback");

            migrationBuilder.RenameColumn(
                name: "Profilo",
                table: "Feedback",
                newName: "ValutazioneGlobale");

            migrationBuilder.RenameColumn(
                name: "Esito",
                table: "Feedback",
                newName: "Ruolo");

            migrationBuilder.AddColumn<bool>(
                name: "IsPassed",
                table: "Feedback",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsPassed",
                table: "Feedback");

            migrationBuilder.RenameColumn(
                name: "ValutazioneGlobale",
                table: "Feedback",
                newName: "Profilo");

            migrationBuilder.RenameColumn(
                name: "Ruolo",
                table: "Feedback",
                newName: "Esito");

            migrationBuilder.AddColumn<string>(
                name: "Note",
                table: "Feedback",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
