﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class CVFileRepository : AbstractRepository<CVFileDTO>, ISectionCVRegistryRepository<CVFileDTO>
    {
    private readonly IMapper _mapper;
        public CVFileRepository(KeycloakAuthDbContext context, IMapper mapper) : base(context)
        {
            _mapper = mapper;
        }
        public override async Task<CVFileDTO> GetById(int id)
        {
            var cvFile = await _context.CVFile.FirstOrDefaultAsync(cvFile => cvFile.Id == id);
            if (cvFile is null) return null;
            var cvFileResponse = _mapper.Map<CVFileDTO>(cvFile);
            return cvFileResponse;
        }
        public override async Task<CVFileDTO> Create(CVFileDTO cvFileDTO)
        {
            var cvFileToSave = _mapper.Map<CVFile>(cvFileDTO);
            _context.CVFile.Add(cvFileToSave);
            await _context.SaveChangesAsync();
            var cvFileToSaveDTO = _mapper.Map<CVFileDTO>(cvFileToSave);
            return cvFileToSaveDTO;
        }
        public async Task<List<CVFileDTO>> GetAll()
        {
            List<CVFileDTO> cvFile;
            cvFile = await _context.CVFile.Select(cvFile => _mapper.Map<CVFileDTO>(cvFile)).ToListAsync();
            return cvFile;
        }

        public override async Task<CVFileDTO> Update(CVFileDTO cvFileDTO)
        {
            var cvFileToUpdate = _mapper.Map<CVFile>(cvFileDTO);
            _context.Update(cvFileToUpdate);
            await _context.SaveChangesAsync();
            var cvFileToUpdateDTO = _mapper.Map<CVFileDTO>(cvFileToUpdate);
            return cvFileToUpdateDTO;
        }

        public override async Task<bool> Delete(CVFileDTO cvFileDTO)
        {
            var cvFileToDelete = _mapper.Map<CVFile>(cvFileDTO);
            _context.Remove(cvFileToDelete);
            return await this.Save();
        }
        public async Task<bool> Exists(int id)
        {
            return await _context.CVFile.AnyAsync(cvFile => cvFile.Id == id);
        }

        public override async Task<CVFileDTO> Find(int id)
        {
            var cvFileEntity = await _context.CVFile.AsNoTracking().FirstOrDefaultAsync(cvFile => cvFile.Id == id);
            CVFileDTO? cvFileDTO = null;
            if (cvFileEntity != null) cvFileDTO = _mapper.Map<CVFileDTO>(cvFileEntity);
            return cvFileDTO;
        }
        public async Task<bool> FindCVRegistry(int id)
        {
            return await _context.CVRegistry.AnyAsync(cvRegistry => cvRegistry.Id == id);
        }

        public override bool IsUserAuthorized(string keycloakId, int cvRegistryId)
        {
            var userId = GetUserIdFromKeycloakId(keycloakId);
            int registryId = _context.CVRegistry.Where(c => c.Id == cvRegistryId).Select(r => r.RegistryId).FirstOrDefaultAsync().Result;

            return registryId == userId;
        }

        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
