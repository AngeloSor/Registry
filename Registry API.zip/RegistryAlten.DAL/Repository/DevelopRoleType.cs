﻿namespace RegistryAlten.API.Models;

public enum DevelopRoleType
{
    Frontend,
    Backend
}