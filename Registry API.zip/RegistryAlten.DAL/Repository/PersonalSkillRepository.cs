﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class PersonalSkillRepository : AbstractRepository<PersonalSkillDTO> , IPersonalSkillRepository
    {
        private readonly IMapper _mapper;
        public PersonalSkillRepository(KeycloakAuthDbContext context, IMapper mapper) :base(context)
        {   
            _mapper = mapper;
        }
        public override async Task<PersonalSkillDTO> Create(PersonalSkillDTO personalSkillDTO)
        {
            var personalSkillToSave = _mapper.Map<PersonalSkill>(personalSkillDTO);
            _context.PersonalSkill.Add(personalSkillToSave);
            await _context.SaveChangesAsync();
            var personalSkillToSaveDTO = _mapper.Map<PersonalSkillDTO>(personalSkillToSave);
            return personalSkillToSaveDTO;
        }
        public async Task<PersonalSkillDTO[]> CreateSkills(PersonalSkillDTO[] personalSkillsDTO)
        {
            foreach (PersonalSkillDTO personalSkillDTO in personalSkillsDTO)
            {
                var personalSkillToSave = _mapper.Map<PersonalSkill>(personalSkillDTO);
                _context.PersonalSkill.Add(personalSkillToSave);
                personalSkillDTO.Id = personalSkillToSave.Id;
            }
            await _context.SaveChangesAsync();
            return personalSkillsDTO;
        }
        public override async Task<PersonalSkillDTO> GetById(int id)
        {
            var personalSkill = await _context.PersonalSkill.FirstOrDefaultAsync(personalSkill => personalSkill.Id == id);
            if (personalSkill is null) return null;
            var personalSkillResponse = _mapper.Map<PersonalSkillDTO>(personalSkill);
            return personalSkillResponse;
        }
        public async Task<List<PersonalSkillDTO>> GetAll()
        {
            List<PersonalSkillDTO> personalSkill = await _context.PersonalSkill.Select(personalSkill => _mapper.Map<PersonalSkillDTO>(personalSkill)).ToListAsync();
            return personalSkill;
        }
        public override async Task<PersonalSkillDTO> Update(PersonalSkillDTO personalSkillDTO)
        {
            var personalSkillToUpdate = _mapper.Map<PersonalSkill>(personalSkillDTO);
            _context.Update(personalSkillToUpdate);
            await _context.SaveChangesAsync();
            var personalSkillToUpdateDTO = _mapper.Map<PersonalSkillDTO>(personalSkillToUpdate);
            return personalSkillToUpdateDTO;
        }
        public override async Task<bool> Delete(PersonalSkillDTO personalSkillDTO)
        {
            var personalSkillToDelete = _mapper.Map<PersonalSkill>(personalSkillDTO);
            _context.Remove(personalSkillToDelete);
            return await this.Save();
        }
        public override async Task<PersonalSkillDTO> Find(int id)
        {
            var personalSkillEntity = await _context.PersonalSkill.AsNoTracking().FirstOrDefaultAsync(personalSkill => personalSkill.Id == id);
            PersonalSkillDTO? personalSkillDTO = null;
            if (personalSkillEntity != null) personalSkillDTO = _mapper.Map<PersonalSkillDTO>(personalSkillEntity);
            return personalSkillDTO;
        }
        public override bool IsUserAuthorized(string keycloakId, int cvRegistryId)
        {
            var userId = GetUserIdFromKeycloakId(keycloakId);
            int registryId = _context.CVRegistry.Where(c => c.Id == cvRegistryId).Select(r => r.RegistryId).FirstOrDefaultAsync().Result;

            return registryId == userId;
        }

        public async Task<bool> Exists(int id)
        {
            return await _context.PersonalSkill.AnyAsync(personalSkill => personalSkill.Id == id);
        }
        public async Task<bool> FindCVRegistry(int id)
        {
            var cvRegistry = await _context.CVRegistry.AsNoTracking().FirstOrDefaultAsync(cvRegistry => cvRegistry.Id == id);
            bool check = cvRegistry is not null ? true : false;
            return check;
        }
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
