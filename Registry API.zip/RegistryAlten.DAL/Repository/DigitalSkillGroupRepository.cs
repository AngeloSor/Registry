﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class DigitalSkillGroupRepository : IDigitalSkillGroupsRepository
    {
        private readonly KeycloakAuthDbContext _context;
        private readonly IMapper _mapper;
        public DigitalSkillGroupRepository(KeycloakAuthDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public async Task<List<DigitalSkillGroupDTO>> Create(string name)
        {
            var newDigitalSkillGroup = new DigitalSkillGroup(name);
            _context.DigitalSkillGroups.Add(newDigitalSkillGroup);
            _context.SaveChanges();

            var result = await GetAll();
            return result!;
        }
        public async Task<DigitalSkillGroup> Get(string name)
        {
            var result = await _context.DigitalSkillGroups.Where(x => x.Name == name).Include(c => c.DigitalSkills).FirstOrDefaultAsync();
            return result!;
        }
        public async Task<List<DigitalSkillGroupDTO>> GetAll()
        {
            var digitalSkillGroups = await _context.DigitalSkillGroups.Include(c => c.DigitalSkills).ToListAsync();
            var res = new List<DigitalSkillGroupDTO>();
            foreach(var digitalSkillGroup in digitalSkillGroups)
            {
                var digitalSkillGroupDTO = new DigitalSkillGroupDTO(digitalSkillGroup.Id, digitalSkillGroup.Name);
                List<SkillDTO> skills = new List<SkillDTO>();
                foreach (var skill in digitalSkillGroup.DigitalSkills)
                {
                    var digitalSkill = new SkillDTO(skill.Name,skill.DevelopRole);
                    skills.Add(digitalSkill);
                }
                digitalSkillGroupDTO.DigitalSkills = skills;
                res.Add(digitalSkillGroupDTO);
            }
            return res!;
        }
        public async Task<List<DigitalSkillGroupDTO>> Update(DigitalSkillGroup digitalSkillGroup)
        {
            _context.Update(digitalSkillGroup);
            await _context.SaveChangesAsync();
            return await GetAll();
        }
        public async Task<bool> Delete(DigitalSkillGroup existingDigitalSkillGroup)
        {
            var res = false;
            if (existingDigitalSkillGroup.DigitalSkills.Count() == 0)
            {
                _context.DigitalSkillGroups.Remove(existingDigitalSkillGroup);
                _context.SaveChanges();
                if (await _context.DigitalSkillGroups.Where(x => x == existingDigitalSkillGroup).FirstOrDefaultAsync() == null)
                {
                    res = true;
                }
            }
            return res;
        }

        public async Task<DigitalSkillGroup> ExistingSkill(int id)
        {
            var digitalSkillGroup = await _context.DigitalSkillGroups.Where(x => x.Id == id).Include(c => c.DigitalSkills).FirstOrDefaultAsync();
            return digitalSkillGroup;
        }
    }
}
