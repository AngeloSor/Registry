﻿using RegistryAlten.DAL.Data;
using Microsoft.EntityFrameworkCore;
using RegistryAlten.DAL.Interface;


namespace RegistryAlten.DAL.Repository
{
    public abstract class AbstractRepository<T> : IRepository<T>
    {
        protected readonly KeycloakAuthDbContext _context;
        public AbstractRepository(KeycloakAuthDbContext context)
        {
            _context = context;
        }
        public abstract Task<T> Create(T dto);
        public abstract Task<bool> Delete(T dto);
        public abstract Task<T> GetById(int Id);
        public abstract Task<T> Update(T dto);
        public abstract Task<T> Find(int id);
        public abstract bool IsUserAuthorized(string keycloakId, int registryId);

        protected int GetUserIdFromKeycloakId(string keycloakId)
        { 
            return _context.Registry.Where(r => r.IdKeycloak == keycloakId).Select(r => r.Id).FirstOrDefaultAsync().Result;
        }
    }
}
