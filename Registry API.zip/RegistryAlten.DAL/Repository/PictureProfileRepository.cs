﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class PictureProfileRepository : AbstractRepository<PictureProfile>, IPictureProfileRepository
    {
        private readonly IMapper _mapper;
        public PictureProfileRepository(KeycloakAuthDbContext context, IMapper mapper) : base(context)
        {
            _mapper = mapper;
        }
        public override async Task<PictureProfile> Create(PictureProfile pictureProfile)
        {
            //var pictureToSave = _mapper.Map<PictureProfile>(pictureProfileDTO);
            _context.PictureProfile.Add(pictureProfile);
            await _context.SaveChangesAsync();
            //var pictureToSaveDTO = _mapper.Map<PictureProfileDTO>(pictureToSave);
            return pictureProfile;
        }
        public override async Task<PictureProfile> GetById(int id)
        {
            var picture = await _context.PictureProfile.FirstOrDefaultAsync(picture => picture.Id == id);
            if (picture is null) return null;
            //var pictureResponse = _mapper.Map<PictureProfileDTO>(picture);
            return picture;
        }
        public override async Task<PictureProfile> Update(PictureProfile pictureProfile)
        {
            //var pictureToUpdate = _mapper.Map<PictureProfile>(pictureProfileDTO);
            _context.Update(pictureProfile);
            await _context.SaveChangesAsync();
            //var pictureToUpdateDTO = _mapper.Map<PictureProfileDTO>(pictureToUpdate);
            return pictureProfile;
        }
        public override async Task<bool> Delete(PictureProfile pictureProfile)
        {
            //var pictureToDelete = _mapper.Map<PictureProfile>(pictureProfileDTO);
            _context.Remove(pictureProfile);
            return await this.Save();
        }
        public override async Task<PictureProfile> Find(int id)
        {
            var pictureEntity = await _context.PictureProfile.AsNoTracking().FirstOrDefaultAsync(picture => picture.Id == id);
            //PictureProfile? pictureProfileDTO = null;
            //if (pictureEntity != null) pictureProfileDTO = _mapper.Map<PictureProfileDTO>(pictureEntity);
            return pictureEntity;
        }
        public async Task<bool> Exists(int id)
        {
            return await _context.PictureProfile.AnyAsync(picture => picture.Id == id);
        }

        public async Task<List<PictureProfile>> GetAll()
        {
            //List<PictureProfileDTO> picture;
            //picture = await _context.PictureProfile.Select(picture => _mapper.Map<PictureProfileDTO>(picture)).ToListAsync();
            List<PictureProfile> picture = await _context.PictureProfile.ToListAsync();
            return picture;
        }

        public override bool IsUserAuthorized(string keycloakId, int registryId)
        {
            var userId = GetUserIdFromKeycloakId(keycloakId);
            return registryId == userId;
        }

        public async Task<bool> FindRegistry(int id)
        {
            return await _context.Registry.AnyAsync(registry => registry.Id == id);
        }

        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
