﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class CVRegistryRepository : AbstractRepository<CVRegistry>, ICVRegistryRepository
    {
        private readonly IMapper _mapper;
        public CVRegistryRepository(KeycloakAuthDbContext context,IMapper mapper):base(context)
        {
            _mapper = mapper;
        }
        public override async Task<CVRegistry> Create(CVRegistry cvRegistry)
        {
            //var cvRegistryToSave = _mapper.Map<CVRegistry>(cvRegistryDTO);
            _context.CVRegistry.Add(cvRegistry);
            await _context.SaveChangesAsync();
            //var cvRegistryToSaveDTO = _mapper.Map<CVRegistryDTO>(cvRegistryToSave);
            return cvRegistry;
        }
        public override async Task<CVRegistry> GetById(int id)
        {
            var cvRegistry = await _context.CVRegistry.FirstOrDefaultAsync(dbCVRegistry => dbCVRegistry.Id == id);
            //if (cvRegistry is null) return null;
            //var cvRegistryResponse = _mapper.Map<CVRegistryDTO>(cvRegistry);
            //return cvRegistryResponse;
            return cvRegistry;
        }

        public async Task<CVRegistry> GetByIdRegistry(int id)
        {
            //var cvRegistry = await _context.CVRegistry
            //    .Include(dbCVRegistry => dbCVRegistry.CVFiles)
            //    .Include(dbCVRegistry => dbCVRegistry.EducationAndTrainingExperiences)
            //    .Include(dbCVRegistry => dbCVRegistry.WorkExperiences)
            //    .Include(dbCVRegistry => dbCVRegistry.PersonalSkills)
            //    .Include(dbCVRegistry => dbCVRegistry.PivotDigitalSkills)
            //    .Where(dbCVRegistry => dbCVRegistry.RegistryId == id).Select(cvRegistry => _mapper.Map<CVDTO>(cvRegistry)).ToListAsync();

            var cvRegistry = await _context.CVRegistry
               .Include(dbCVRegistry => dbCVRegistry.CVFiles)
               .Include(dbCVRegistry => dbCVRegistry.EducationAndTrainingExperiences)
               .Include(dbCVRegistry => dbCVRegistry.WorkExperiences)
               .Include(dbCVRegistry => dbCVRegistry.PersonalSkills)
               .Include(dbCVRegistry => dbCVRegistry.PivotDigitalSkills)
               .FirstOrDefaultAsync(dbCVRegistry => dbCVRegistry.RegistryId == id);

            //if (cvRegistry.Count == 0) return null;
            return cvRegistry;
        }
        public async Task<List<CVRegistry>> GetAllUserRegistry(int userId)
        {
            //var cvRegistry = await _context.CVRegistry
            //    .Include(dbCVRegistry => dbCVRegistry.CVFiles)
            //    .Include(dbCVRegistry => dbCVRegistry.EducationAndTrainingExperiences)
            //    .Include(dbCVRegistry => dbCVRegistry.WorkExperiences)
            //    .Include(dbCVRegistry => dbCVRegistry.PersonalSkills)
            //    .Include(dbCVRegistry => dbCVRegistry.PivotDigitalSkills)
            //    .Where(dbCVRegistry => dbCVRegistry.RegistryId == userId).Select(cvRegistry => _mapper.Map<CVDTO>(cvRegistry)).ToListAsync();

            var cvRegistry = await _context.CVRegistry
                .Include(dbCVRegistry => dbCVRegistry.CVFiles)
               .Include(dbCVRegistry => dbCVRegistry.EducationAndTrainingExperiences)
                .Include(dbCVRegistry => dbCVRegistry.WorkExperiences)
                .Include(dbCVRegistry => dbCVRegistry.PersonalSkills)
                .Include(dbCVRegistry => dbCVRegistry.PivotDigitalSkills)
                .Where(dbCVRegistry => dbCVRegistry.RegistryId == userId).ToListAsync();

            return cvRegistry;
        }
        public async Task<bool> DeleteAll(List<CVRegistry> cv)
        {
            //var cvRegistryToDelete = _mapper.Map<List<CVRegistry>>(cvDTO);
            _context.CVRegistry.RemoveRange(cv);
            return await this.Save();
        }

        public async Task<List<CVRegistry>> GetAll()
        {
            //List<CVRegistryDTO> cvRegistries = await _context.CVRegistry.Select(cvRegistry => _mapper.Map<CVRegistryDTO>(cvRegistry)).ToListAsync();
            var cvRegistry = await _context.CVRegistry.ToListAsync();
            return cvRegistry;
        }
        public override async Task<CVRegistry> Update(CVRegistry cvRegistry)
        {
            //var cvRegistryToUpdate = _mapper.Map<CVRegistry>(cvRegistryDTO);
            _context.Update(cvRegistry);
            await _context.SaveChangesAsync();
            //var cvRegistryToUpdateDTO = _mapper.Map<CVRegistryDTO>(cvRegistryToUpdate);
            return cvRegistry;
        }
        public override async Task<bool> Delete(CVRegistry cvRegistry)
        {
            //var cvRegistryToDelete = _mapper.Map<CVRegistry>(cvRegistryDTO);
            _context.Remove(cvRegistry);
            return await this.Save();
        }
        public override async Task<CVRegistry> Find(int id)
        {
            var cvRegistryEntity = await _context.CVRegistry.AsNoTracking().FirstOrDefaultAsync(cvRegistry => cvRegistry.Id == id);
            //CVRegistryDTO? cvRegistryDTO = null;
            //if (cvRegistryEntity != null) cvRegistryDTO = _mapper.Map<CVRegistryDTO>(cvRegistryEntity);
            return cvRegistryEntity;
        }
        public override bool IsUserAuthorized(string keycloakId, int registryId)
        {
            var userId = GetUserIdFromKeycloakId(keycloakId);
            return registryId == userId;
        }

        public async Task<bool> Exists(int id)
        {
            return await _context.CVRegistry.AnyAsync(cvRegistry => cvRegistry.Id == id);
        }

        public async Task<bool> FindRegistry(int id)
        {
            var registry = await _context.Registry.AsNoTracking().FirstOrDefaultAsync(Registry => Registry.Id == id);
            bool check = registry is not null ? true : false;
            return check;
        }

        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
