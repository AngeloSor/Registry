﻿using RegistryAlten.SHARED;
using MimeKit;
using Microsoft.Extensions.Options;
using RegistryAlten.API.Models;
using AutoMapper;
using MailKit.Net.Smtp;
using RegistryAlten.DAL.Interface;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using RegistryAlten.DAL.Entities;

namespace RegistryAlten.DAL.Repository
{
    public class EmailSenderRepository : IEmailSender
    {
        

        public EmailSenderRepository()
        {

        }

        //    private void Connect()
        //    {
        //        _smtpClient.Connect(_options.Value.Hostname, _options.Value.Port, useSsl: false);
        //    }

        //    public async Task<bool> SendEmailAsync(MimeMessageDTO mimeMessageDTO)
        //    {
        //        if (!_smtpClient.IsConnected)
        //            Connect();
        //        MimeMessage mimeMessage = FromMimeMessageDTOToMimeMessage(mimeMessageDTO);

        //        try
        //        {
        //            await _smtpClient.SendAsync(mimeMessage);

        //        }
        //        catch (Exception e)
        //        {
        //            return false;
        //        }

        //        await _smtpClient.NoOpAsync();
        //        return true;
        //    }

        //    private MimeMessage FromMimeMessageDTOToMimeMessage(MimeMessageDTO mimeMessageDTO)
        //    {
        //        MimeMessage mailMessage = new MimeMessage();

        //        mailMessage.From.Add(new MailboxAddress(mimeMessageDTO.From.Name, mimeMessageDTO.From.Address));
        //        mimeMessageDTO.To.ToList().ForEach(to => mailMessage.To.Add(new MailboxAddress(to.Name, to.Address)));

        //        if (mimeMessageDTO.Cc is not null)
        //            mimeMessageDTO.Cc.ToList().ForEach(cc => mailMessage.Cc.Add(new MailboxAddress(cc.Name, cc.Address)));

        //        mailMessage.Subject = mimeMessageDTO.Subject;
        //        mailMessage.Body = new TextPart()
        //        {
        //            Text = mimeMessageDTO.Body
        //        };

        //        return mailMessage;
        // }
        // }


        public async Task<string> SendMail(SendFeedbackDTO candidateProfile)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://prod-66.westeurope.logic.azure.com:443/workflows/52202782a2f643ea834a1ccdc6f466ae/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=UQUh9l6XY-7BachYzPCyTfITU_Jqj7lW67t9VfwXfnc");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress);

            var body = JsonSerializer.Serialize(candidateProfile);
            var content = new StringContent(body, Encoding.UTF8, "application/json");
            request.Content = content;
            var response = await MakeRequestAsync(request, client);
            return response;
        }
        private async Task<string> MakeRequestAsync(HttpRequestMessage getRequest, HttpClient client)
        {
            var response = await client.SendAsync(getRequest).ConfigureAwait(false);
            var responseString = string.Empty;
            //var responseToSend = new Response<string>();

            try
            {
                response.EnsureSuccessStatusCode();
                responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                //_logger.LogInformation(responseString);
                //responseToSend = new Response<string> { Success = true, StatusCode = response.StatusCode, Message = responseString };
            }
            catch (HttpRequestException ex)
            {
                //_logger.LogError(ex.Message);
                //responseToSend = new Response<string> { Success = false, StatusCode = response.StatusCode, Message = ex.Message };
                throw new Exception($"An errror occured while sending the mail: {ex.Message}");
            }
            return responseString;

        }
    }
}
