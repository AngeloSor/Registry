﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.DAL.Migrations;
using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Repository
{
    public class FeedbackRepository : AbstractRepository<Feedback>, IFeedbackRepository
    {
        private readonly IMapper _mapper;
        //protected readonly KeycloakAuthDbContext _context;

        public FeedbackRepository(KeycloakAuthDbContext context, IMapper mapper) : base(context)
        {
            //_context = context;
            _mapper = mapper;

        }
        public override async Task<Feedback> Create(Feedback feedback)
        {
            //var feedbackToSave = _mapper.Map<Feedback>(feedbackDTO);
            _context.Feedback.Add(feedback);
            await _context.SaveChangesAsync();
            //var feedbackToSendDTO = _mapper.Map<InterviewFeedbackDTO>(feedbackToSave);
            return feedback;
        }

        public override async Task<bool> Delete(Feedback feedback)
        {
            //var feedbackToDelete = _mapper.Map<Feedback>(feedback);
            _context.Feedback.Remove(feedback);
            return await this.Save();
        }




        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }

        public override async Task<Feedback> GetById(int id)
        {
            var feedback = await _context.Feedback.Include(f => f.FeedbackUser).FirstOrDefaultAsync(f => f.Id == id);
            if (feedback is null) return null;
            return feedback;
        }

        public override async Task<Feedback> Update(Feedback feedback)
        {
            _context.Update(feedback);
            await _context.SaveChangesAsync();
            return feedback;
        }

        public override async Task<Feedback> Find(int id)
        {
            var feedbackEntity = await _context.Feedback.AsNoTracking().FirstOrDefaultAsync(feed => feed.Id == id);
            return feedbackEntity;
        }

        public override bool IsUserAuthorized(string keycloakId, int registryId)
        {
            throw new NotImplementedException();
        }

        public async Task<List<Feedback>> GetByTechnicianId(int id)
        {
            //List<InterviewFeedbackDTO> feedbacks = await _context.Feedback.Where(f => f.FeedbackInterviewerId == id).OrderBy(f => f.DateFeedback).Select(feedback => _mapper.Map<InterviewFeedbackDTO>(feedback)).ToListAsync();
            var feedbacks = await _context.Feedback.Where(f => f.FeedbackInterviewerId == id).OrderByDescending(f => f.DateFeedback).Include(f => f.FeedbackUser).ToListAsync();
            return feedbacks;
        }

        public async Task<List<Feedback>> GetByInterviewId(int id)
        {
            //List<InterviewFeedbackDTO> interviews = await _context.Feedback.Where(i => i.Id == id).Select(interview => _mapper.Map<InterviewFeedbackDTO>(interview)).ToListAsync();
            var interviews = await _context.Feedback.Where(i => i.FeedBackUserId == id).OrderByDescending(f => f.DateFeedback).Include(f =>f.FeedbackUser).ToListAsync();
            return interviews;
        }

        public async Task<List<Feedback>> GetAll()
        {
            //List<InterviewFeedbackDTO> allFeedback = await _context.Feedback.Select(feedback => _mapper.Map<InterviewFeedbackDTO>(feedback)).ToListAsync();
            var allFeedback = await _context.Feedback.OrderByDescending(f => f.DateFeedback).Include( f => f.FeedbackUser).ToListAsync();
            return allFeedback;
        }

        public async Task<bool> FeedbackExists(int id)
        {
            var feedback = await _context.Feedback.AsNoTracking().AnyAsync(feed => feed.Id == id);
            return feedback;
        }

        public Task<List<Feedback>> GetAllInterview()
        {
            throw new NotImplementedException();
        }
    }
}
