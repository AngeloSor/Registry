﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class PivotDigitalSkillRepository : IPivotDigitalSkillRepository
    {
        protected readonly KeycloakAuthDbContext _context;
        public readonly IMapper _mapper;
        public readonly IDefaultDigitalSkillsRepository _digitalSkillsRepository;
        public PivotDigitalSkillRepository(IMapper mapper, IDefaultDigitalSkillsRepository digitalSkillsRepository, KeycloakAuthDbContext context)
        {
            _context = context;
            _mapper = mapper;
            _digitalSkillsRepository = digitalSkillsRepository;
        }

        public async Task<PivotDigitalSkillDTO> Create(PivotDigitalSkillDTO pivotDigitalSkillDTO)
        {
            var digitalSkillInfo = await _digitalSkillsRepository.Get(pivotDigitalSkillDTO.Name);
            var pivotDigitalSkillToSave = new PivotDigitalSkill(pivotDigitalSkillDTO.Name, digitalSkillInfo.DigitalSkillGroup.Name, digitalSkillInfo.DevelopRole, pivotDigitalSkillDTO.StartDate, pivotDigitalSkillDTO.EndDate, pivotDigitalSkillDTO.CVRegistryId);
            _context.PivotDigitalSkills.Add(pivotDigitalSkillToSave);
            await _context.SaveChangesAsync();
            var res = await _context.PivotDigitalSkills.Where(x => x == pivotDigitalSkillToSave).FirstOrDefaultAsync();
            var resDto = _mapper.Map<PivotDigitalSkillDTO>(res);
            return resDto;
        }

        public async Task<bool> Delete(int pivotDigitalSkillDtoId)
        {
            var pivotDigitalSkillToDelete = await _context.PivotDigitalSkills.Where(pivotds => pivotds.Id == pivotDigitalSkillDtoId).FirstOrDefaultAsync();
            _context.PivotDigitalSkills.Remove(pivotDigitalSkillToDelete!);
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }

        public async Task<PivotDigitalSkillDTO> Find(int id)
        {
            var pivotDigitalSkillEntity = await _context.PivotDigitalSkills.FirstOrDefaultAsync(pivotDigitalSkill => pivotDigitalSkill.Id == id);
            PivotDigitalSkillDTO? pivotDigitalSkillDTO = null;
            if (pivotDigitalSkillEntity != null) pivotDigitalSkillDTO = _mapper.Map<PivotDigitalSkillDTO>(pivotDigitalSkillEntity);
            return pivotDigitalSkillDTO;
        }
        public async Task<bool> SkillExists(int id) 
        {
            return await _context.PivotDigitalSkills.AnyAsync(pivotDigitalSkill => pivotDigitalSkill.Id == id);
        }

        public async Task<bool> FindCVRegistry(int id)
        {
            var cvRegistry = await _context.CVRegistry.AsNoTracking().FirstOrDefaultAsync(cvRegistry => cvRegistry.Id == id);
            bool check = cvRegistry is not null;
            return check;
        }

        public async Task<List<PivotDigitalSkillDTO>> GetAll()
        {
            List<PivotDigitalSkillDTO> pivotDigitalSkills = await _context.PivotDigitalSkills.Select(pivotDigitalSkill => _mapper.Map<PivotDigitalSkillDTO>(pivotDigitalSkill)).ToListAsync();
            return pivotDigitalSkills;
        }
        public async Task<PivotDigitalSkillDTO> Update(PivotDigitalSkillDTO pivotDigitalSkillDTO)
        {
            var digitalSkillInfo = await _digitalSkillsRepository.Get(pivotDigitalSkillDTO.Name);
            var pivotDigitalSkillToUpdate = _mapper.Map<PivotDigitalSkill>(pivotDigitalSkillDTO);
            _context.Update(pivotDigitalSkillToUpdate);
            await _context.SaveChangesAsync();
            var pivotDigitalSkillToUpdateDto = _mapper.Map<PivotDigitalSkillDTO>(pivotDigitalSkillToUpdate);
            return pivotDigitalSkillToUpdateDto;
        }

        public bool IsUserAuthorized(string keycloakId, int cvRegistryId)
        {
            var userId = _context.Registry.Where(r => r.IdKeycloak == keycloakId).Select(r => r.Id).FirstOrDefaultAsync().Result;
            var registryId = _context.CVRegistry.Where(c => c.Id == cvRegistryId).Select(r => r.RegistryId).FirstOrDefaultAsync().Result;

            return userId == registryId;
        }

    } 
}
