﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegistryAlten.DAL.Repository;

namespace RegistryAlten.DAL.Repository
{
    public class ConditionRepository : AbstractRepository<Condition>, IConditionRepository
    {
        private readonly IMapper _mapper;
        public ConditionRepository(KeycloakAuthDbContext context, IMapper mapper) : base(context)
        {
            _mapper = mapper;
        }

        public async Task<bool> ConditionExists(int id)
        {

            var condition = await _context.Condition.AsNoTracking().AnyAsync(cond => cond.Id == id);
            return condition;
        }

        public override async Task<Condition> Create(Condition condition)
        {
            //var conditionToSave = _mapper.Map<Condition>(conditionDTO);
            _context.Condition.Add(condition);
            await this.Save();
            //var conditionToSaveDTO = _mapper.Map<ConditionDTO>(conditionToSave);
            return condition;
        }

        public override async Task<bool> Delete(Condition condition)
        {
            //var conditionToDelete = _mapper.Map<Condition>(conditionDTO);
            _context.Remove(condition);
            return await this.Save();
        }

        public async override Task<Condition> Find(int id)
        {
            var conditionEntity = await _context.Condition.AsNoTracking().FirstOrDefaultAsync(cond => cond.Id == id);
            //Condition? conditionDTO = null;
            //if (conditionEntity != null) conditionDTO = _mapper.Map<Condition>(conditionEntity);
            return conditionEntity;
        }

        public async Task<List<Condition>> GetAll()
        {
            var cond = await _context.Condition.ToListAsync();

            //var conditions = await _context.Condition.Select(cond => _mapper.Map<ConditionDTO>(cond)).ToListAsync();
            return cond;
        }

        public override Task<Condition> GetById(int Id)
        {
            throw new NotImplementedException();
        }
        

        public override bool IsUserAuthorized(string keycloakId, int registryId)
        {
            throw new NotImplementedException();
        }

        public override async Task<Condition> Update(Condition condition)
        {
            //var conditionToUpdate = _mapper.Map<Condition>(conditionDTO);
            _context.Update(condition);
            await _context.SaveChangesAsync();
            //var conditionToUpdateDTO = _mapper.Map<ConditionDTO>(conditionToUpdate);
            return condition;

        }
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
