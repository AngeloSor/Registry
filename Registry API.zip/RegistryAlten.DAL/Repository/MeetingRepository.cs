﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;

namespace RegistryAlten.DAL.Repository;

public class MeetingRepository : AbstractRepository<Meeting>, IMeetingRepository
{
    private readonly IMapper _mapper;

    public MeetingRepository(KeycloakAuthDbContext context, IMapper mapper) : base(context)
    {
        _mapper = mapper;
    }
    

    public async override Task<Meeting> Create(Meeting meeting)
    {
        //var meetingToSave = _mapper.Map<Meeting>(meeting);
        _context.Meeting.Add(meeting);
        await _context.SaveChangesAsync();
        //var meetingDTO = _mapper.Map<MeetingDTO>(meetingToSave);
        return meeting;
    }

    public async override Task<bool> Delete(Meeting meeting)
    {
        //var meetingToDelete = _mapper.Map<Meeting>(meetingDTO);
        _context.Meeting.Remove(meeting);
        return await this.Save();
    }

    public async Task<bool> DeleteAll(List<Meeting> meetings)
    {
        //var meetingsToDelete = _mapper.Map<List<Meeting>>(meetingsDTO);
        _context.Meeting.RemoveRange(meetings);
        return await this.Save();
    }

    public async override Task<Meeting> Find(int id)
    {
        var meetingEntity = await _context.Meeting.AsNoTracking().FirstOrDefaultAsync(meeting => meeting.Id == id);
       // MeetingDTO? meetingDTO = null;
       // if (meetingEntity != null) meetingDTO = _mapper.Map<MeetingDTO>(meetingEntity);
        return meetingEntity;
    }

    public async override Task<Meeting> GetById(int id)
    {
        var meeting = await _context.Meeting.FirstOrDefaultAsync(m => m.Id == id);
        if (meeting is null) return null;
        //var response = _mapper.Map<MeetingDTO>(meeting);
        return meeting;
    }

    public async Task<List<Meeting>> GetByInterviewer(string keycloakId)
    {
        var interviewerId = GetUserIdFromKeycloakId(keycloakId);

        //List<MeetingDTO> meetings = await _context.Meeting.AsNoTracking().Where(m => m.InterviewerId == interviewerId)
        //.Select(meeting => _mapper.Map<MeetingDTO>(meeting))
        //.ToListAsync();

        List<Meeting> meetings = await _context.Meeting.AsNoTracking().Where(m => m.InterviewerId == interviewerId).Include(x => x.Interviewer).Include(x => x.User).ToListAsync();

        return meetings;
    }

    public async Task<List<Meeting>> GetByInterviewedUser(string keycloakId)
    {
        var userId = GetUserIdFromKeycloakId(keycloakId);

        //List<MeetingDTO> meetings = await _context.Meeting.AsNoTracking().Where(m => m.UserId == userId)
        //.Select(meeting => _mapper.Map<MeetingDTO>(meeting))
        //.ToListAsync();

        List <Meeting> meetings = await _context.Meeting.AsNoTracking().Where(m => m.UserId == userId).ToListAsync();

        return meetings;
    }

    public async Task<List<Meeting>> GetAll()
    {
        //List<MeetingDTO> meetings = await _context.Meeting.Select(meeting => _mapper.Map<MeetingDTO>(meeting)).ToListAsync();
        List<Meeting> meetings = await _context.Meeting.ToListAsync();

        return meetings;
    }

    public async override Task<Meeting> Update(Meeting meeting)
    {
        //var meetingToUpdate = _mapper.Map<Meeting>(meetingDTO);
        _context.Update(meeting);
        // _context.SaveChangesAsync();
        await this.Save();
        //var meetingToUpdateDto = _mapper.Map<MeetingDTO>(meetingToUpdate);
        return meeting;
    }
    public async Task<bool> ConflictDateCheck(Meeting meeting) 
    { 
        return await _context.Meeting.Where(m => m.InterviewerId==meeting.InterviewerId && m.Date == meeting.Date).AnyAsync();
    }
    public async Task<bool> UserExists(Meeting meeting) 
    {
        return await _context.Registry.AnyAsync(m => m.Id == meeting.UserId);
    }
    public async Task<bool> InterviewerExists(Meeting meeting)
    {
        return await _context.Registry.AnyAsync(m => m.Id == meeting.InterviewerId && m.Technician == true);
    }
    public override bool IsUserAuthorized(string keycloakId, int userId)
    {
        var interviewerId = GetUserIdFromKeycloakId(keycloakId);

        bool check = false;
        if (_context.Meeting.AnyAsync(meeting => meeting.InterviewerId == interviewerId && meeting.UserId == userId).Result) check = true;
        return check;
    }

    private async Task<bool> Save()
    {
        var saved = await _context.SaveChangesAsync();
        return saved >= 0;
    }

    public bool DataTimeCheck(DateTime date)
    {
        var checkTime = false;
        if (date.Hour >= 8 && date.Hour <= 21) 
            checkTime = true;
        
        return checkTime;
        
    }

    public async Task<Meeting> ChangeStatus(Meeting meeting)
    {
        //var meeting = _mapper.Map<Meeting>(meetingDTO);
        if(meeting.IsDeleted) meeting.IsDeleted = false;
 
        else meeting.IsDeleted = true;
        
        _context.Update(meeting);
        await _context.SaveChangesAsync();

        //var meetingUpdatedDto = _mapper.Map<MeetingDTO>(meeting);

        return meeting;

    }

    public async Task<Meeting> GetMeetingById(int? userId)
    {
        var meeting = await _context.Meeting.FirstOrDefaultAsync(m => m.UserId == userId);
        return meeting;
    }
}
