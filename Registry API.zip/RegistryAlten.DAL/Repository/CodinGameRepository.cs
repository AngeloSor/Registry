﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.DAL.Migrations;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Mvc.Internal;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Org.BouncyCastle.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Repository
{
    public class CodinGameRepository : ICodinGameRepository
    {
        private readonly IMapper _mapper;
        protected readonly KeycloakAuthDbContext _context;
        public CodinGameRepository(KeycloakAuthDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Stream> GetAllCampaigns(HttpClient codinGameClient)
        {
            Stream stream = new MemoryStream();
            try
            {
                stream = await codinGameClient.GetStreamAsync("https://www.codingame.eu/assessment/api/v1.1/campaigns");
            }
            catch (Exception ex)
            {
                return stream;
            }
           
            return stream;
        }

        public async Task<string> SendInvitation(HttpClient client, CandidateDTO candidate, int idCampaign)
        {
            string json = JsonConvert.SerializeObject(candidate);
            StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
            string endpoint = $"https://www.codingame.eu/assessment/api/v1.1/campaigns/{idCampaign}/actions/send";
            HttpResponseMessage response;
            var registryId = await _context.Registry.Where(user => user.Email == candidate.candidate_email).Select(user => user.Id).FirstOrDefaultAsync();
            string responseBody;
            if (await _context.CodinGame.AnyAsync(x => x.CandidateEmail == candidate.candidate_email)) return responseBody = "testExist";
            if (!await _context.Registry.AnyAsync(user => user.Id == registryId)) return responseBody = "UserNotExist";
            if (!await _context.Registry.AnyAsync(user => user.Email == candidate.recruiter_email && user.Technician)) return responseBody = "TechnicianNotExist";
            response = await client.PostAsync(endpoint, httpContent);

            if (!response.IsSuccessStatusCode)
            {
                return response.StatusCode.ToString();
            }

            responseBody = await response.Content.ReadAsStringAsync();
            InvitationResponseDTO? invitationResponseDTO = System.Text.Json.JsonSerializer.Deserialize<InvitationResponseDTO>(responseBody);
            
            var invitationToSave = _mapper.Map<CodinGame>(invitationResponseDTO);
            invitationToSave.CandidateEmail = candidate.candidate_email;
            invitationToSave.RegistryId = registryId;

            _context.CodinGame.Add(invitationToSave);
            await _context.SaveChangesAsync();

            return responseBody;
        }
        public async Task<string> GetTestSessionStatus(HttpClient codinGameClient,int registryId)
        {
            
            int? idTest = await _context.CodinGame.Where(codin => codin.RegistryId == registryId).Select(codin => codin.IdTest).FirstOrDefaultAsync();
            if (idTest == 0)
                return "NotFoundRegistryId";
            string url = $"https://www.codingame.eu/assessment/api/v1.1/tests/{idTest}";
            Stream stream = new MemoryStream();
            HttpResponseMessage response;
            CodinGameDTO codinGameDTO = new();
            try 
            {
                stream = await codinGameClient.GetStreamAsync(url);
            }
            catch (Exception ex)
            {
                return "NotFoundTestSessionStatus";
            }
            StreamReader reader = new StreamReader(stream);
            string text = reader.ReadToEnd();
            codinGameDTO = System.Text.Json.JsonSerializer.Deserialize<CodinGameDTO>(text);
            var codinGame = _mapper.Map<CodinGame>(codinGameDTO);
            CodinGame codinGameDB = new();
            try
            {
                codinGameDB = await _context.CodinGame.AsNoTracking().Where(x => x.IdTest == idTest).FirstAsync();
            }
            catch (Exception ex)
            {
                codinGame.RegistryId = registryId;
                _context.Add(codinGame);
                await _context.SaveChangesAsync();
            }
            if (codinGameDB.CandidateEmail is not null && codinGame.Status != codinGameDB.Status)
            {
                codinGame.Id = codinGameDB.Id;
                codinGame.RegistryId = codinGameDB.RegistryId;
                _context.Update(codinGame);
                await _context.SaveChangesAsync();
            }
            return text;
        }

        public async Task<string> GetTestReport(HttpClient codinGameClient, int registryId)
        {
            CodinGame codinGame = await _context.CodinGame.AsNoTracking().Where(codin => codin.RegistryId == registryId).FirstOrDefaultAsync();
            if (codinGame is null) return "NotFoundRegistryId";
            if (codinGame.Status == "waiting" || codinGame.Status == "expired")
            {
                if (codinGame.Status == "expired") return "Expired";
                await GetTestSessionStatus(codinGameClient, registryId);
                codinGame = await _context.CodinGame.Where(codin => codin.RegistryId == registryId).FirstOrDefaultAsync();
                if (codinGame.Status == "waiting") return "Waiting";
                if (codinGame.Status == "expired") return "Expired";
            }
            string url = $"https://www.codingame.eu/assessment/api/v1.1/tests/{codinGame.IdTest}/report";
            byte[] data;
            CodinGameDTO codinGameDTO = new();
            try
            {
                data = await codinGameClient.GetByteArrayAsync(url);
            }
            catch (Exception ex)
            {
                return "NotFoundTestSessionStatus";
            }
            var prova = Convert.ToBase64String(data);
            return prova;
        }

        public bool IsUserAuthorized(string keycloakId, int registryId)
        {
            var techId = GetUserIdFromKeycloakId(keycloakId);

            return _context.Meeting.Where(meeting => meeting.UserId == registryId).Any(meeting => meeting.InterviewerId == techId);
        }

        private int GetUserIdFromKeycloakId(string keycloakId)
        {
            return _context.Registry.Where(r => r.IdKeycloak == keycloakId).Select(r => r.Id).FirstOrDefaultAsync().Result;
        }

        public async Task<List<CodinGameDTO>> GetUserCodinGames(int userId)
        {
            List<CodinGameDTO> codingames = await _context.CodinGame.AsNoTracking().Where(c => c.RegistryId == userId)
                                .Select(codingame => _mapper.Map<CodinGameDTO>(codingame))
                                .ToListAsync();
            return codingames;
        }

        public async Task<bool> DeleteAll(List<CodinGameDTO> codingamesDTO)
        {
            var codingamesToDelete = _mapper.Map<List<CodinGame>>(codingamesDTO);
            _context.CodinGame.RemoveRange(codingamesToDelete);
            return await this.Save();
        }

        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }

        public async Task<List<CampaignDTO>> GetCampaigns(HttpClient codinGameClient, string tag)
        {
            //List<CampaignCategory> campaignCategories = new List<CampaignCategory>();
            List<Campaign> campaigns = new List<Campaign>();
            try
            {
                Stream stream = await codinGameClient.GetStreamAsync("https://www.codingame.eu/assessment/api/v1.1/campaigns");
                var streamReader = new StreamReader(stream);
                var jsonReader = new JsonTextReader(streamReader);
                campaigns = JsonSerializer.CreateDefault().Deserialize<List<Campaign>>(jsonReader);
                //var codinGame = campaigns.Select(cond => _mapper.Map<CampaignDTO>(cond)).ToList();
                // Map campaign types to categories
                foreach (Campaign campaign in campaigns)
                {
                    string[] nameParts = campaign.Name.Split(" - ");
                    string category = nameParts[0];
                    switch (category.ToUpper())
                    {
                        case "FE":
                            campaign.Category = CampaignCategory.FE;
                            break;
                        case "BE":
                            campaign.Category = CampaignCategory.BE;
                            break;
                        case "FS":
                            campaign.Category = CampaignCategory.FS;
                            break;
                        default:
                            campaign.Category = CampaignCategory.ALTRO;
                            break;
                    }
                }

                //campaignCategories = campaigns.Select(campaign => campaign.Category).ToList();
            }
            catch (Exception ex)
            {
                // Handle exception here
            }

            List<Campaign> filteredCampaigns = campaigns.Where(c => c.Category.ToString().ToUpper() == tag.ToUpper()).ToList();
            //var codinGame = campaigns.Select(cond => _mapper.Map<CampaignDTO>(cond)).ToList();
            //List<Campaign> filteredCampaigns = campaigns.Where(c => c.Category.ToString().ToUpper() == tag.ToUpper()).ToList();
            var codinGame = filteredCampaigns.Select(cond => _mapper.Map<CampaignDTO>(cond)).ToList();
            return codinGame;
        }
    }
}
