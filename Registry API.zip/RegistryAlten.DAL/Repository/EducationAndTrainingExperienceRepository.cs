﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class EducationAndTrainingExperienceRepository : AbstractRepository<EducationAndTrainingExperienceDTO>, ISectionCVRegistryRepository<EducationAndTrainingExperienceDTO>
    {
        private readonly IMapper _mapper;
        public EducationAndTrainingExperienceRepository (KeycloakAuthDbContext context, IMapper mapper) : base(context)
        { 
            _mapper = mapper;
        }
        public override async Task<EducationAndTrainingExperienceDTO> Create(EducationAndTrainingExperienceDTO educationAndTrainingExperienceDTO)
        {
            var educationAndTrainingExperienceToSave = _mapper.Map<EducationAndTrainingExperience>(educationAndTrainingExperienceDTO);
            _context.EducationAndTrainingExperience.Add(educationAndTrainingExperienceToSave);
            await _context.SaveChangesAsync();
            var educationAndTrainingExperienceToSaveDTO = _mapper.Map<EducationAndTrainingExperienceDTO>(educationAndTrainingExperienceToSave);
            return educationAndTrainingExperienceToSaveDTO;
        }
        public override async Task<EducationAndTrainingExperienceDTO> GetById(int id)
        {
            var educationAndTrainingExperience = await _context.EducationAndTrainingExperience.FirstOrDefaultAsync(dbEducationAndTrainingExperience => dbEducationAndTrainingExperience.Id == id);
            if (educationAndTrainingExperience is null) return null;
            var educationAndTrainingExperienceResponse = _mapper.Map<EducationAndTrainingExperienceDTO>(educationAndTrainingExperience);
            return educationAndTrainingExperienceResponse;
        }
        public async Task<List<EducationAndTrainingExperienceDTO>> GetAll()
        {
            List<EducationAndTrainingExperienceDTO> educationAndTrainingExperiences = await _context.EducationAndTrainingExperience.Select(educationAndTrainingExperience => _mapper.Map<EducationAndTrainingExperienceDTO>(educationAndTrainingExperience)).ToListAsync();
            return educationAndTrainingExperiences;
        }
        public override async Task<EducationAndTrainingExperienceDTO> Update(EducationAndTrainingExperienceDTO educationAndTrainingExperienceDTO)
        {
            var educationAndTrainingExperienceToUpdate = _mapper.Map<EducationAndTrainingExperience>(educationAndTrainingExperienceDTO);
            _context.Update(educationAndTrainingExperienceToUpdate);
            await _context.SaveChangesAsync();
            var educationAndTrainingExperienceToUpdateDTO = _mapper.Map<EducationAndTrainingExperienceDTO>(educationAndTrainingExperienceToUpdate);
            return educationAndTrainingExperienceToUpdateDTO;
        }
        public override async Task<bool> Delete(EducationAndTrainingExperienceDTO educationAndTrainingExperienceDTO)
        {
            var educationAndTrainingExperienceToDelete = _mapper.Map<EducationAndTrainingExperience>(educationAndTrainingExperienceDTO);
            _context.Remove(educationAndTrainingExperienceToDelete);
            return await this.Save();
        }
        public override async Task<EducationAndTrainingExperienceDTO> Find(int id)
        {
            var educationAndTrainingExperienceEntity = await _context.EducationAndTrainingExperience.AsNoTracking().FirstOrDefaultAsync(educationAndTrainingExperience => educationAndTrainingExperience.Id == id);
            EducationAndTrainingExperienceDTO? educationAndTrainingExperienceDTO = null;
            if (educationAndTrainingExperienceEntity != null) educationAndTrainingExperienceDTO = _mapper.Map<EducationAndTrainingExperienceDTO>(educationAndTrainingExperienceEntity);
            return educationAndTrainingExperienceDTO;
        }
        public override bool IsUserAuthorized(string keycloakId, int cvRegistryId)
        {
            var userId = GetUserIdFromKeycloakId(keycloakId);
            int registryId = _context.CVRegistry.Where(c => c.Id == cvRegistryId).Select(r => r.RegistryId).FirstOrDefaultAsync().Result;

            return registryId == userId;
        }

        public async Task<bool> Exists(int id)
        {
            return await _context.EducationAndTrainingExperience.AnyAsync(educationAndTrainingExperience => educationAndTrainingExperience.Id == id);
        }
        public async Task<bool> FindCVRegistry(int id)
        {
            var cvRegistry = await _context.CVRegistry.AsNoTracking().FirstOrDefaultAsync(cvRegistry => cvRegistry.Id == id);
            bool check = cvRegistry is not null ? true : false;
            return check;
        }
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
