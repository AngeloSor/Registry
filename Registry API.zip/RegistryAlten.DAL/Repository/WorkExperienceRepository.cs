﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class WorkExperienceRepository : AbstractRepository<WorkExperienceDTO> , ISectionCVRegistryRepository<WorkExperienceDTO>
    {
        private readonly IMapper _mapper;
        public WorkExperienceRepository(KeycloakAuthDbContext context,IMapper mapper) : base(context)
        {
            _mapper = mapper;
        }
        public override async Task<WorkExperienceDTO> Create(WorkExperienceDTO workExperienceDTO)
        {
            var workExperienceToSave = _mapper.Map<WorkExperience>(workExperienceDTO);
            _context.WorkExperience.Add(workExperienceToSave);
            await _context.SaveChangesAsync();
            var workExperienceToSaveDTO = _mapper.Map<WorkExperienceDTO>(workExperienceToSave);
            return workExperienceToSaveDTO;
        }
        public override async Task<WorkExperienceDTO> GetById(int id)
        {
            var workExperience = await _context.WorkExperience.FirstOrDefaultAsync(workExperience => workExperience.Id == id);
            if (workExperience is null) return null;
            var workExperienceResponse = _mapper.Map<WorkExperienceDTO>(workExperience);
            return workExperienceResponse;
        }
        public async Task<List<WorkExperienceDTO>> GetAll()
        {
            List<WorkExperienceDTO> workExperience = await _context.WorkExperience.Select(workExperience => _mapper.Map<WorkExperienceDTO>(workExperience)).ToListAsync();
            return workExperience;
        }
        public override async Task<WorkExperienceDTO> Update(WorkExperienceDTO workExperienceDTO)
        {
            var workExperienceToUpdate = _mapper.Map<WorkExperience>(workExperienceDTO);
            _context.Update(workExperienceToUpdate);
            await _context.SaveChangesAsync();
            var workExperienceToUpdateDto = _mapper.Map<WorkExperienceDTO>(workExperienceToUpdate);
            return workExperienceToUpdateDto;
        }
        public override async Task<bool> Delete(WorkExperienceDTO workExperienceDTO)
        {
            var workExperienceToDelete = _mapper.Map<WorkExperience>(workExperienceDTO);
            _context.Remove(workExperienceToDelete);
            return await this.Save();
        }
        public override async Task<WorkExperienceDTO> Find(int id)
        {
            var workExperienceEntity = await _context.WorkExperience.AsNoTracking().FirstOrDefaultAsync(workExperience => workExperience.Id == id);
            WorkExperienceDTO? workExperienceDTO = null;
            if (workExperienceEntity != null) workExperienceDTO = _mapper.Map<WorkExperienceDTO>(workExperienceEntity);
            return workExperienceDTO;
        }

        public override bool IsUserAuthorized(string keycloakId, int cvRegistryId)
        {
            var userId = GetUserIdFromKeycloakId(keycloakId);
            int registryId = _context.CVRegistry.Where(c => c.Id == cvRegistryId).Select(r => r.RegistryId).FirstOrDefaultAsync().Result;

            return registryId == userId;
        }

        public async Task<bool> Exists(int id)
        {
            return await _context.WorkExperience.AnyAsync(workExperience => workExperience.Id == id);
        }
        public async Task<bool> FindCVRegistry(int id)
        {
            var cvRegistry = await _context.CVRegistry.AsNoTracking().FirstOrDefaultAsync(cvRegistry => cvRegistry.Id == id);
            bool check = cvRegistry is not null;
            return check;
        }
        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }
    }
}
