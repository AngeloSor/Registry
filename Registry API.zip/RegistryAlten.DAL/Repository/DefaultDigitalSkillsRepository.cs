﻿using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;

namespace RegistryAlten.DAL.Repository
{
    public class DefaultDigitalSkillsRepository: IDefaultDigitalSkillsRepository
    {
        private readonly KeycloakAuthDbContext _context;
        private readonly IDigitalSkillGroupsRepository _digitalSkillGroupsRepository;
        public DefaultDigitalSkillsRepository(KeycloakAuthDbContext context,
            IDigitalSkillGroupsRepository digitalSkillGroupsRepository)
        {
            _context = context;
            _digitalSkillGroupsRepository = digitalSkillGroupsRepository;
        }
        public async Task<List<DigitalSkillGroupDTO>> Create(DigitalSkillGroup digitalSkillGroup, DefaultDigitalSkillDTO digitalSkill)
        {
            var newSkill = new DefaultDigitalSkill(digitalSkill.Name, digitalSkill.DevelopeRole, digitalSkillGroup);
            _context.DigitalSkills.Add(newSkill);
            _context.SaveChanges();
            return await _digitalSkillGroupsRepository.GetAll();
        }
        public async Task<DefaultDigitalSkill> Get(string name)
        {
            var res = await _context.DigitalSkills.Where(x => x.Name == name).Include(c => c.DigitalSkillGroup).FirstOrDefaultAsync();
            return res!;
        }
        public async Task<List<DefaultDigitalSkill>> GetAll()
        {
            var res = await _context.DigitalSkills.Include(c => c.DigitalSkillGroup).ToListAsync();
            return res;
        }
        public async Task<List<DigitalSkillGroupDTO>> Update(DefaultDigitalSkill existingDigitalSkill, SkillDTO digitalSkill)
        {
            
            existingDigitalSkill!.Name = digitalSkill.Name;
            existingDigitalSkill.DevelopRole = digitalSkill.DevelopRole;
            await _context.SaveChangesAsync();
            return await _digitalSkillGroupsRepository.GetAll();
        }
        public async Task<bool> Delete(DefaultDigitalSkill existingDigitalSkill)
        {
            var res = false;
            _context.DigitalSkills.Remove(existingDigitalSkill);
            _context.SaveChanges();
            if(await Get(existingDigitalSkill.Name) == null)
            {
                res = true;
            }
            return res;
        }

    }
}
