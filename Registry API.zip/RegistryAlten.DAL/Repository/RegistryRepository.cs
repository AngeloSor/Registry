﻿using AutoMapper;
using RegistryAlten.DAL.Data;
using RegistryAlten.DAL.Entities;
using RegistryAlten.DAL.Interface;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;
using System.Collections.Immutable;

namespace RegistryAlten.DAL.Repository
{
    public class RegistryRepository : AbstractRepository<Registry>, IRegistryRepository
    {
        private readonly IMapper _mapper;
        private readonly IMeetingRepository _meetingRepository;
        private readonly ICVRegistryRepository _cvregistryRepository;
        public RegistryRepository(KeycloakAuthDbContext context, IMeetingRepository meetingRepository, ICVRegistryRepository cvregistryRepository, IMapper mapper) : base(context)
        {
            _mapper = mapper;
            _meetingRepository = meetingRepository;
            _cvregistryRepository = cvregistryRepository;
        }
        public override async Task<Registry> GetById(int id)
        {
            var user = await _context.Registry.FirstOrDefaultAsync(dbUser => dbUser.Id == id);
            if (user is null) return null;
            //var userResponse = _mapper.Map<RegistryDTO>(user);
            return user;
        }
        public async Task<Registry> GetByIdWithPicture(int id)
        {
            //var user = await _context.Registry.Include(dbUser => dbUser.PictureProfile).Where(dbUser => dbUser.Id == id)
            //.Select(dbUser => _mapper.Map<RegistryWithPictureDTO>(dbUser)).FirstOrDefaultAsync();
            var user = await _context.Registry.Include(dbUser => dbUser.PictureProfile).Where(dbUser => dbUser.Id == id).FirstOrDefaultAsync();
            if (user is null) return null;
            return user;
        }
        public async Task<Registry> GetByEmail(string email)
        {
            var user = await _context.Registry.AsNoTracking().Where(user => user.Email == email).FirstOrDefaultAsync();
            if (user is null) return null;
            //var userResponse = _mapper.Map<RegistryDTO>(user);
            return user;
        }
        public override async Task<Registry> Create(Registry registry)
        {
            //var userToSave = _mapper.Map<Registry>(registryDTO);
            if(registry.Technician == true) {
                registry.ConditionId = 2;
            }
            _context.Registry.Add(registry);
            await _context.SaveChangesAsync();
            ///var userToSaveDTO = _mapper.Map<RegistryDTO>(userToSave);
            return registry;
        }
        public async Task<List<Registry>> GetAll(int pageNumber, int pageSize, bool isDeleted)
        {
            //var usersRegistry = await _context.Registry.Select(user => new RegistryCountCVDTO(_mapper.Map<RegistryDTO>(user), user.CVRegistry.CVFiles.Count, user.Condition.Name)).ToListAsync();
            var usersRegistry = await _context.Registry.Include(x => x.CVRegistry.CVFiles)
                .Include(x => x.Condition)
                .Include(x => x.CodinGame)
                .OrderBy(x => x.ConditionId)
                .ThenBy(x => x.Surname).ThenBy(x => x.Name)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
            if (!isDeleted) usersRegistry = usersRegistry.Where(u => !u.IsDeleted).ToList();
            else usersRegistry = usersRegistry.Where(u => u.IsDeleted).ToList();
            return usersRegistry;
        }
        public async Task<List<Registry>> GetAllCG(bool isDeleted)
        {
            //var usersRegistry = await _context.Registry.OrderBy(x => x.ConditionId).ThenBy(x => x.Surname).ThenBy(x => x.Name).Select(user => new RegistryCGStatusDTO(_mapper.Map<RegistryDTO>(user), user.CVRegistry.CVFiles.Count, user.Condition.Name, user.CodinGame.Status)).ToListAsync();
            var usersRegistry = await _context.Registry.Include(x => x.CVRegistry.CVFiles)
                .Include(x=> x.Condition)
                .OrderBy(x => x.ConditionId)
                .ThenBy(x => x.Surname).ThenBy(x => x.Name)
                .ToListAsync();
            if (!isDeleted) usersRegistry = usersRegistry.Where(u => !u.IsDeleted).ToList();
            else usersRegistry = usersRegistry.Where(u => u.IsDeleted).ToList();
            return usersRegistry;
        }
        public async Task<List<Registry>> GetAllInterview()
        {
            //var usersRegistry = await _context.Registry.OrderBy(u => u.Surname).ThenBy(u =>u.Name).Where(u => u.Condition.Name == "Pronto per il colloquio").Select(user => new RegistryCountCVDTO((_mapper.Map<RegistryDTO>(user)), user.CVRegistry.CVFiles.Count, user.Condition.Name)).ToListAsync();
            var usersRegistry = await _context.Registry
                .Include(x => x.CVRegistry.CVFiles)
                .Include(x => x.Condition)
                .OrderBy(u => u.Surname)
                .ThenBy(u => u.Name)
                .Where(u => u.Condition.Name == "Pronto per il colloquio")
                .ToListAsync();
            return usersRegistry;
        }
        public async Task<List<Registry>> GetAllTechnician()
        {
            //var usersRegistry = await _context.Registry.OrderBy(u => u.Surname).ThenBy(u => u.Name).Where(u => u.Technician == true).Select(user => new RegistryCountCVDTO(_mapper.Map<RegistryDTO>(user), user.CVRegistry.CVFiles.Count, user.Condition.Name)).ToListAsync();
            var usersRegistry = await _context.Registry
                .Include(x => x.CVRegistry.CVFiles)
                .Include(x => x.Condition)
                .OrderBy(u => u.Surname)
                .ThenBy(u => u.Name)
                .Where(u => u.Technician == true)
                .ToListAsync();
            return usersRegistry;
        }

        public async Task<List<Registry>> GetAllTechnicianPage(int pageSize, int pageNumber)
        {
            //var usersRegistry = await _context.Registry.OrderBy(u => u.Surname).ThenBy(u => u.Name).Where(u => u.Technician == true).Select(user => new RegistryCountCVDTO(_mapper.Map<RegistryDTO>(user), user.CVRegistry.CVFiles.Count, user.Condition.Name)).ToListAsync();
            var usersRegistry = await _context.Registry
                .Include(x => x.CVRegistry.CVFiles)
                .Include(x => x.Condition)
                .OrderBy(u => u.Surname)
                .ThenBy(u => u.Name)
                .Where(u => u.Technician == true)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
            return usersRegistry;
        }

        public override async Task<Registry> Update(Registry registry)
        {
            //var userToUpdate = _mapper.Map<Registry>(registryDTO);
            _context.Update(registry);
            await _context.SaveChangesAsync();
            //var userToUpdateDTO = _mapper.Map<RegistryDTO>(userToUpdate);
            return registry;
        }

        public override async Task<bool> Delete(Registry registry)
        {
            //var userToDelete = _mapper.Map<Registry>(registryDTO);
            registry.IsDeleted = true;
            _context.Update(registry);
            return await this.Save();
        }
        public async Task<bool> Rehabilitate(Registry registry)
        {
            //var userToRehabilitate = _mapper.Map<Registry>(registryDTO);
            registry.IsDeleted = false;
            _context.Update(registry);
            return await this.Save();
        }
        public async Task<int> RegistryExists(string email)
        {
            return await _context.Registry.AsNoTracking().Where(user => user.Email == email).Select(user => user.Id).FirstOrDefaultAsync();
        }
        public async Task<bool> ConditionExists(int id)
        {
            return await _context.Condition.AnyAsync(condition => condition.Id == id);
        }
        public async override Task<Registry> Find(int id)
        {
            var userEntity = await _context.Registry.AsNoTracking().FirstOrDefaultAsync(user => user.Id == id);
            //RegistryDTO? userDTO = null;
            // if (userEntity != null) userDTO = _mapper.Map<RegistryDTO>(userEntity);
            return userEntity;
        }

        public override bool IsUserAuthorized(string keycloakId, int repositoryId)
        {
            var userId = GetUserIdFromKeycloakId(keycloakId);
            bool check = false;
            if (repositoryId == userId) check = true;
            if (_context.Meeting.AnyAsync(meeting => meeting.InterviewerId == userId && meeting.UserId == repositoryId).Result) check = true;
            return check;
        }

        private async Task<bool> Save()
        {
            var saved = await _context.SaveChangesAsync();
            return saved >= 0;
        }

        private int GetRegistryIdFromKeycloakId(string keycloakId)
        {
            return _context.Registry.Where(r => r.IdKeycloak == keycloakId).Select(r => r.Id).FirstOrDefaultAsync().Result;
        }

        public async Task<bool> DeletePermanent(Registry registry)
        {
            //var userToDeletePermanent = _mapper.Map<Registry>(registryDTO);
            _context.Registry.Remove(registry);

            return await this.Save();
        }

        public async Task<bool> SetCandidateToFirstInterview(int id)
        {
            var findUser = await Find(id);
            if (findUser is null)
            {
                return false;
            }
            findUser.ConditionId = 4;
            //var userToSave = _mapper.Map<Registry>(findUser);


            _context.Update(findUser);

            return await this.Save();
        }

        public async Task<bool> IsTechnician(int id)
        {
            var findUser = await Find(id);
            return findUser.Technician;

        }
    }
}
