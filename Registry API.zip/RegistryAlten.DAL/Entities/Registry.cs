﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class Registry
    {
        public int Id { get; set; }
        public string IdKeycloak { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public DateTime? BirthDate { get; set; }
        public string? FiscalCode { get; set; }
        public string? City { get; set; }
        public string? Province { get; set; }
        public string? Street { get; set; }
        public string? StreetNumber { get; set; }
        public int? ZIPCode { get; set; }
        public GenderType? Gender { get; set; }
        public string? BusinessManager { get; set; }
        public bool IsDeleted { get; set; }
        public bool Technician { get; set; }
        public int ConditionId { get; set; }
        [InverseProperty("Interviewer")]
        public virtual IList<Meeting>? MeetingsInterviewer { get; set; }
        [InverseProperty("User")]
        public virtual IList<Meeting>? MeetingsUser { get; set; }
        [InverseProperty("FeedbackInterviewer")]
        public virtual IList<Feedback>? FeedbacksInterviewer { get; set; }
        [InverseProperty("FeedbackUser")]
        public virtual IList<Feedback>? FeedbacksUser { get; set; }
        public virtual CVRegistry CVRegistry { get; set; }
        public virtual PictureProfile PictureProfile { get; set; }
        public virtual Condition Condition { get; set; }
        public virtual CodinGame CodinGame { get; set; }

        public enum GenderType
        {
            Male,
            Female,
            NotSpecified
        }

    }
}
