﻿namespace RegistryAlten.DAL.Entities
{
    public class EducationAndTrainingExperience
    {
        public int Id { get; set; }
        public string QualificationAwarded { get; set; }
        public string OrganisationOrSchool { get; set; }
        public string? Address { get; set; }
        public int VotesObtained { get; set; }
        public virtual CVRegistry CVRegistry { get; set; }
        public int CVRegistryId { get; set; }
    }
}
