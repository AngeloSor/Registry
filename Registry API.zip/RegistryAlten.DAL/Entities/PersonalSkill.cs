﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class PersonalSkill
    {
        public int Id { get; set; }
        public string Property { get; set; }
        public string Value { get; set; }
        public virtual CVRegistry CVRegistry { get; set; }
        public int CVRegistryId { get; set; }
    }
}
