﻿using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Entities
{
    public class DefaultDigitalSkill
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DevelopRoleType DevelopRole { get; set; }
        public DigitalSkillGroup DigitalSkillGroup { get; set; }
        public int DigitalSkillGroupId { get; set; }
        private DefaultDigitalSkill(string name, DevelopRoleType developRole)
        {
            Name = name;
            DevelopRole = developRole;
        }
        public DefaultDigitalSkill(string name, DevelopRoleType developRole, DigitalSkillGroup digitalSkillGroup) : this(name, developRole)
        {
            DigitalSkillGroup = digitalSkillGroup;
        }
    }
}