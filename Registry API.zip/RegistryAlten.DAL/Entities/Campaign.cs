﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class Campaign
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string[]? Languages { get; set; }
        public bool Archived { get; set; }
        public bool Pinned { get; set; }
        public CampaignCategory? Category { get; set; }
    }

    public enum CampaignCategory
    {
        FE,
        BE,
        FS,
        ALTRO
    }

}
