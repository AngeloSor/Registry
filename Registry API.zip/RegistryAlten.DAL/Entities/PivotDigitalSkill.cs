﻿using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Entities
{
    public class PivotDigitalSkill
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public DevelopRoleType DevelopRole { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int CVRegistryId { get; set; }
        public virtual CVRegistry CVRegistry { get; set; }

        private PivotDigitalSkill(string name, string category, DevelopRoleType developRole, DateTime startDate, DateTime endDate)
        {
            Name = name;
            Category = category;
            DevelopRole = developRole;
            StartDate = startDate;
            EndDate = endDate;
        }

        public PivotDigitalSkill(string name, string category, DevelopRoleType developRole, DateTime startDate, DateTime endDate, int cvRegistryId) : 
                                this(name, category, developRole, startDate, endDate)
        {
            CVRegistryId = cvRegistryId;
        }

        public PivotDigitalSkill()
        {}
    }
}
