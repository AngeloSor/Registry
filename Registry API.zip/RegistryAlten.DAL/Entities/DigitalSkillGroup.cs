﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class DigitalSkillGroup
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public IList<DefaultDigitalSkill> DigitalSkills { get; set; }
        public DigitalSkillGroup(string name)
        {
            Name = name;
        }
        public DigitalSkillGroup(string name, List<DefaultDigitalSkill> digitalSkills) : this(name)
        {
            DigitalSkills = digitalSkills;
        }
    }
}
