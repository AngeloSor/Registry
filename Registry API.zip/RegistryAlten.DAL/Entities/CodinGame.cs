﻿using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class CodinGame
    {
        
        public int Id { get; set; }
        public string? Status { get; set; }
        public string? Url { get; set; }
        public string? Report { get; set; }
        public int IdTest { get; set; }
        public int? CampaignId { get; set; }
        public string? CandidateName { get; set; }
        public string CandidateEmail { get; set; }
        public string? Tags { get; set; }
        public long? SendTime { get; set; }
        public long? StartTime { get; set; }
        public long? EndTime { get; set; }
        public string? TestUrl { get; set; }
        public string? CandidateLanguage { get; set; }
        public int? RegistryId { get; set; }
        public virtual Registry Registry { get; set; }
    }
}
