﻿using AutoMapper.Configuration.Annotations;
using Microsoft.AspNetCore.Mvc;
using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
  
        //public enum Esito
        //{
        //    Negativo,
        //    Positivo
        //}

        public enum Esperienza
        {
        Stagista,
        Apprendista,
        Junior,
        Medior,
        Senior,
        Architect
        }

        public enum Ruolo
        {
            Frontend,
            Backend,
            FullStack
        }

        public enum Valutazione
        {
            A,
            B,
            C,
            D
        }

    public class Feedback
    {
        public int Id { get; set; }

        public PivotDigitalSkillDTO PivotDigitalSkillDTO;
        //public MimeMessageDTO MailMessage { get; set; }
        public bool IsPassed { get; set; }
        public Esperienza Esperienza { get; set; }
        public Ruolo Ruolo { get; set; }

        public string Conclusioni { get; set; }

        public Valutazione DesignEvaluation { get; set; }
        public Valutazione CodeEvaluation { get; set; }
        public Valutazione ArchitectureEvaluation { get; set; }



        //Input
        //public IList<DigitalSkillFeedback> DigitalSkillFeedback { get; set; }

        public int? FeedbackInterviewerId { get; set; }
        [Ignore]
        public Registry FeedbackInterviewer { get; set; }

        public int? FeedBackUserId { get; set; }
        [Ignore]
        public Registry FeedbackUser { get; set; }

        public DateTime? DateFeedback { get; set; } = DateTime.Now;
    }
}
