﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class CVRegistry
    {
        public int Id { get; set; } 
        public int RegistryId { get; set; }
        public virtual IList<CVFile> CVFiles { get; set; } 
        public virtual Registry Registry { get; set; }
        public virtual IList<EducationAndTrainingExperience> EducationAndTrainingExperiences { get; set; }
        public virtual IList<WorkExperience> WorkExperiences { get; set; }
        public virtual IList<PersonalSkill> PersonalSkills { get; set; }
        public virtual IList<PivotDigitalSkill> PivotDigitalSkills { get; set; }
    }
}
