﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class PictureProfile
    {
        public int Id { get; set; }
        public string ? Picture { get; set; }
        public int RegistryId { get; set; }
        public virtual Registry Registry {get; set; }
    }
}
