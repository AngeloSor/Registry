﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class WorkExperience
    {
        public int Id { get; set; }
        public string? WorkingPosition { get; set; }
        public string? Agency { get; set; }
        public string? Location { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public virtual CVRegistry CVRegistry { get; set; }
        public int CVRegistryId { get; set; }
    }
}
