﻿using AutoMapper.Configuration.Annotations;
using Microsoft.AspNetCore.Mvc;
using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Entities
{
    public class SendFeedback
    {
        //public MimeMessageDTO MailMessage { get; set; }
        public List<string>? To { get; set; }
        public List<string>? Cc { get; set; }
        public string InterviewerName { get; set; }
        public string InterviewerSurname { get; set; }
        public string UserName { get; set; }
        public string UserSurname { get; set; }
        public bool IsPassed { get; set; }
    }
}
