﻿using AutoMapper.Configuration.Annotations;

namespace RegistryAlten.DAL.Entities
{
    public class Meeting
    {
        public int Id { get; set; }

        public int? InterviewerId { get; set; }
        [Ignore]
        public virtual Registry Interviewer { get; set; }

        public int? UserId { get; set; }
        [Ignore]
        public virtual Registry User { get; set; }
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
        public bool IsDeleted { get; set; }
    }
}
