﻿using System.Net.Mail;
using AutoMapper;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Mvc;
using RegistryAlten.DAL.Entities;

namespace RegistryAlten.DAL.Interface
{
    public interface IEmailSender
    {
        //public Task<bool> SendEmailAsync(MimeMessageDTO message);
        public Task<string> SendMail(SendFeedbackDTO candidateProfile);
        
    }
}
