﻿namespace RegistryAlten.DAL.Interface
{
    public interface IRepository<T> : IAuthorizable
    {
        public Task<T> Create(T dto);
        public Task<T> GetById(int id);
        public Task<T> Update(T dto);
        public Task<bool> Delete(T dto);
        public Task<T> Find(int id);
    }
}
