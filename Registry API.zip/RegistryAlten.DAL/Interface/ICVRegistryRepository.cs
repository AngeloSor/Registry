﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Interface
{
    public interface ICVRegistryRepository : ICVAndInheritedRepository<CVRegistry>
    {
        public Task<bool> FindRegistry(int id);
        public Task<bool> Exists(int id);
        public Task<CVRegistry> GetByIdRegistry(int id);
        public Task<List<CVRegistry>> GetAllUserRegistry(int userId);
        public Task<bool> DeleteAll(List<CVRegistry> cvDTO);
    }
}
