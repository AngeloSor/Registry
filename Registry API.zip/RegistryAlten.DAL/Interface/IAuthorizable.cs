﻿using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Interface;

public interface IAuthorizable
{
    public bool IsUserAuthorized(string keycloakId, int registryId);
}
