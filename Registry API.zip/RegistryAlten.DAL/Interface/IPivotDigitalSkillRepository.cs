﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Interface
{
    public interface IPivotDigitalSkillRepository
    {
        public Task<PivotDigitalSkillDTO> Create(PivotDigitalSkillDTO pivotDigitalSkillDTO);
        public Task<List<PivotDigitalSkillDTO>> GetAll();
        public Task<bool> FindCVRegistry(int id);
        public Task<PivotDigitalSkillDTO> Find(int id);
        public Task<bool> SkillExists(int id);
        public Task<PivotDigitalSkillDTO> Update(PivotDigitalSkillDTO pivotDigitalSkillDTO);
        public Task<bool> Delete(int pivotDigitalSkillDtoId);
        public bool IsUserAuthorized(string keycloakId, int registryId);
    }
}
