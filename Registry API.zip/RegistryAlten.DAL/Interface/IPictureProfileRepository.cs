﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Interface
{
    public interface IPictureProfileRepository : ICVAndInheritedRepository<PictureProfile>
    {
        public Task<bool> FindRegistry(int id);
        public Task<bool> Exists(int id);
    }
}
