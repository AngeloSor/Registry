﻿using RegistryAlten.SHARED;
using Org.BouncyCastle.Asn1.Mozilla;
using RegistryAlten.DAL.Entities;

namespace RegistryAlten.DAL.Interface
{
    public interface IRegistryRepository : IRepository<Registry>
    {
        public Task<int> RegistryExists(string email);
        public Task<List<Registry>> GetAll(int pageSize, int pageNumber, bool isDeleted);
        public Task<List<Registry>> GetAllCG(bool isDeleted);
        public Task<Registry> GetByEmail(string email);
        public Task<Registry> GetByIdWithPicture(int id);
        public Task<List<Registry>> GetAllInterview();
        public Task<List<Registry>> GetAllTechnician();

        public Task<List<Registry>> GetAllTechnicianPage(int pageSize, int pageNumber);
        public Task<bool> Rehabilitate(Registry registry);
        public Task<bool> ConditionExists(int id);
        public Task<bool> DeletePermanent(Registry registry);

        public Task<bool> SetCandidateToFirstInterview(int id);

        public Task<bool> IsTechnician(int id);
    }
}
