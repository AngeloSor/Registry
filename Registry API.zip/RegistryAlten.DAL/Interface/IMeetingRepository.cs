﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Interface
{
    public interface IMeetingRepository : IRepository <Meeting>
    {
        public Task<Meeting> GetMeetingById (int? UserId);
        public Task<List<Meeting>> GetByInterviewer(string keycloakId);
        public Task<List<Meeting>> GetByInterviewedUser(string keycloakId);
        public Task<List<Meeting>> GetAll();
        public Task<bool> ConflictDateCheck(Meeting meeting);
        public Task<bool> UserExists(Meeting meeting);
        public Task<bool> InterviewerExists(Meeting meeting);
        public bool DataTimeCheck(DateTime date);
        public Task<Meeting> ChangeStatus(Meeting meeting);
        public Task<bool> DeleteAll(List<Meeting> meetings);
    }
}