﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Interface
{
    public interface ICodinGameRepository : IAuthorizable
    {
        public Task<Stream> GetAllCampaigns(HttpClient codinGameClient);

        public Task<List<CampaignDTO>> GetCampaigns(HttpClient codinGameClient, string tag);
        public Task<String> SendInvitation(HttpClient client, CandidateDTO candidate, int idCampaign);
        public Task<string> GetTestSessionStatus(HttpClient codinGameClient, int id);
        public Task<string> GetTestReport(HttpClient codinGameClient, int id);
        public Task<List<CodinGameDTO>> GetUserCodinGames(int userId);
        public Task<bool> DeleteAll(List<CodinGameDTO> codingamesDTO);

    }
}
