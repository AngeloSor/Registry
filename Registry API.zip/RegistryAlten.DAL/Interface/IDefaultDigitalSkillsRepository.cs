﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;
using Microsoft.AspNetCore.Mvc;

namespace RegistryAlten.DAL.Interface
{
    public interface IDefaultDigitalSkillsRepository
    {
        
        public Task<List<DigitalSkillGroupDTO>> Create(DigitalSkillGroup digitalSkillGroup, DefaultDigitalSkillDTO digitalSkill);
        public Task<DefaultDigitalSkill> Get(string name);
        public Task<List<DefaultDigitalSkill>> GetAll();
        public Task<List<DigitalSkillGroupDTO>> Update(DefaultDigitalSkill existigSkill, SkillDTO digitalSkill);
        public Task<bool> Delete(DefaultDigitalSkill existigSkill);
    }
}
