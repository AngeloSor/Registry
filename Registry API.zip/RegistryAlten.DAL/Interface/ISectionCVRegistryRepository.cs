﻿using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Interface
{
    public interface ISectionCVRegistryRepository<T> : ICVAndInheritedRepository<T>
    {
        Task<bool> FindCVRegistry(int id);
        Task<bool> Exists(int id);
    }
}
