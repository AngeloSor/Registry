﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Interface
{
    public interface IConditionRepository: ICVAndInheritedRepository<Condition>
    {
        public Task<bool> ConditionExists(int id);
        
    }
}
