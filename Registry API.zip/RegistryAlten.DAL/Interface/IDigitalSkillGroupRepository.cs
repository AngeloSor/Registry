﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;

namespace RegistryAlten.DAL.Interface
{
    public interface IDigitalSkillGroupsRepository
    {
        public Task<List<DigitalSkillGroupDTO>> Create(string name);
        public Task<DigitalSkillGroup> Get(string name);
        public Task<DigitalSkillGroup> ExistingSkill(int id);
        public Task<List<DigitalSkillGroupDTO>> GetAll();
        public Task<List<DigitalSkillGroupDTO>> Update(DigitalSkillGroup existingDigitalSkillGroup);
        public Task<bool> Delete(DigitalSkillGroup existingDigitalSkillGroup);
    }
}
