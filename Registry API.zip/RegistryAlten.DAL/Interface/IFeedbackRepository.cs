﻿using RegistryAlten.DAL.Entities;
using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Interface
{
    public interface IFeedbackRepository : IRepository <Feedback>
    {
        public Task<Feedback> Create(Feedback feedback);

        public Task<Feedback> Update(Feedback feedback);
        public Task<bool> Delete(Feedback feedback);
        public Task<Feedback> Find(int id);
        public Task<List<Feedback>> GetByTechnicianId(int id);
        public Task<List<Feedback>> GetByInterviewId(int id);
        public Task<List <Feedback>> GetAll();
        public Task<bool> FeedbackExists(int id);
    }
}
