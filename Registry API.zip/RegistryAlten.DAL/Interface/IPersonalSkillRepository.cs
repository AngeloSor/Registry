﻿using RegistryAlten.SHARED;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.DAL.Interface
{
    public interface IPersonalSkillRepository : ISectionCVRegistryRepository<PersonalSkillDTO>
    {
        public Task<PersonalSkillDTO[]> CreateSkills(PersonalSkillDTO[] dto);
    }
}
