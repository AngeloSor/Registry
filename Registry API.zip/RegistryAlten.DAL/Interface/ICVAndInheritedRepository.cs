﻿namespace RegistryAlten.DAL.Interface
{
    public interface ICVAndInheritedRepository<T> : IRepository<T>
    {
        public Task<List<T>> GetAll();
    }
}
