﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistryAlten.BLL
{
    public class ErrMsg
    {
        public ErrMsg(string message, int errCode) 
        {
            this.message = message;
            this.errCode = errCode;
        }
        public string message { get; set; }
        public int errCode { get; set; }
    }
}
