﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;



namespace RegistryAlten.BLL
{
    public static class StatusDictionaryResponse
    {
        public static Dictionary<string, string> StatusDictionary { get; set; }
        public static void AddStatusDictionary()
        {
            StatusDictionary = new Dictionary<string, string>();


            //ConditionController
            StatusDictionary.Add("ConditionNotFound", "La Condition non è stata trovata");

            //RegistryController
            StatusDictionary.Add("RegistryNotFound", "L'anagrafica non è stata trovata");
            StatusDictionary.Add("BadRequestFormatCheckFields", "I campi email, nome e cognome sono obbligatori");
            StatusDictionary.Add("BadRequestFormatCheckCondition", "Il campo Condition non contiene le informazioni corrette");
            StatusDictionary.Add("BadRequestRegistryCheck", "L'anagrafica è stata già inserita");
            StatusDictionary.Add("UserNotAuthorized", "Non sei autorizzato");
            StatusDictionary.Add("InternalServerErrorDelete", "Ci sono stati problemi nell'eliminazione");
            StatusDictionary.Add("BadRequestFormatFiscalCode", "Il formato del codice fiscale inserito non è corretto");
            StatusDictionary.Add("BadRequestFormatStreetNumber", "Il formato del numero civico inserito non è corretto");

            //CVRegistryController
            StatusDictionary.Add("BadRequestCVExists", "Il CV che stai cercando di inserire esiste già");
            StatusDictionary.Add("BadRequestRegistryId", "Il RegistryId non corrisponde a nessun utente nel database");
            StatusDictionary.Add("CVRegistryNotFound", "Il CV non è stato trovato");
            StatusDictionary.Add("BadRequestPutCV", "Stai cercando di aggiornare un CV che non esiste!");

            //CVFileController
            StatusDictionary.Add("BadRequestFindCVRegistry", "Il CVRegistryId non corrisponde a nessun curriculum nel database");
            StatusDictionary.Add("CVFileNotFound", "Il file cercato non è stato trovato");
            StatusDictionary.Add("BadRequestPutCVFile", "Stai cercando di aggiornare un file che non esiste");
            StatusDictionary.Add("BadRequestDeleteCVFile", "Stai cercando di eliminare un File che non esiste");

            //DefaultDigitalSkillController
            StatusDictionary.Add("BadRequestCreateGroupDefaultDigitalSkill", "Il gruppo di skill non è presente");
            StatusDictionary.Add("BadRequestCreateDefaultDigitalSkill", "La skill è già presente in una categoria");
            StatusDictionary.Add("NotFoundDefaultDigitalSkill", "La skill non è stata trovata");
            StatusDictionary.Add("BadRequestDevelopRole", "Stai assegnando lo stesso Development Role");

            //DigitalSkillGroupController
            StatusDictionary.Add("BadRequestCreateDigitalSkillGroup", "Il gruppo di skill è già presente");
            StatusDictionary.Add("BadRequestPutDigitalSkillGroup", "Il nuovo nome è già associato ad un gruppo di skill");
            StatusDictionary.Add("BadRequestDeleteDigitalSkillGroup", "Il gruppo di skill è associato a delle skill");
            StatusDictionary.Add("NotFoundDigitalSkillGroup", "Il gruppo di skill non è stato trovato");
            StatusDictionary.Add("BadRequestNameCheck", "Il campo Name inserito non è corretto");

            //EducationAndTrainingExperienceController
            StatusDictionary.Add("NotFoundSection", "La sezione non è stata trovata");
            StatusDictionary.Add("BadRequestPutSection", "Stai cercando di aggiornare una sezione che non esiste");
            StatusDictionary.Add("BadRequestDeleteSection", "Stai cercando di eliminare una sezione che non esiste");

            //EmailSenderController
            StatusDictionary.Add("OkSendEmail", "Email inviata!");
            StatusDictionary.Add("InternalServerErrorSendEmail", "Ci sono stati problemi durante l'invio della mail");

            //MeetingController
            StatusDictionary.Add("NotFoundMeeting", "Il meeting non è stato trovato");
            StatusDictionary.Add("BadRequestCreateMeeting", "Inserire i campi richiesti.");
            StatusDictionary.Add("BadRequestConflictDateCheck", "Inserire una data valida e disponibile");
            StatusDictionary.Add("BadRequestUserExists", "Inserire un utente valido");
            StatusDictionary.Add("BadRequestInterviewerExists", "Inserire un tecnico valido");
            StatusDictionary.Add("ForbiddenUpdateMeeting", "Gli unici campi modificabili sono data e orario");
            StatusDictionary.Add("BadRequestPutMeeting", "Stai cercando di aggiornare un meeting che non esiste");
            StatusDictionary.Add("BadRequestDeleteMeeting", "Stai cercando di eliminare un meeting che non esiste");
            StatusDictionary.Add("BadRequestTimeNotValid", "Inserire un orario lavorativo valido"); 
            StatusDictionary.Add("InternalServerErrorDisable", "Ci sono stati problemi nel cambiamento di stato"); 

            //PersonalSkillController
            StatusDictionary.Add("BadRequestFormatCheckProperty", "Il campo Property inserito non è corretto");

            //PictureProfileController
            StatusDictionary.Add("NotFoundProfilePicture", "L'immagine profilo non è stata trovata");
            StatusDictionary.Add("BadRequestPutPictureProfile", "Stai cercando di aggiornare un'immagine di profilo che non esiste");
            StatusDictionary.Add("BadRequestDeletePictureProfile", "Stai cercando di eliminare un'immagine di profilo che non esiste");

            //PivotDigitalSkillController
            StatusDictionary.Add("BadRequestPivotDigitalSkill", "La skill è già stata inserita");

            //CodinGameController
            StatusDictionary.Add("NotFoundCampaign", "La campaign non è stata trovata");
            StatusDictionary.Add("NotFoundTestSessionStatus", "Il test non è stato trovato o errore interno di CodinGame");
            StatusDictionary.Add("InternalErrorCodinGame", "Errore interno di CodinGame");
            StatusDictionary.Add("BadRequestTestAlreadyExist", "Test per l'utente già esistente");
            StatusDictionary.Add("BadRequestUserNotExist", "Utente non esistente");
            StatusDictionary.Add("BadRequestTechnicianNotExist", "Tecnico non esistente o l'utente non è un Tecnico");
            StatusDictionary.Add("NotFoundRegistryId", "L'utente non ha test");
        }

        public static Dictionary<string, string> StatusDictionaryEN { get; set; }
        public static void AddStatusDictionaryEN()
        {
            StatusDictionaryEN = new Dictionary<string, string>();

            //ConditionController
            StatusDictionaryEN.Add("ConditionNotFound", "Condtion was not found");

            //RegistryController
            StatusDictionaryEN.Add("RegistryNotFound", "Registry was not found");
            StatusDictionaryEN.Add("BadRequestFormatCheckFields", "Email, first and lastname fields are required");
            StatusDictionaryEN.Add("BadRequestFormatCheckCondition", "Condition field doesn't contain the correct information");
            StatusDictionaryEN.Add("BadRequestRegistryCheck", "The registry has already been entered");
            StatusDictionaryEN.Add("UserNotAuthorized", "User not authorized");
            StatusDictionaryEN.Add("InternalServerErrorDelete", "There were problems in the deletion");
            StatusDictionaryEN.Add("BadRequestFormatFiscalCode", "The format of the Tax Code entered is incorrect");
            StatusDictionaryEN.Add("BadRequestFormatStreetNumber", "The format of the Street Number entered is incorrect");

            //CVRegistryController
            StatusDictionaryEN.Add("BadRequestCVExists", "This CV already exists");
            StatusDictionaryEN.Add("BadRequestRegistryId", "RegistryId doesn't match any user in the database");
            StatusDictionaryEN.Add("CVRegistryNotFound", "CV was not found");
            StatusDictionaryEN.Add("BadRequestPutCV", "You are trying to update a CV that doesn't exist!");

            //CVFileController
            StatusDictionaryEN.Add("BadRequestFindCVRegistry", "CVRegistryId does not match any Curriculum in the database");
            StatusDictionaryEN.Add("CVFileNotFound", "CV file was not found");
            StatusDictionaryEN.Add("BadRequestPutCVFile", "You are trying to update a file that doesn't exist");
            StatusDictionaryEN.Add("BadRequestDeleteCVFile", "You are trying to delete a File that doesn't exist");

            //DefaultDigitalSkillController
            StatusDictionaryEN.Add("BadRequestCreateGroupDefaultDigitalSkill", "The skill group was not found");
            StatusDictionaryEN.Add("BadRequestCreateDefaultDigitalSkill", "The skill is already present in a category");
            StatusDictionaryEN.Add("NotFoundDefaultDigitalSkill", "Skill was not found");
            StatusDictionaryEN.Add("BadRequestDevelopRole", "You are assigning the same Development Role");

            //DigitalSkillGroupController
            StatusDictionaryEN.Add("BadRequestCreateDigitalSkillGroup", "The skills group already exists");
            StatusDictionaryEN.Add("BadRequestPutDigitalSkillGroup", "This name is already associated with a group of skills");
            StatusDictionaryEN.Add("BadRequestDeleteDigitalSkillGroup", "The skill group is associated with skills");
            StatusDictionaryEN.Add("NotFoundDigitalSkillGroup", "Skill group was not found");
            StatusDictionaryEN.Add("BadRequestNameCheck", "The Name field entered is incorrect");

            //EducationAndTrainingExperienceController
            StatusDictionaryEN.Add("NotFoundSection", "Section was not found");
            StatusDictionaryEN.Add("BadRequestPutSection", "You are trying to update a section that doesn't exist");
            StatusDictionaryEN.Add("BadRequestDeleteSection", "You're trying to delete a section that doesn't exist");

            //EmailSenderController
            StatusDictionaryEN.Add("OkSendEmail", "Email sent!");
            StatusDictionaryEN.Add("InternalServerErrorSendEmail", "There were problems while sending the email");

            //MeetingController
            StatusDictionaryEN.Add("NotFoundMeeting", "Meeting was not found");
            StatusDictionaryEN.Add("BadRequestCreateMeeting", "Enter the required fields");
            StatusDictionaryEN.Add("BadRequestConflictDateCheck", "Enter a valid and available date");
            StatusDictionaryEN.Add("BadRequestUserExists", "Enter a valid user");
            StatusDictionaryEN.Add("BadRequestInterviewerExists", "Enter a valid technician");
            StatusDictionaryEN.Add("ForbiddenUpdateMeeting", "The only editable fields are date and time");
            StatusDictionaryEN.Add("BadRequestPutMeeting", "You're trying to update a meeting that doesn't exist");
            StatusDictionaryEN.Add("BadRequestDeleteMeeting", "You're trying to delete a meeting that doesn't exist");
            StatusDictionaryEN.Add("BadRequestTimeNotValid", "Enter a valid working time");

            //PersonalSkillController
            StatusDictionaryEN.Add("BadRequestFormatCheckProperty", "Property field entered is incorrect");

            //PictureProfileController
            StatusDictionaryEN.Add("NotFoundProfilePicture", "Profile image was not found");
            StatusDictionaryEN.Add("BadRequestPutPictureProfile", "You are trying to update a profile picture that does not exist");
            StatusDictionaryEN.Add("BadRequestDeletePictureProfile", "You are trying to delete a profile picture that does not exist");

            //PivotDigitalSkillController
            StatusDictionaryEN.Add("BadRequestPivotDigitalSkill", "The skill has already been entered");

            //CodinGameController
            StatusDictionaryEN.Add("NotFoundCampaign", "The campaign was not found");
            StatusDictionaryEN.Add("NotFoundTestSessionStatus", "Test was not found or CodinGame internal error");
            StatusDictionaryEN.Add("InternalErrorCodinGame", "CodinGame internal error");
            StatusDictionaryEN.Add("BadRequestTestAlreadyExist", "Test for existing user");
            StatusDictionaryEN.Add("BadRequestUserNotExist", "User was not found");
            StatusDictionaryEN.Add("BadRequestTechnicianNotExist", "Technician not found or user is not a Technician");
            StatusDictionary.Add("NotFoundRegistryId", "User doesn't have tests");
        }
    }
}