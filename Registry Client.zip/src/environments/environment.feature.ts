export const environment = {
  production: false
};

export const ApisRoot = {
  clientBaseUrl: 'https://registryclient-feature.azurewebsites.net/',
  dotnetBaseUrl: 'https://registryapi-feature.azurewebsites.net/api/',
  keycloakBaseUrl: 'https://recruitingkeycloak.azurewebsites.net/auth/',
  realm: 'RegistryAlten-Features',
  PROJECT_NAME: 'RegrtsyAlten'
}

//test
