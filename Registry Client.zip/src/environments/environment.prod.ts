export const environment = {
  production: true
};

export const ApisRoot = {
  clientBaseUrl: 'https://registryclient-production.azurewebsites.net/',
  dotnetBaseUrl: 'https://registryapi.azurewebsites.net/api/',
  keycloakBaseUrl: 'https://recruitingkeycloak.azurewebsites.net/auth/',
  realm: 'RegistryAlten-Prod',
  PROJECT_NAME: 'RegrtsyAlten'
}
