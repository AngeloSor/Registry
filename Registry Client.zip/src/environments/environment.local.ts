export const environment = {
  production: false
};

export const ApisRoot = {
  clientBaseUrl: 'https://localhost:4200/',
  dotnetBaseUrl: 'https://localhost:7295/',
  keycloakBaseUrl: 'https://recruitingkeycloak.azurewebsites.net/auth/',
  realm: 'RegistryAlten-Dev',
  PROJECT_NAME: 'RegrtsyAlten'
}
