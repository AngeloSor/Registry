import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestoreEventDialogComponent } from './restore-event-dialog.component';

describe('RestoreEventDialogComponent', () => {
  let component: RestoreEventDialogComponent;
  let fixture: ComponentFixture<RestoreEventDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestoreEventDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RestoreEventDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
