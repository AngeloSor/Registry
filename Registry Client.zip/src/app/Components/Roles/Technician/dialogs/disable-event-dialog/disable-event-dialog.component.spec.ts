import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisableEventDialogComponent } from './disable-event-dialog.component';

describe('DisableEventDialogComponent', () => {
  let component: DisableEventDialogComponent;
  let fixture: ComponentFixture<DisableEventDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisableEventDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DisableEventDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
