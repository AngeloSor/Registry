import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EventScheduledComponent } from '../../event-scheduled/event-scheduled.component';

@Component({
  selector: 'app-delete-event-dialog',
  templateUrl: './delete-event-dialog.component.html',
  styleUrls: ['./delete-event-dialog.component.css']
})
export class DeleteEventDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<EventScheduledComponent>,
    @Inject(MAT_DIALOG_DATA) public data: string,
  ) {
    dialogRef.disableClose = true;
  }
ngOnInit(): void {

}
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
