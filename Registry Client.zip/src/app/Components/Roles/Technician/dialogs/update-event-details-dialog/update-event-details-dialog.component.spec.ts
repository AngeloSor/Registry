import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateEventDetailsDialogComponent } from './update-event-details-dialog.component';

describe('UpdateEventDetailsDialogComponent', () => {
  let component: UpdateEventDetailsDialogComponent;
  let fixture: ComponentFixture<UpdateEventDetailsDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateEventDetailsDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateEventDetailsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
