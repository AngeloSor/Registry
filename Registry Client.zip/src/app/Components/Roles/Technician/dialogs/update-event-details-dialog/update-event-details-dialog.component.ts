import { MeetingCreateComponent } from '../../../Admin/meeting-create/meeting-create.component';
import { MeetingDTO } from 'src/app/Models/DTOs/Meeting/Meeting-dto';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { EventScheduledComponent } from '../../event-scheduled/event-scheduled.component';
import { DatepickerRangeService } from 'src/app/Services/General/DatepickerRange/datepicker-range.service';

@Component({
  selector: 'app-update-event-details-dialog',
  templateUrl: './update-event-details-dialog.component.html',
  styleUrls: ['./update-event-details-dialog.component.css']
})
export class UpdateEventDetailsDialogComponent implements OnInit {

  user!: UserDTO;
  technician!: UserDTO;
  max_date = new Date()
  min_date = new Date()

  meetingForm = new FormGroup({
    date: new FormControl<Date>(null, Validators.required),
    time: new FormControl<any>(null, Validators.required)
  })

  constructor(
    private dotNetService: DotNetService,
    public dialogRef: MatDialogRef<EventScheduledComponent>,
    private _datePickerRange: DatepickerRangeService,
    @Inject(MAT_DIALOG_DATA) public data: MeetingDTO
  ) {
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.SetFormValue();
    this.min_date = this._datePickerRange.min_meeting
    this.max_date = this._datePickerRange.max_meeting
  }

  FormatDate(date: Date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) {
      month = '0' + month;
    }

    if (day.length < 2) {
      day = '0' + day;
    }

    return [day, month, year].join('/');
  }

  SetFormValue(){
    console.log("this.data", this.data);
    let date = new Date(this.data.date)
    this.GetUserById(this.data.userId);
    this.meetingForm.controls.date.setValue(date);
    this.meetingForm.controls.time.setValue(date.toTimeString().substring(0,5));
    console.log(this.meetingForm.value)
  }

  GetUserById(id: number){
    this.dotNetService.GetRegistryById(id).subscribe({
      next: res => {
        this.user = res.body
      }, error: error => {
        this.dotNetService.DisplayError(error.error)
      }
    })
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  UpdateMeeting(){
    console.log("Valore del form: ",this.meetingForm.value)
    let a:string = this.meetingForm.value.time
    let b = a.split(':')

    this.meetingForm.value.date.setHours(Number.parseInt(b[0]), Number.parseInt(b[1]))
    this.data.date = new Date(this.meetingForm.value.date);
    this.data.time = new Date(this.meetingForm.value.date);
    console.log(this.meetingForm)
    this.dialogRef.close(this.data);
  }

}
