import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CodingameResultComponent } from './codingame-result.component';

describe('CodingameResultComponent', () => {
  let component: CodingameResultComponent;
  let fixture: ComponentFixture<CodingameResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CodingameResultComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CodingameResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
