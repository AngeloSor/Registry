import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CodinGameCampaigns, Result } from 'src/app/Models/DTOs/CodinGame/CodinGame';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';

@Component({
  selector: 'app-codingame-result',
  templateUrl: './codingame-result.component.html',
  styleUrls: ['./codingame-result.component.css']
})
export class CodingameResultComponent implements OnInit {
  result: Result
  keys: string[]
  start_time: string
  end_time: string
  send_time: string
  duration: string
  skills_for_key = []
  campaigns: CodinGameCampaigns[];
  status = 'Loading'

  constructor(
    private dotNetService: DotNetService,
    @Inject(MAT_DIALOG_DATA) public data: number,
    private dialogRef: MatDialogRef<any>
  ) { }

  ngOnInit(): void {
    //this.GetCampaigns()
    this.GetStatusText(this.data)
  }

  GetStatusText(userId: number){
    this.dotNetService.GetStatusTest(userId)
    .subscribe({
      next: res => {

        this.result = res.body
        console.log("🚀 ~ file: codingame-result.component.ts:33 ~ CodingameResultComponent ~ GetStatusText ~ this.result", this.result)
        this.send_time = this.FormatDate(this.result.send_time)
        if(this.result.status != 'waiting' && this.result.status != 'expired'){
          this.dialogRef.updateSize('45vw','90vh')
          this.start_time = this.FormatDate(this.result.start_time)
          this.end_time = this.FormatDate(this.result.end_time)

          let timetest = new Date(null)
          timetest.setSeconds(this.result.report.duration);
          this.duration = timetest.toISOString().substring(11,19);

          this.keys = Object.keys(res.body.report.technologies); //[0] --> C#
          console.log("Risposta da codinGame", this.keys);
          this.keys.forEach(key => {
            this.result.report.technologies[key].name = key
            console.log("key name ", this.result.report.technologies[key].name)
            let skills = Object.keys(this.result.report.technologies[key].skills)
            skills.forEach(skill => {
              this.result.report.technologies[key].skills[skill].name = skill
            })
            this.skills_for_key.push(skills)
          });
        } else {
          this.dialogRef.updateSize('45vw','35vh')
          console.log("Waiting || Expired")
        }
        setTimeout(()=>{
          this.status = 'Loaded'
        },200)
      }, error: error => {
        this.status = 'Loaded'
        //this.dialogRef.close()
        this.dotNetService.DisplayError(error.error)
      }
    })
  }

  GetCampaignById(campaignId: number){
    return this.campaigns.find(campaign => campaign.id == campaignId).name
  }

  FormatDate(dateNumber: number){
    let date = new Date(dateNumber)
    return date.getDate()+
    "/"+(date.getMonth()+1)+
    "/"+ date.getFullYear()+
    " "+ date.getHours()+
    ":"+ date.getMinutes()
  }

}
