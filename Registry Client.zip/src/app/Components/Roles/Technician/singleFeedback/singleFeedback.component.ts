import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { InterviewFeedbackDTO, esperienza, isPassed, profilo, valutazione } from "src/app/Models/DTOs/InterviewFeedback/interviewFeedbackDTO";
import { FeedbackService } from "src/app/Services/Apis/Net/Feedback/feedback.service";

@Component({
  selector: 'app-singleFeedback',
  templateUrl: './singleFeedback.component.html',
  styleUrls: ['./singleFeedback.component.css']
})
export class SingleFeedbackComponent implements OnInit {

  id: number;
  feedback: InterviewFeedbackDTO;
  ruoloOptions = profilo;
  valutazioneOptions = valutazione;
  esperienzaOptions = esperienza;
  isPassedOption = isPassed;
  loaded: boolean = null;

  constructor(private feedbackService: FeedbackService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.loaded = false
    this.id = +this.route.snapshot.paramMap.get('id');
    this.getFeedback();
  }

  // goBack(): void {
  //   this.location.back();
  // }

  getRole(data: string){
    let value = Number.parseInt(data)
    let res = this.ruoloOptions.find(x => x.value == value);
    return res.label
  }

  getEvaluation(data:string){
    let value = Number.parseInt(data)
    let res = this.valutazioneOptions.find(x => x.value == value);
    return res.label
  }

  getExperience(data:string){
    let value = Number.parseInt(data)
    let res = this.esperienzaOptions.find(x => x.value == value);
    return res.label
  }

  getPassed(data:string){
    let value = Number.parseInt(data)
    let res = this.isPassedOption.find(x => x.value == value);
    return res.label
  }

  getLabelFromValue(value: number, array: {value: number, label: string}[]): string {
    const item = array.find(x => x.value === value);
    return item ? item.label : '';
  }

  getFeedback() {
    this.feedbackService.getFeedbackById(this.id).subscribe(feedback => {
      this.loaded = false
      this.feedback = feedback;
      this.feedback.dateFeedback = new Date(this.feedback.dateFeedback);
      console.log(this.feedback);
      this.loaded = true
    });
  }
}
