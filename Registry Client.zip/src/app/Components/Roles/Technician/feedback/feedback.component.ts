import { CvSkillComponent } from './../../User/user-detail/cv/cv-dialogs/cv-dialogs.component';
import { MatDialog } from '@angular/material/dialog';
import { MatChipInputEvent } from '@angular/material/chips';
import { ENTER, COMMA } from '@angular/cdk/keycodes';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { DigitalSkill, DigitalSkillGroupDTO, SkillAutocomplete } from 'src/app/Models/DTOs/Skills/SkillGroup/skillGroup';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { Component, OnInit, ElementRef, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { InterviewFeedbackDTO, esperienza, isPassed, profilo, valutazione } from 'src/app/Models/DTOs/InterviewFeedback/interviewFeedbackDTO';
import { CookieService } from 'ngx-cookie-service';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { DictionaryService } from 'src/app/Services/General/Dictionary/dictionary.service';
import { DatepickerRangeService } from 'src/app/Services/General/DatepickerRange/datepicker-range.service';
import { ErrorStateMatcher } from '@angular/material/core';
import { request } from 'express';
import { HttpClient } from '@angular/common/http';
import { FeedbackService } from 'src/app/Services/Apis/Net/Feedback/feedback.service';
import { PivotDigitalSkill, RegistryCVDTO } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { Observable } from 'rxjs';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';

export const _filter = (opt: DigitalSkill[], value: string): DigitalSkill[] => {
  const filterValue = value;
  return opt.filter(item => item.name.toLowerCase().includes(filterValue));
};

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  separatorKeysCodes: number[] = [ENTER, COMMA];
  ruoloOptions = profilo;
  valutazioneOptions = valutazione;
  esperienzaOptions = esperienza;
  isPassedOption = isPassed;
  ccEmails: string[] = [];
  toEmails: string[] = [];
  newEmail: string = '';
  emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  technicianId: number;
  userId: number;
  currentDate: Date = new Date;
  skillAutocomplete: any = [];
  digitalSkillGroups: DigitalSkillGroupDTO[] = [];

  //#region feedbackForm
  interviewFeedback: InterviewFeedbackDTO = {
    mailMessage: {
      from: {
        address: "",
        name: ""
      },
      cc: [],
      to: [],
      body: '',
      subject: ''
    },
    architectureEvaluation: null,
    codeEvaluation: null,
    conclusioni: '',
    designEvaluation: null,
    isPassed: null,
    esperienza: null,
    ruolo: null,
    dateFeedback: this.currentDate,
    feedbackUserId: null,
    feedbackInterviewerId: null,
    nameUser: '',
    id: null
  }

  feedbackForm = this.fb.group({
    cc: new FormControl<string>('', [Validators.required, Validators.email]),
    to: new FormControl<string[]>([''], [Validators.required, Validators.email]),
    architectureEvaluation: new FormControl<string>(null, Validators.required),
    codeEvaluation: new FormControl<string>(null, Validators.required),
    conclusioni: new FormControl<string>('', Validators.required),
    designEvaluation: new FormControl<string>(null, Validators.required),
    isPassed: new FormControl<boolean>(null, Validators.required),
    esperienza: new FormControl<string>(null, Validators.required),
    ruolo: new FormControl<string>(null, Validators.required),
  })

  matcher = new MyErrorStateMatcher();
  //#endregion

  constructor(
    private _dotNetService: DotNetService,
    public dialog: MatDialog,
    private _activatedRoute: ActivatedRoute,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private http: HttpClient,
    private feedbackService: FeedbackService,
    private snackBar: SnackbarService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getId();
  }

  //#region getId
  getId(){
    this.route.params.subscribe(param => {
      this.technicianId = Number.parseInt(param['technicianId'])
      this.userId = Number.parseInt(param['userId'])
      console.debug(
        [
          { 'TechnicianId: ' : this.technicianId },
          { 'UserId: ' : this.userId }
        ]
      );
    })
  }
  //#endregion

//#region submit
submitForm(){
  let formData = this.feedbackForm.value;
  console.debug(formData.cc)
  console.debug(formData.to)
  console.debug(this.feedbackForm)
  let request: InterviewFeedbackDTO = {
    nameUser: '',
    mailMessage: {
      cc: this.ccEmails,
      to: this.toEmails,
      from: {
        name: 'Antonio Cioce',
        address: 'antonio.cioce@alten.it'
      },
      subject: 'Esito colloquio',
      body: ''
    },
    isPassed: formData.isPassed,
    esperienza: formData.esperienza,
    ruolo: formData.ruolo,
    conclusioni: formData.conclusioni,
    designEvaluation: formData.designEvaluation,
    codeEvaluation: formData.codeEvaluation,
    dateFeedback: this.currentDate,
    feedbackUserId: this.userId,
    feedbackInterviewerId: this.technicianId,
    architectureEvaluation: formData.architectureEvaluation,
    id: 0,
  }
  if(Array.isArray(formData.to)){
    formData.to.forEach(x => request.mailMessage.to.push(x));
  }
  //#region sendFeedback
  this.feedbackService.createFeedback(request).subscribe(
    result => {
      this.snackBar.Show('Feedback inviato con successo');
      console.log('Feedback inviato al backend:', request);
    },
    error => {
      this.snackBar.Show('Errore durante l\'invio del feedback');
      console.error('Errore durante l\'invio del feedback:', error);
    });
    //#endregion
  console.debug(request);

  this.router.navigate(['/user/info', this.technicianId]);
}
//#endregion

  //#region cc
  addCc(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();
    if (value && value.match(this.emailRegex)) {
      this.ccEmails.push(value);
      if(this.ccEmails.length >= 1){
        this.feedbackForm.controls.cc.removeValidators(Validators.required);
      }
    }
    event.chipInput!.clear();
  }

  removeCc(email: string): void {
    const index = this.ccEmails.indexOf(email);
    if (index >= 0) {
      this.ccEmails.splice(index, 1);
      if(this.ccEmails.length <= 0){
        this.feedbackForm.controls.cc.addValidators(Validators.required);
      }
    }
  }

  addTo(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();
    if (value && value.match(this.emailRegex)) {
      this.toEmails.push(value);
      if(this.toEmails.length >= 1){
        this.feedbackForm.controls.to.removeValidators(Validators.required);
      }
    }
    event.chipInput!.clear();
  }

  removeTo(email: string): void {
    const index = this.toEmails.indexOf(email);
    if (index >= 0) {
      this.toEmails.splice(index, 1);
      if(this.toEmails.length <= 0){
        this.feedbackForm.controls.to.addValidators(Validators.required);
      }
    }
  }

  /*   addEmail(event: any): void {
    const value = event.value.trim();
    if (value && !this.emails.includes(value)) {
      this.emails.push(value);
    }
    event.chipInput.clear();
  }

  removeEmail(email: string): void {
    const index = this.emails.indexOf(email);
    if (index >= 0) {
      this.emails.splice(index, 1);
    }
  } */
  //#endregion
}
