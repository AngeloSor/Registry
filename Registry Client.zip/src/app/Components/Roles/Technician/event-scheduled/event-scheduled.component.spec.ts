import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventScheduledComponent } from './event-scheduled.component';

describe('EventScheduledComponent', () => {
  let component: EventScheduledComponent;
  let fixture: ComponentFixture<EventScheduledComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventScheduledComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventScheduledComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
