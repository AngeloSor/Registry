import { filter } from 'rxjs';
import { Params, Router, ActivatedRoute, UrlSerializer } from '@angular/router';
import { UpdateEventDetailsDialogComponent } from '../dialogs/update-event-details-dialog/update-event-details-dialog.component';
import { UserDTO } from './../../../../Models/DTOs/User/user-dto';
import { MeetingDTO } from 'src/app/Models/DTOs/Meeting/Meeting-dto';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { Clipboard } from '@angular/cdk/clipboard';
import { CodingameResultComponent } from "../codingame-result/codingame-result.component";
import { DisableEventDialogComponent } from '../dialogs/disable-event-dialog/disable-event-dialog.component';
import { DeleteEventDialogComponent } from '../dialogs/delete-event-dialog/delete-event-dialog.component';
import { RestoreEventDialogComponent } from '../dialogs/restore-event-dialog/restore-event-dialog.component';

import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ApisRoot } from 'src/environments/environment';


@Component({
  selector: 'app-event-scheduled',
  templateUrl: './event-scheduled.component.html',
  styleUrls: ['./event-scheduled.component.css']
})
export class EventScheduledComponent implements OnInit {

  allMeetings: MeetingDTO[] = [];
  meetings: MeetingDTO[] = [];
  pastMeetings: MeetingDTO[] = [];
  deletedMeetings: MeetingDTO[] = [];
  filterMeetings: MeetingDTO[] = [];
  filterPastMeetings: MeetingDTO[] = [];
  filterDeletedMeetings: MeetingDTO[] = [];

  allUsers: UserDTO[] = []
  users: UserDTO[] = []
  pastUsers: UserDTO[] = []
  deletedUsers: UserDTO[] = []
  filterUsers: UserDTO[] = [];
  filterPastUsers: UserDTO[] = [];
  filterDeletedUsers: UserDTO[] = [];

  technician: UserDTO;
  value: string;
  today: Date;
  status: string

  userFilterParam = new FormControl('');
  userFiltered: Observable<UserDTO[]>;
  meetingFilterParam = new FormControl('');
  filteredMeetings: Observable<MeetingDTO[]>;
  received = true

  filteredUsers$: Observable<UserDTO[]>;
/*   disabledUser: UserDTO[] = []; */

  meetingForm = new FormGroup({
    user: new FormControl<UserDTO>(null),
    technicianId: new FormControl<UserDTO>(null),
  })

  constructor(
    private _dotNetService: DotNetService,
    public dialog: MatDialog,
    private router: Router,
    private _snackBarService: SnackbarService,
    private serialize: UrlSerializer
  ) { }

  ngOnInit(): void {
    this.filteredUsers$ = this.meetingForm.controls.user.valueChanges.pipe(
      startWith(''),
      map(value => this._filterU(value.toString() || ''))
    )

    this.filteredMeetings = this.meetingFilterParam.valueChanges.pipe(
      startWith(''),
      map(value => this._filterMeeting(value || '')),
    );

    this.status = 'Loading'
    this.GetEventScheduled();

  }

  private _filterU(value: string): UserDTO[] {
    if (typeof value !== 'string') {
      return [];
    }
    const filterValue = value.toLowerCase();
    return this.users.filter(option => option.name.toLowerCase().includes(filterValue) || option.surname.toLowerCase().includes(filterValue)
      || String(option.name + " " + option.surname).toLowerCase().includes(filterValue)
    );
  }

  private _filterMeeting(value: string): MeetingDTO[] {
    const filterValue = value.toLowerCase();
    return this.meetings.filter(option => option.nameUser?.toLowerCase().includes(filterValue));
  }

  FormatDate(date: Date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) {
      month = '0' + month;
    }

    if (day.length < 2) {
      day = '0' + day;
    }

    return [day, month, year].join('/');
  }

  FormatHours(date: Date) {

    let hours = '' + (date.getHours())
    let minutes = '' + date.getMinutes()
    if (hours.length < 2) {
      hours = '0' + hours;
    }

    if (minutes.length < 2) {
      minutes = '0' + minutes;
    }

    return [hours, minutes].join(':');
  }

  GetEventScheduled() {
    this.today = new Date()
    this._dotNetService.GetMeetingsByInterviewer().subscribe({
      next: res => {
        if (res.body.length != 0) {

          this.allMeetings = res.body;
          if(this.allMeetings.length > 0) {
            this.GetTechnicianById(this.allMeetings[0]?.interviewerId);
          }

          this.allMeetings.forEach(x => {
            x.date = new Date(this.GetIsoDate(x.date));
          })


          this.FillMeetings(this.meetings, this.filterMeetings, this.users, this.filterUsers, false, 1)
          this.FillMeetings(this.pastMeetings, this.filterPastMeetings, this.pastUsers, this.filterPastUsers,false, 2)
          this.FillMeetings(this.deletedMeetings, this.filterDeletedMeetings, this.deletedUsers,this.filterDeletedUsers, true)
        }
        setTimeout(() => {
          this.status = 'Loaded'
        }, 1000)

      }, error: error => {
        setTimeout(() => {
          this.status = 'Loaded'
        }, 1000)
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  FillMeetings(meetings, filterMeetings, users, filterUsers, isDeleted, condition = 0){

    if(condition == 0){
      this.allMeetings.filter(meet =>
        meet.isDeleted == isDeleted
      ).forEach(meet => {
        this.PushUser(meet.userId, users, filterUsers);
        meetings.push(meet);
        filterMeetings.push(meet);
      })

    } else if(condition == 1){
      this.allMeetings.filter(meet =>
        meet.isDeleted == isDeleted && meet.date >= this.today
      ).forEach(meet => {
        this.PushUser(meet.userId, users, filterUsers);
        meetings.push(meet);
        filterMeetings.push(meet);
      })
    } else {
      this.allMeetings.filter(meet =>
        meet.isDeleted == isDeleted && meet.date < this.today
      ).forEach(meet => {
        this.PushUser(meet.userId, users, filterUsers);
        meetings.push(meet);
        filterMeetings.push(meet);
      })
    }
  }

  Filter(event){
    let text = (<string>event.target.value).toLowerCase()

    this.filterUsers = []
    this.filterMeetings = []
    if(event.target.value == ''){
      this.filterMeetings = this.meetings
      this.filterUsers = this.users
    } else {
      this.filterUsers = this.users.filter(x =>
        x.name.toLowerCase().includes(text) || x.surname.toLowerCase().includes(text))
      this.filterUsers.forEach(user => {
        this.filterMeetings.push(this.meetings.find(x => x.userId == user.id))
      })
    }
  }
  FilterPast(event){
    let text = (<string>event.target.value).toLowerCase()

    this.filterPastUsers = []
    this.filterPastMeetings = []
    if(event.target.value == ''){
      this.filterPastMeetings = this.pastMeetings
      this.filterPastUsers = this.pastUsers
    } else {
      this.filterPastUsers = this.pastUsers.filter(x =>
        x.name.toLowerCase().includes(text) || x.surname.toLowerCase().includes(text))
      this.filterPastUsers.forEach(user => {
        this.filterPastMeetings.push(this.pastMeetings.find(x => x.userId == user.id))
      })
    }
  }
  FilterDeleted(event){
    let text = (<string>event.target.value).toLowerCase()

    this.filterDeletedUsers = []
    this.filterDeletedMeetings = []
    if(event.target.value == ''){
      this.filterDeletedMeetings = this.deletedMeetings
      this.filterDeletedUsers = this.deletedUsers
    } else {
      this.filterDeletedUsers = this.deletedUsers.filter(x =>
        x.name.toLowerCase().includes(text) || x.surname.toLowerCase().includes(text))
      this.filterDeletedUsers.forEach(user => {
        this.filterDeletedMeetings.push(this.deletedMeetings.find(x => x.userId == user.id))
      })
    }
  }

  GetIsoDate(date: Date) {
    const d = new Date(date)
    return new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() - d.getTimezoneOffset()).toISOString();
  }

  PushUser(userId: number, users: UserDTO[], filterUsers: UserDTO[]) {
    this._dotNetService.GetRegistryById(userId).subscribe({
      next: res => {
        if (!users.map(user => user.id).includes(res.body.id)) {
          users.push(res.body)
          filterUsers.push(res.body)
          this.allUsers.push(res.body)
        }
      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  GetTechnicianById(idTechinician: number) {
    this._dotNetService.GetRegistryById(idTechinician).subscribe({
      next: res => {
        this.technician = res.body;
      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  GetUserByMeeting(meeting: MeetingDTO) {
    let user = this.users.find(user => user?.id == meeting?.userId)
    return user?.name + " " + user?.surname
  }

  CopyToClipboard(userId: number) {
    const queryParams: Params = { TechnicianId: this.technician.id, UserId: userId };
    const tree = this.router.createUrlTree(['feedback', userId], { queryParams: queryParams, queryParamsHandling: 'merge' });
    console.log(this.serialize.serialize(tree));
    let a = this.serialize.serialize(tree);
    a = a.replace('/feedback/', 'feedback/');
    let baseUrl = ApisRoot.clientBaseUrl;
    return baseUrl + a;
  }

  OpenEditDetailsEvent(meeting: MeetingDTO) {
    console.log("METING", meeting)
    const dialog = this.dialog.open(UpdateEventDetailsDialogComponent, {
      width: '300px',
      height: '340px',
      data: meeting
    });

    dialog.afterClosed().subscribe({
      next: res => {
        if (res) {
          console.log(res)
          this._dotNetService.UpdateMeeting(res).subscribe({
            next: res => {
              console.log(res)
            }, error: error => {
              this._dotNetService.DisplayError(error.error)
            }
          })
        }
      }
    });
  }

  OpenDeleteEvent(index: number) {
    const dialog = this.dialog.open(DeleteEventDialogComponent, {});

    dialog.afterClosed().subscribe({
      next: res => {
        if (res) {
          this._dotNetService.DeleteMeeting(index).subscribe({
            next: res => {
              let meetingIndex = this.deletedMeetings.findIndex(x => x.id == index);
              // let userIndex = this.users.findIndex(x => x.id == index);
              this.deletedMeetings.splice(meetingIndex, 1);
              // this.users.splice(userIndex, 1);
              this._snackBarService.Show("Evento cancellato con successo!");
              window.location.reload();
            }, error: error => {
              this._dotNetService.DisplayError(error.error)
            }
          })
        }
      }
    })
  }

  OpenDisableEvent(index: number) {
    const dialog = this.dialog.open(DisableEventDialogComponent, {});

    dialog.afterClosed().subscribe({
      next: res => {
        if (res) {
          this._dotNetService.ChangeStatusMeeting(index).subscribe({
            next: res => {
              let meeting = this.meetings.find(x => x.id == index);
              this.deletedMeetings.push(meeting)
              this.meetings.splice(this.meetings.indexOf(meeting), 1);
              this._snackBarService.Show("Evento disabilitato con successo!");
            }, error: error => {
              this._dotNetService.DisplayError(error.error)
            }
          })
        }
      }
    })
  }

  OpenRestoreEvent(index: number) {
    const dialog = this.dialog.open(RestoreEventDialogComponent, {});

    dialog.afterClosed().subscribe({
      next: res => {
        if (res) {
          this._dotNetService.ChangeStatusMeeting(index).subscribe({
            next: res => {
              let meeting = this.deletedMeetings.find(x => x.id == index);
              if (meeting.date < this.today) {
                this.pastMeetings.push(meeting);
              } else {
                this.meetings.push(meeting);
              }
              this.deletedMeetings.splice(this.deletedMeetings.indexOf(meeting), 1);
              this._snackBarService.Show("Evento riabilitato con successo!");
            }, error: error => {
              this._dotNetService.DisplayError(error.error)
            }
          })
        }
      }
    })
  }

  OpenCondigameResultDialog(userId: number) {
    const dialogRef = this.dialog.open(CodingameResultComponent, {
      width: '400px',
      height: '400px',
      data: userId,
      disableClose: true
    });
    dialogRef.keydownEvents().subscribe(event => {
      if (event.key === "Escape") {
        dialogRef.close()
      }
    });
    dialogRef.afterClosed().subscribe(res => {
    });
  }

  displayUserFn(user?: UserDTO): string | undefined {
    return user ? user.name + ' ' + user.surname : undefined;
  }
}
