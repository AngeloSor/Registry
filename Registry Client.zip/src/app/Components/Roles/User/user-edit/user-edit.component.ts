import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Genders, UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { UserDetailComponent } from '../user-detail/user-detail.component';
import { DatepickerRangeService } from 'src/app/Services/General/DatepickerRange/datepicker-range.service';
import { ConditionDTO } from 'src/app/Models/DTOs/User/condition-dto';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';

const today = new Date();
const month = today.getMonth();
const year = today.getFullYear();


@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {



  user!: UserDTO;
  max_date = new Date()
  min_date = new Date()
  genders = Genders
  conditions : ConditionDTO[] = []
  accountImage: any;

  editUserForm = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.maxLength(20)]),
    surname: new FormControl('', [Validators.required, Validators.maxLength(20)]),
    email: new FormControl('', [Validators.required, Validators.email]),
    birthDate: new FormControl<Date>(null, Validators.required),
    fiscalCode: new FormControl('', [Validators.required, Validators.maxLength(16)]),
    city: new FormControl('', [Validators.required, Validators.maxLength(30)]),
    province: new FormControl('', [Validators.required, Validators.maxLength(2)]),
    street: new FormControl('', [Validators.required, Validators.maxLength(50)]),
    streetNumber: new FormControl('', [Validators.required, Validators.maxLength(6), Validators.pattern('^[0-9]{1,3}(/?[A-z]{1,2})?$')]),
    zipCode: new FormControl<number>(null, Validators.required),
    gender: new FormControl<number>(null, Validators.required),
    businessManager: new FormControl('', [Validators.required, Validators.maxLength(50)]),
    conditionId: new FormControl<number>(null,Validators.required),
    role: new FormControl(false, [Validators.required]),
  })

  constructor(
    private router: Router,
    private _dotNetService: DotNetService,
    private _datePickerRange: DatepickerRangeService,
    public dialogRef: MatDialogRef<UserDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }


  ngOnInit(): void {
    this.min_date = this._datePickerRange.min_dob
    this.max_date = this._datePickerRange.max_dob
    this.GetConditions()
    this.GetUserData();
  }

  GetConditions(){
    this._dotNetService.GetAllConditions().subscribe({
      next: res => {
        console.log(res.body)
        this.conditions = res.body
      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  onSave(): void {
    this.user.name = this.editUserForm.value.name
    this.user.surname = this.editUserForm.value.surname
    this.user.email = this.editUserForm.getRawValue().email
    this.user.birthDate = this.editUserForm.value.birthDate
    this.user.street = this.editUserForm.value.street
    this.user.streetNumber = this.editUserForm.value.streetNumber
    this.user.zipCode = this.editUserForm.value.zipCode
    this.user.city = this.editUserForm.value.city
    this.user.province = this.editUserForm.value.province
    this.user.gender = this.editUserForm.value.gender
    this.user.conditionId = this.editUserForm.value.conditionId
    this.user.fiscalCode = this.editUserForm.value.fiscalCode
    this.user.businessManager = this.editUserForm.value.businessManager
    this.user.technician = this.editUserForm.value.role

    this.dialogRef.close({user: this.user, image: this.accountImage});
  }

  GetUserData(){
    if(this.data.image != null)
      this.accountImage = this.data.image.picture;
    this.user = this.data.user;
    this.editUserForm.controls.name.setValue(this.user.name);
    this.editUserForm.controls.surname.setValue(this.user.surname);
    this.editUserForm.controls.email.setValue(this.user.email);
    this.editUserForm.controls.street.setValue(this.user.street);
    this.editUserForm.controls.streetNumber.setValue(this.user.streetNumber);
    this.editUserForm.controls.businessManager.setValue(this.user.businessManager);
    this.editUserForm.controls.fiscalCode.setValue(this.user.fiscalCode);
    this.editUserForm.controls.zipCode.setValue(this.user.zipCode);
    this.editUserForm.controls.city.setValue(this.user.city);
    this.editUserForm.controls.province.setValue(this.user.province);
    this.editUserForm.controls.gender.setValue(this.user.gender);
    this.editUserForm.controls.birthDate.setValue(new Date(this.user.birthDate));
    this.editUserForm.controls.conditionId.setValue(this.user.conditionId);

    if(this.editUserForm.value.role == false){
      this.editUserForm.controls.conditionId.setValue(this.user.conditionId)
    }
    else{
      this.editUserForm.controls.role.setValue(this.user.technician);
    }
    this.editUserForm.controls.role.setValue(this.user.technician);

    this.editUserForm.controls.email.disable();
  }

  onCancel(){
    this.dialogRef.close();
  }

  OnChangeValue(){
    if(this.editUserForm.value.role == true){
      alert("Non puoi cambiare un utente da tecnico a candidato!")
    }
  }

  SetFileToUpload(event) {
    let file = event.target.files[0];
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.accountImage = reader.result
    };
    reader.onerror = function (error) {
      console.log('Error: ', error);
    };

  }
}
