import { ActivatedRoute, Params } from '@angular/router';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { CvFile, EducationAndTrainingExperience, PersonalSkill, PersonalSkills, PivotDigitalSkill, RegistryCVDTO, WorkExperience } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { CvConfirmDeletDialogComponent, CvIstructionComponent, CvSkillComponent, CvWorkExperienceComponent } from './cv-dialogs/cv-dialogs.component';
import { SkillAutocomplete, DigitalSkillGroupDTO, DigitalSkill } from 'src/app/Models/DTOs/Skills/SkillGroup/skillGroup';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { COMMA, ENTER, Z } from '@angular/cdk/keycodes';
import { map, Observable, startWith } from 'rxjs';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { RoleGuard } from 'src/app/Services/Guards/Role/role.guard';
import { DatepickerRangeService } from 'src/app/Services/General/DatepickerRange/datepicker-range.service';
import { CodingGameService } from 'src/app/Services/General/CodingGame/codin-game.service';
import { CodingameReport } from 'src/app/Models/Entities/CodingameReport/codingame-report';
import { Dictionary, DictionaryService } from 'src/app/Services/General/Dictionary/dictionary.service';
import { CookieService } from 'ngx-cookie-service';

export const _filter = (opt: DigitalSkill[], value: string): DigitalSkill[] => {
  const filterValue = value;

  return opt.filter(item => item.name.toLowerCase().includes(filterValue));
};


@Component({
  selector: 'app-cv',
  templateUrl: './cv.component.html',
  styleUrls: ['./cv.component.css'],
})

export class CvComponent implements OnInit {
  @Input() dob: Date
  loadingCvRegistry = 'pending'
  cvRegistry!: RegistryCVDTO;
  base64CodinGame = '';
  fileToUpload: any;

  pivotSkills: PivotDigitalSkill[] = []
  pivotSkillRange = new FormGroup({
    start: new FormControl<Date | null>(null),
    end: new FormControl<Date | null>(null),
  });

  separatorKeysCodes: number[] = [ENTER, COMMA];
  fruitCtrl = new FormControl('');
  filteredFruits: Observable<DigitalSkillGroupDTO[]>;
  fruits: string[] = [];

  @ViewChild('fruitInput') fruitInput: ElementRef<HTMLInputElement>;
  skillAutocomplete: any = [];
  digitalSkillGroups: DigitalSkillGroupDTO[] = [];
  idTest: number = 4584216;

  skillListStatus = ''
  cvStatus = ''
  pivotSkillChanged = false
  fileErrorSize = false
  fileErrorExisted = false

  min_skill_date = new Date()
  max_skill_date = new Date()

  files: (CvFile | CodingameReport)[] = [];
  url: (CvFile | CodingameReport);

  role: string;

  constructor(
    private _dotNetService: DotNetService,
    private _datePickerRange: DatepickerRangeService,
    private _route: ActivatedRoute,
    public dialog: MatDialog,
    private snackBar: SnackbarService,
    private _roleGuard: RoleGuard,
    private _dictionary: DictionaryService,
    private _cookieService: CookieService
  ) {
  }

  ngOnInit(): void {
    this._datePickerRange.SetMinDateSkill(this.dob)
    this.min_skill_date = this._datePickerRange.min_skill
    this.max_skill_date = this._datePickerRange.max_skill

    this.cvStatus = 'Loading'
    this.skillListStatus = 'Loading'
    this.GetCVByIdRegistry(this.GetIdParams());
    this.GetDigitalSkillGroupList();

    //creare un metodo per togliere questo blocco di codice
    this.filteredFruits = this.fruitCtrl.valueChanges.pipe(
      startWith(''),
      map(value => this._filterGroup(value || '')),
    );


  }

  GetIdParams() {
    let id;
    this._route.params.subscribe({
      next: (params: Params) => {
        id = params['id'];
      },
    });
    return id;
  }

  GetCVByIdRegistry(id: number) {
    let responseCvRegistryById = this._dotNetService.GetCVRegistryByIdRegistry(id);
    let role = this._cookieService.get('role');
    if(role === 'administrator'){
      let responseStatusCG = this._dotNetService.GetStatusTestPdf(id);
      responseStatusCG.subscribe({
        next: res => {
          if (!res.body.includes("Waiting")) {
            let report: CodingameReport = {
              file: "data:application/pdf;base64," + res.body,
              name: "CodinGame.pdf"
            }

            this.files.push(report)
            console.log("this.files", this.files)
            if (!this.url) {
              this.url = report
              console.log("this.urlCG", this.url)
            }
            setTimeout(()=>{
              this.cvStatus = 'Loaded'
            },5000)
          }
        },
        error: (error) => {
          setTimeout(()=>{
            this.cvStatus = 'Loaded'
          },5000)
          this._dictionary.DisplayError(error.error)
        }
      })
    }



    responseCvRegistryById.subscribe({
      next: (res) => {
        this.cvRegistry = res.body;
        this.files = [...this.files, ...this.cvRegistry.cvFiles]
        console.log("this.filesAPI", this.files)
        if (this.cvRegistry.cvFiles.length > 0) {
          this.url = this.files[0]
          console.log("this.urlApi", this.url)
        }
        setTimeout(()=>{
          this.skillListStatus = 'Loaded'
        },5000)

      },
      error: (error) => {
        setTimeout(()=>{
          this.skillListStatus = 'Loaded'
        },5000)
        this._dictionary.DisplayError(error.error)
      },
    });
  }

  GetCVFile(idx: number) {
    this.url = this.files[idx]
  }

  FormatDate(date: Date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }
    return [day, month, year].join('/');
  }

  DeleteFile() {
    document.forms[0].reset()
    this.fileToUpload = null
    this.fileErrorExisted = false
    this.fileErrorSize = false
  }

  SetFileToUpload(event) {
    this.fileToUpload = event
    console.log("this.fileToUpload", this.fileToUpload)
  }

  SaveFile() {
    console.log(this.fileToUpload.target.files[0].name)
    this.HandleUpload(this.fileToUpload)
  }

  HandleUpload(event) {
    const file = event.target.files[0];
    let fileMBSize = parseFloat((file.size / (1024 * 1024)).toFixed(2));
    console.log(fileMBSize + ' MB');
    if (!this.cvRegistry.cvFiles.map(x => x.name).includes(file.name)) {
      if (fileMBSize <= 3) {
        this.fileToUpload = null
        const reader = new FileReader();
        let fileByteArray = [];
        reader.readAsDataURL(file);
        reader.onload = () => {
          fileByteArray.push(reader.result);
          console.log('HandleUpload: ' + reader.result);
          console.log(fileByteArray[0]);
          let userId = this.GetIdParams();
          if (this.cvRegistry) {
            console.log(fileByteArray)
            let cvFile: CvFile = {
              id: 0,
              file: fileByteArray[0],
              cvRegistryId: this.cvRegistry.id,
              name: event.target.files[0].name
            };
            this._dotNetService.CreateCVFile(cvFile).subscribe({
              next: (res) => {
                this.files.unshift(cvFile);
                console.log("Pdf aggiunto in un cvregistry esistente")
                this.snackBar.Show('File salvato')
                this.url = res.body;
                // (<HTMLSelectElement>document.getElementById('selector')).selectedIndex = 0
                this.cvRegistry.cvFiles.push(res.body)
              },
              error: (errorRes) => {
                console.error(errorRes.message)
              },
            });
          } else {
            this._dotNetService.CreateCV(userId).subscribe({
              next: (res) => {
                let cvFile: CvFile = {
                  id: 0,
                  file: fileByteArray[0],
                  cvRegistryId: res.body!.id,
                  name: fileByteArray[0].name
                };
                this._dotNetService.CreateCVFile(cvFile).subscribe({
                  next: (res) => {
                    this.files.push(cvFile)
                    console.log("Pdf aggiunto in un nuovo cvregistry")
                  },
                  error: (errorRes) => {
                    console.error(errorRes.message)
                  },
                });
              },
              error: (res) => {
                console.log('Error on creating cv registry');
              },
            });
          }
        };
      } else {
        this.fileErrorSize = true
        this.snackBar.Show("file non salvato")
        console.log("file non salvato")
      }
    } else {
      this.fileErrorExisted = true
      this.snackBar.Show("file non salvato")
      console.log("file non salvato")
    }
  }

  errorFileMessage() {
    if (this.fileErrorExisted)
      return "Il file è già presente"
    else //if(this.fileErrorSize)
      return "Il file è troppo grande ( >3 MB )"
  }

  GetDigitalSkillGroupList() {
    this._dotNetService.GetDigitalSkillGroupList().subscribe({
      next: res => {
        this.digitalSkillGroups = res.body;
        res.body.forEach(a => {
          let value: string[] = []
          a.digitalSkills.forEach(b => {
            value.push(b.name)
          })
          let test: SkillAutocomplete = {
            category: a.name,
            skillsName: value
          }
          this.skillAutocomplete.push(test);
        })
      }
    })
  }

  IsAdmin() {
    return this._roleGuard.CheckRole;
  }

  OpenSkillTable() {
    const dialogRef = this.dialog.open(CvSkillComponent, {
      width: '60vw',
      height: '450px',
      data: this.digitalSkillGroups,
      disableClose: true
    });

    dialogRef.keydownEvents().subscribe(event => {
      if (event.key === "Escape") {
        dialogRef.close()
      }
    });

    dialogRef.afterClosed().subscribe(res => {
      this._dotNetService.GetDigitalSkillGroupList().subscribe(
        res => {
          let skill: SkillAutocomplete[] = [];
          this.digitalSkillGroups = res.body;
          res.body.forEach(a => {
            let value: string[] = []
            a.digitalSkills.forEach(b => {
              value.push(b.name)
            })
            let test: SkillAutocomplete = {
              category: a.name,
              skillsName: value
            }
            skill.push(test)
          })
          this.skillAutocomplete = skill;
        }
      )
    });
  }

  updatePivotSkills() {
    this.cvRegistry.pivotDigitalSkills.forEach(skill => {
      console.log(skill)
      if (skill.id != 0) {
        this._dotNetService.PutPivotDigitalSkill(skill).subscribe({
          next: res => {
            this.snackBar.Show("Skill salvata con successo")
          }
        })
      } else {
        this._dotNetService.CreatePivotDigitalSkill(skill).subscribe({
          next: res => {
            this.snackBar.Show("Skill salvata con successo")
          }
        })
      }
    })
  }

  deletePivotSkill(id: number) {
    this._dotNetService.DeletePivotDigitalSkill(id).subscribe({
      next: res => {
        this.snackBar.Show("Skill eliminata con successo")
      },
      error: res => {
        this.snackBar.Show("Errore nell'eliminazione dela skill")
      }
    });
  }

  OpenWorkExperienceDialog(id: number) {
    let workExperience: WorkExperience;
    if (id > 0) {
      workExperience = this.cvRegistry.workExperiences.find(x => x.id == id);
    }
    const dialogRef = this.dialog.open(CvWorkExperienceComponent, {
      data: {
        id: this.cvRegistry.id,
        workExperience: workExperience
      }
    });

    dialogRef.afterClosed().subscribe(
      res => {
        if (res) {
          let found = false
          this.cvRegistry.workExperiences.forEach((experience, index) => {
            if (experience.id == res.workExperienceItem.id) {
              this.cvRegistry.workExperiences.splice(index, 1, res.workExperienceItem);
              found = true
              return
            }
          })
          if (!found)
            this.cvRegistry.workExperiences.push(res.workExperienceItem)
        }
      }
    )
  }

  DeleteWorkExperience(id: number) {
    const dialogRef = this.dialog.open(CvConfirmDeletDialogComponent, {
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(
      result => {
        if (result) {
          this._dotNetService.DeleteWorkExperience(id).subscribe(
            {
              next: res => {
                let workExperienceId = this.cvRegistry.workExperiences.findIndex(x => x.id == id)
                this.cvRegistry.workExperiences.splice(workExperienceId, 1);
                this.snackBar.Show('Campo nella sezione Esperienze lavorative eliminato')
              },
              error: res => {

              }
            }
          )
        }
      }
    )
  }


  OpenIstructionDialog(id: number) {
    let education: EducationAndTrainingExperience;
    if (id > 0) {
      education = this.cvRegistry.educationAndTrainingExperiences.find(x => x.id == id);
    }
    const dialogRef = this.dialog.open(CvIstructionComponent, {
      data: {
        id: this.cvRegistry.id,
        educationAndTrainingExperiences: education
      }
    });

    dialogRef.afterClosed().subscribe(
      res => {
        if (res) {
          let found = false
          this.cvRegistry.educationAndTrainingExperiences.forEach((experience, index) => {
            if (experience.id == res.istructionItem.id) {
              this.cvRegistry.educationAndTrainingExperiences.splice(index, 1, res.istructionItem);
              found = true
              return
            }
          })
          if (!found)
            this.cvRegistry.educationAndTrainingExperiences.push(res.istructionItem)
        }
      }
    )
  }

  DeleteIstruction(id: number) {
    const dialogRef = this.dialog.open(CvConfirmDeletDialogComponent, {
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(
      result => {
        if (result) {
          this._dotNetService.DeleteEducationAndTrainingExperience(id).subscribe(
            {
              next: res => {
                let istructionId = this.cvRegistry.educationAndTrainingExperiences.findIndex(x => x.id == id)
                this.cvRegistry.educationAndTrainingExperiences.splice(istructionId, 1);
                this.snackBar.Show('Campo nella sezione Istruzione eliminato')
              },
              error: res => {

              }
            }
          )
        }
      }
    )
  }

  DeleteCvFile(id) {
    const dialogRef = this.dialog.open(CvConfirmDeletDialogComponent, {
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(
      result => {
        if (result) {
          this._dotNetService.DeleteCvFile(id).subscribe(
            {
              next: res => {
                this.cvRegistry.cvFiles.splice(this.cvRegistry.cvFiles.findIndex(x => x.id == id), 1);
                this.files.splice(this.files.findIndex(x => x.id == id), 1)
                if(this.files){
                  this.url = this.files[0];
                }
                else this.url = null;
                this.snackBar.Show('File eliminato')
              },
              error: res => {

              }
            }
          )
        }
      }
    )
  }

  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();

    // Add our fruit
    if (value) {
      this.digitalSkillGroups.forEach(group => {
        group.digitalSkills.forEach(x => {
          if (x.name == value) {
            console.log(x)
            this.fruits.push(value);
            let pivotSkill: PivotDigitalSkill = {
              id: 0,
              name: x.name,
              cvRegistryId: this.cvRegistry.id,
              startDate: new Date(),
              endDate: new Date(),
              category: group.name,
              developRole: x.developRole
            }
            this.cvRegistry.pivotDigitalSkills.push(pivotSkill)
          }
        })
      })
    }

    // Clear the input value
    event.chipInput!.clear();

    this.fruitCtrl.setValue(null);
  }

  remove(pivotDigitalSkill: PivotDigitalSkill): void {
    const index = this.cvRegistry.pivotDigitalSkills.indexOf(pivotDigitalSkill);

    if (index >= 0) {
      this.cvRegistry.pivotDigitalSkills.splice(index, 1);
    }

    if (pivotDigitalSkill.id > 0) {
      this.deletePivotSkill(pivotDigitalSkill.id)
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.fruits.push(event.option.viewValue);

    this.digitalSkillGroups.forEach(group => {
      group.digitalSkills.forEach(x => {
        if (x.name == event.option.viewValue) {
          console.log(x)

          this.fruits.push(event.option.viewValue);
          let pivotSkill: PivotDigitalSkill = {
            id: 0,
            name: x.name,
            cvRegistryId: this.cvRegistry.id,
            startDate: new Date(),
            endDate: new Date(),
            category: group.name,
            developRole: x.developRole
          }
          this.cvRegistry.pivotDigitalSkills.push(pivotSkill)
        }
      })
    })
    this.fruitInput.nativeElement.value = '';
    this.fruitCtrl.setValue(null);
  }

  private _filterGroup(value: string): DigitalSkillGroupDTO[] {
    if (value) {
      return this.digitalSkillGroups
        .map(group => ({ id: group.id, name: group.name, digitalSkills: _filter(group.digitalSkills, value) }))
        .filter(group => group.name.length > 0);
    }

    return this.digitalSkillGroups;
  }

  pivotSkillUpdated() {
    this.pivotSkillChanged = true
  }
}

