import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Component, ElementRef, HostListener, Inject, OnInit, ViewChild } from '@angular/core';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { DevelopeRole, DigitalSkill, DigitalSkillGroupDTO } from 'src/app/Models/DTOs/Skills/SkillGroup/skillGroup';
import { ConnectableObservable, Subject } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EducationAndTrainingExperience, PersonalSkills, WorkExperience } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { CvComponent } from '../cv.component';
import { DIALOG_DATA } from '@angular/cdk/dialog';
import { enableDebugTools } from '@angular/platform-browser';
import { V } from '@angular/cdk/keycodes';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { DatepickerRangeService } from 'src/app/Services/General/DatepickerRange/datepicker-range.service';

@Component({
  selector: 'app-cv-dialogs',
  templateUrl: './cv-dialogs-instruction.component.html',
  styleUrls: ['./cv-dialogs.component.css']
})
export class CvIstructionComponent implements OnInit {

  res = false
  istructionForm = new FormGroup({
    organisationOrSchool: new FormControl('', [Validators.required, Validators.maxLength(30)]),
    qualificationAwarded: new FormControl('', [Validators.maxLength(30)]),
    address: new FormControl('', [Validators.maxLength(30)]),
    votesObtained: new FormControl(null, [Validators.required, Validators.min(0)]),
  })
  constructor(
    private dialogRef: MatDialogRef<CvSkillComponent>,
    private _dotNetService: DotNetService,
    private _snackBar: SnackbarService,
    @Inject(MAT_DIALOG_DATA) public istruction: {
      id: number,
      educationAndTrainingExperiences: EducationAndTrainingExperience
    },
  ) {
    dialogRef.disableClose = true;
   }
   @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.SetData();
    this.dialogRef.afterClosed().subscribe(
      () => {
        this.res = true
      }
    )
  }

  SetData() {
    console.log(this.istruction)
    if (this.istruction.educationAndTrainingExperiences != null) {
      this.istructionForm.controls.qualificationAwarded.setValue(this.istruction.educationAndTrainingExperiences.qualificationAwarded)
      this.istructionForm.controls.organisationOrSchool.setValue(this.istruction.educationAndTrainingExperiences.organisationOrSchool)
      this.istructionForm.controls.address.setValue(this.istruction.educationAndTrainingExperiences.address)
      this.istructionForm.controls.votesObtained.setValue(this.istruction.educationAndTrainingExperiences.votesObtained)
    }
  }

  OnNoClick() {
    this.dialogRef.close();
  }

  Save() {
    if (this.istruction.educationAndTrainingExperiences == null) {
      this.istruction = {
        id: this.istruction.id,
        educationAndTrainingExperiences: {
          id: 0,
          qualificationAwarded: this.istructionForm.value.qualificationAwarded,
          organisationOrSchool: this.istructionForm.value.organisationOrSchool,
          address: this.istructionForm.value.address,
          votesObtained: this.istructionForm.value.votesObtained,
          cvRegistryId: this.istruction.id
        }
      }
      //create
      this._dotNetService.CreateEducationAndTrainingExperience(this.istruction.educationAndTrainingExperiences).subscribe({
        next: res => {
          this.dialogRef.close({istructionItem: this.istruction.educationAndTrainingExperiences});
          this._snackBar.Show("Le modifiche sono state salvate")
        }, error: res => {

        }
      })
    } else {
      this.istruction = {
        id: this.istruction.id,
        educationAndTrainingExperiences: {
          id: this.istruction.educationAndTrainingExperiences.id,
          qualificationAwarded: this.istructionForm.value.qualificationAwarded,
          organisationOrSchool: this.istructionForm.value.organisationOrSchool,
          address: this.istructionForm.value.address,
          votesObtained: this.istructionForm.value.votesObtained,
          cvRegistryId: this.istruction.id
        }
      }

      //put
      this._dotNetService.PutEducationAndTrainingExperience(this.istruction.educationAndTrainingExperiences).subscribe({
        next: res => {
          this.dialogRef.close({istructionItem: this.istruction.educationAndTrainingExperiences});
          this._snackBar.Show("Le modifiche sono state salvate")
        }, error: res => {

        }
      })
    }
  }
}

@Component({
  selector: 'app-cv-dialogs-working-experience',
  templateUrl: './cv-dialogs-working-experience.component.html',
  styleUrls: ['./cv-dialogs.component.css']
})
export class CvWorkExperienceComponent implements OnInit {

  workExperienceForm = new FormGroup({
    workingPosition: new FormControl('', Validators.required),
    agency: new FormControl('', Validators.required),
    location: new FormControl('', Validators.required),
    startDate: new FormControl<Date>(null, Validators.required),
    endDate: new FormControl<Date>(null, Validators.required)
  })
  max_date = new Date()
  min_date = new Date()

  constructor(
    private dialogRef: MatDialogRef<CvSkillComponent>,
    private _dotNetService: DotNetService,
    private _snackBar: SnackbarService,
    private _datePickerRange: DatepickerRangeService,
    @Inject(MAT_DIALOG_DATA) public workExperience: {
      id: number,
      workExperience: WorkExperience
    },
  ) {
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.min_date = this._datePickerRange.min_dob
    this.max_date = new Date()
    this.SetData();
  }

  SetData() {
    console.log(this.workExperience)
    if (this.workExperience.workExperience != null) {
      console.log("settando")
      this.workExperienceForm.controls.agency.setValue(this.workExperience.workExperience.agency)
      this.workExperienceForm.controls.location.setValue(this.workExperience.workExperience.location)
      this.workExperienceForm.controls.workingPosition.setValue(this.workExperience.workExperience.workingPosition)
      this.workExperienceForm.controls.startDate.setValue(this.workExperience.workExperience.startDate)
      this.workExperienceForm.controls.endDate.setValue(this.workExperience.workExperience.endDate)
    }
  }

  OnNoClick() {
    this.dialogRef.close();
  }

  Save() {

    if (this.workExperience.workExperience == null) {
      this.workExperience = {
        id: this.workExperience.id,
        workExperience: {
          id: 0,
          agency: this.workExperienceForm.value.agency,
          location: this.workExperienceForm.value.location,
          workingPosition: this.workExperienceForm.value.workingPosition,
          startDate: new Date(this.GetIsoDate(this.workExperienceForm.value.startDate)),
          endDate: new Date(this.GetIsoDate(this.workExperienceForm.value.endDate)),
          cvRegistryId: this.workExperience.id
        }
      }
      //create
      this._dotNetService.CreateWorkExperience(this.workExperience.workExperience).subscribe({
        next: res => {
          this.dialogRef.close({workExperienceItem: this.workExperience.workExperience});
          this._snackBar.Show("Le modifiche sono state salvate")
        }, error: res => {

        }
      })
    } else {
      this.workExperience = {
        id: this.workExperience.id,
        workExperience: {
          id: this.workExperience.workExperience.id,
          agency: this.workExperienceForm.value.agency,
          location: this.workExperienceForm.value.location,
          workingPosition: this.workExperienceForm.value.workingPosition,
          startDate: new Date(this.GetIsoDate(this.workExperienceForm.value.startDate)),
          endDate: new Date(this.GetIsoDate(this.workExperienceForm.value.endDate)),
          cvRegistryId: this.workExperience.id
        }
      }

      //put
      this._dotNetService.PutWorkExperience(this.workExperience.workExperience).subscribe({
        next: res => {
          this.dialogRef.close({workExperienceItem: this.workExperience.workExperience});
          this._snackBar.Show("Le modifiche sono state salvate")
        }, error: res => {

        }
      })
    }
  }

  GetIsoDate(date: Date){
    const d = new Date(date)
    // This will return an ISO string matching your local time.
    return new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes() - d.getTimezoneOffset()).toISOString();
  }
}

@Component({
  selector: 'app-cv-dialogs-skill',
  templateUrl: './cv-dialogs-skill.component.html',
  styleUrls: ['./cv-dialogs.component.css']
})
export class CvSkillComponent implements OnInit {
  @ViewChild('inputCategoryName') inputCategoryName: ElementRef;

  skillGroupObservable = new Subject<DigitalSkillGroupDTO[]>();
  skillGroupObservable$ = this.skillGroupObservable.asObservable();

  devRoles = DevelopeRole;
  skillGroupNames: string[] = [];

  newSkillName: string;
  newCategoryName: string = "";
  newSkill = {
    name: '',
    digitalSkillGroup: ''
  }

  constructor(
    private _dotNetService: DotNetService,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public skillsGroup: DigitalSkillGroupDTO[],
  ) { }

  ngOnInit(): void {
    this.ObserveSkillGroup();
    this.GetSkillGroups();
  }

  ObserveSkillGroup() {
    this.skillGroupObservable$.subscribe(
      res => {
        this.skillsGroup = res;
        this.skillGroupNames = this.skillsGroup.map(x => x.name)
      }
    )
  }

  GetSkillGroups() {
    this._dotNetService.GetDigitalSkillGroupList().subscribe({
      next: res => {
        this.skillsGroup = res.body
        this.skillGroupNames = this.skillsGroup.map(x => x.name)
      }
    })
  }

  getDevRoleLable(dev: number) {
    return this.devRoles.filter(x => x.value == dev)[0].label;
  }

  openEditCategoryDialog(digitalSkillGroup: DigitalSkillGroupDTO) {
    const dialogRef = this.dialog.open(CvUpdateCategoryComponent, {
      width: '300px',
      data: digitalSkillGroup.name,
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == null) return;
      if (digitalSkillGroup.name == result) {
        console.log("Non ci sono modifiche")
        return
      };
      digitalSkillGroup.name = result

      this.updateCategory(digitalSkillGroup)
    });
  }

  openEditSkillDialog(skill: DigitalSkill) {
    const dialogRef = this.dialog.open(CvUpdateSkillComponent, {
      width: '250px',
      data: skill,
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == null) return;
      if (skill.name == result.name && skill.developRole == result.developRole) {
        console.log("Non ci sono modifiche")
        return
      };
      skill.name = result.name,
        skill.developRole = result.developRole
      this.updateSkill(skill)
    });
  }

  createCategory(groupName: string) {
    console.log(groupName)
    let skillGroup: DigitalSkillGroupDTO = {
      id: 0,
      name: groupName,
      digitalSkills: []
    }
    console.log(skillGroup)
    this._dotNetService.CreateDigitalSkillGroup(skillGroup).subscribe({
      next: res => {
        this.skillGroupObservable.next(res.body);
      },
      error: res => {
      }
    })
    this.newCategoryName = '';
  }

  updateCategory(digitalSkillGroup: DigitalSkillGroupDTO) {
    this._dotNetService.UpdateDigitalSkillGroup(digitalSkillGroup).subscribe({
      next: res => {
        this.skillGroupObservable.next(res.body);
      },
      error: res => {

      }
    })
  }

  deleteCategory(digitalSkillGroup: DigitalSkillGroupDTO) {
    const dialogRef = this.dialog.open(CvConfirmDeletDialogComponent, {
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(
      result => {
        if(result){
          this._dotNetService.DeleteDigitalSkillGroup(digitalSkillGroup).subscribe({
              next: res => {
                this.skillGroupObservable.next(res.body);
              },
              error: res => {

              }
          })
         }
      }
    )
  }


  createSkill(skillName: any, categoryName: string, devRole: number) {
    let digitalSkill: DigitalSkill = {
      id: 0,
      digitalSkillGroupName: categoryName,
      name: skillName.value,
      developRole: devRole
    }
    this._dotNetService.CreateDigitalSkill(digitalSkill).subscribe(
      {
        next: res => {
          this.skillGroupObservable.next(res.body);
        },
        error: res => {

        }
      }
    )
  }

  updateSkill(digitalSkill: DigitalSkill) {
    this._dotNetService.UpdateDigitalSkill(digitalSkill).subscribe(
      {
        next: res => {
          this.skillGroupObservable.next(res.body);
        },
        error: res => {

        }
      }
    )
  }

  deleteDigitalSkill(skill: DigitalSkill) {
    const dialogRef = this.dialog.open(CvConfirmDeletDialogComponent, {
      width: '400px',
      data: skill
    });

    dialogRef.afterClosed().subscribe(
      result => {
        if (result) {
          this._dotNetService.DeleteDigitalSkill(skill).subscribe(
            {
              next: res => {
                this.skillGroupObservable.next(res.body);
              },
              error: res => {

              }
            }
          )
        }
      }
    )
  }

  OnCloseClick(){
    this.dialog.closeAll()
  }
}

@Component({
  selector: 'app-update-skill',
  templateUrl: './cv-dialogs-update-skill.component.html',
  styleUrls: ['./cv-dialogs.component.css']
})
export class CvUpdateSkillComponent {
  devRoles = DevelopeRole

  constructor(
    public dialogRef: MatDialogRef<CvSkillComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DigitalSkill,
  ) {
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  skill: DigitalSkill = {
    id: this.data.id,
    developRole: this.data.developRole,
    name: this.data.name,
    digitalSkillGroupName: this.data.digitalSkillGroupName
  }

  onNoClick(): void {
    this.skill = this.data
    this.dialogRef.close();
  }
}


@Component({
  selector: 'app-update-category',
  templateUrl: './cv-dialogs-update-skill-category.component.html',
  styleUrls: ['./cv-dialogs.component.css']
})
export class CvUpdateCategoryComponent {

  constructor(
    public dialogRef: MatDialogRef<CvSkillComponent>,
    @Inject(MAT_DIALOG_DATA) public data: string,
  ) {
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  newCategoryName = this.data;

  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'app-update-category',
  templateUrl: './cv-dialogs-delete-skill-category.component.html',
  styleUrls: ['./cv-dialogs.component.css']
})
export class CvConfirmDeletDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<CvSkillComponent, CvComponent>,
    @Inject(MAT_DIALOG_DATA) public data: string,
  ) {
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}




