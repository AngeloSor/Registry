import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CvSkillComponent } from './cv-dialogs.component';

describe('CvDialogsComponent', () => {
  let component: CvSkillComponent;
  let fixture: ComponentFixture<CvSkillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CvSkillComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CvSkillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
