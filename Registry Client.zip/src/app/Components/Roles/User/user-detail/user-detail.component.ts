import { MyFeedbackComponent } from './dialogs/my-feedback/my-feedback.component';
import { FeedbackComponent } from './../../Technician/feedback/feedback.component';
import { Location } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
import { KeyCLoakService } from 'src/app/Services/Apis/KeyCloak/key-cloak.service';
import { RoleGuard } from 'src/app/Services/Guards/Role/role.guard';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Genders, UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { ImageDTO } from 'src/app/Models/DTOs/User/image-dto';
import { UserEditComponent } from '../user-edit/user-edit.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteUserDialogComponent } from './dialogs/delete-user-dialog/delete-user-dialog.component';
import { EventScheduledComponent } from '../../Technician/event-scheduled/event-scheduled.component';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { ThisReceiver } from '@angular/compiler';
import { RestoreUserDialogComponent } from './dialogs/restore-user-dialog/restore-user-dialog.component';
import { DisableUserDialogComponent } from './dialogs/disable-user-dialog/disable-user-dialog.component';
import { ConditionDTO } from 'src/app/Models/DTOs/User/condition-dto';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {

  genders = Genders;
  genderLabl = "";
  conditionLabl = "";
  isTechnician = false;
  user!: UserDTO;
  birthDate!: string;
  accountImage!: ImageDTO;
  conditions : ConditionDTO[] = []
  oldId: number;
  loaded: boolean = null;

  constructor(
    private _activatedRoute: ActivatedRoute,
    private _dotNetService: DotNetService,
    private _keyCloakService: KeyCLoakService,
    private dialog: MatDialog,
    private _router: Router,
    public roleGuard: RoleGuard,
    private _snackBar: SnackbarService,
    private _cookieService: CookieService,
    private location: Location,
    private route: ActivatedRoute
  ) { }


  ngOnInit(): void {
    this.loaded = false
    this.GetConditions()
    this.route.params.subscribe(res => {
      this.oldId = res['id']
    })
    this.GetIdByRoute()
  }

  GetConditions(){
    this._dotNetService.GetAllConditions().subscribe({
      next: res => {
        this.loaded = false
        console.log(res.body)
        this.conditions = res.body
        this.loaded = true
      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  GetIdByRoute() {
    if(this.roleGuard.CheckRole){
      this._activatedRoute.params.subscribe(
        (params: Params) => {
          this.oldId = params['id']
          this.GetUserById(this.oldId)
        }
      );
    } else {
      let newId = this.oldId;
      this._dotNetService.GetUserByEmail(this._cookieService.get('emailAuth')).subscribe({
        next: res => {
          this.loaded = false
          if(res.body.id == this.oldId){
            this._activatedRoute.params.subscribe(
              (params: Params) => {
                console.log("params", params['id'])
                this.oldId = params['id']
                this.GetUserById(this.oldId)

              }
            );
          } else {
            this.location.back()
          }
          this.loaded = true
        }
      })
    }
  }

  FormatDate(date: Date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) {
      month = '0' + month;
    }

    if (day.length < 2) {
      day = '0' + day;
    }

    this.birthDate = [day, month, year].join('/');
  }

  GetUserById(id: number) {
    console.log("id", id)
    this._dotNetService.GetRegistryById(id).subscribe({
      next: res => {
        console.log("GetUserById - UserDetail.ts", this.conditions.filter(x => x.id == res!.body!.conditionId!))
        this.genderLabl = this.genders.filter(x => x.value == res!.body!.gender!)[0].label;
        this.conditionLabl = this.conditions.find(x => x.id == res!.body!.conditionId!)?.name;
        this.user = res.body!;

        this.isTechnician = res.body.technician;
        console.log(this.isTechnician)
        console.log(this.roleGuard.GetRole)
        this.FormatDate(new Date(this.user.birthDate))
        console.log("res.body", res.body)
        this.accountImage = res.body.pictureProfile;


      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    }

    );
  }

  openEditDialog() {
    const dialogRef = this.dialog.open(UserEditComponent, {
      width: '1500px',
      height: '800px',
      data: { user: this.user, image: this.accountImage }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log("Result",result)
        //get utente da keycloak
        this._keyCloakService.GetUser(this.user?.email).subscribe({
          next: userKc => {
            userKc.body[0].firstName = this.user?.name;
            userKc.body[0].lastName = this.user?.surname;
            console.log(userKc.body[0].firstName);
            //update user keycloak
            this._keyCloakService.UpdateUser(userKc.body[0]).subscribe({
              next: resKc => {
                //update user db
                this._dotNetService.UpdateUser(this.user).subscribe({
                  next: resApi => {
                    if(result.image){
                      if(this.accountImage){
                        this.accountImage.picture = result.image
                        //update immagine de profilo db
                        this._dotNetService.PutPictureProfile(this.accountImage ).subscribe({
                          next: (res) => {
                            console.log('creazione immagine di profilo nel db con successo');
                          },
                          error: (error) => {
                            this._dotNetService.DisplayError(error.error)
                            this._snackBar.Show("Errore nel salvataggio del'utente")
                          }
                        });
                      }else{
                        console.log("image", result.image)
                        //in caso di immagine non presente
                        let image: ImageDTO = {
                          id : 0,
                          picture : result.image,
                          registryId : resApi.body.id
                        }
                        this._dotNetService.CreatePictureProfile(image).subscribe({
                          next: (res) => {
                            console.log('creazione immagine di profilo nel db con successo');
                          },
                          error: (error) => {
                            this._dotNetService.DisplayError(error.error)
                            this._snackBar.Show("Errore nel salvataggio dell'immagine profilo utente")
                          }
                        });
                      }
                    }
                    console.log("resAPi", resApi.body)
                    this._router.navigate(['/admin/dashboard'])
                    this._snackBar.Show('L\'utente è stato modificato')
                  }
                })
              },
              error: error => {
                this._dotNetService.DisplayError(error.error)
              }
            })

          },
          error: error => {
            this._dotNetService.DisplayError(error.error)
          }
        })
      }
    });
  }

  Feedback(){
    const dialogRef = this.dialog.open(MyFeedbackComponent, {
      data: this.oldId,
      width: '2000px',
      height: '900px',
    });

    // dialogRef.afterClosed().subscribe(result => {
    //   if (result) {
    //     this._alert.Success("Feedback inviato con successo")
    //   }
    // })
  }

  openDisableDialog() {
    const dialogRef = this.dialog.open(DisableUserDialogComponent, {
      width: '400px',
      height: '200px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._keyCloakService.DisableUser(this.user.idKeycloak).subscribe({
          next: resKc => {
            this._dotNetService.DisableUser(this.user.id).subscribe({
              next: resApi => {
                this._router.navigate(['/admin/dashboard'])
                this._snackBar.Show('L\'utente è stato disabilitato')
              }, error: error => {
                this._dotNetService.DisplayError(error.error)
              }
            })
          }
        })
      }
    })
  }

  openDeleteDialog() {
    const dialogRef = this.dialog.open(DeleteUserDialogComponent, {
      width: '400px',
      height: '200px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._keyCloakService.DeleteUser(this.user.idKeycloak).subscribe({
          next: resKc => {
            this._dotNetService.DeleteUser(this.user.id).subscribe({
              next: resApi => {
                this._router.navigate(['/admin/dashboard'])
                this._snackBar.Show('L\'utente è stato eliminato')
              }, error: error => {
                this._dotNetService.DisplayError(error.error)
              }
            })
          }
        })
      }
    })
  }

  openRestoreDialog(){
    const dialogRef = this.dialog.open(RestoreUserDialogComponent, {
      width: '400px',
      height: '150px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._keyCloakService.RestoreUser(this.user.idKeycloak).subscribe({
          next: resKc => {
            this._dotNetService.RestoreUser(this.user.id).subscribe({
              next: resApi => {
                this._router.navigate(['/admin/dashboard'])
                this._snackBar.Show('L\'utente è stato riabilitato')
              }, error: error => {
                this._dotNetService.DisplayError(error.error)
              }
            })
          }
        })
      }
    })
  }

  openEventDialog(){
    const dialogRef = this.dialog.open(EventScheduledComponent, {
      width: '1100px',
      height: '800px',
      data: { userId: this.user.id }
    });

    dialogRef.afterClosed().subscribe({
      next: res => {

      }, error: errorRes => {

      }
    })
  }


  ShowSnackBar(message: string) {
    this._snackBar.Show(message);
  }

}
