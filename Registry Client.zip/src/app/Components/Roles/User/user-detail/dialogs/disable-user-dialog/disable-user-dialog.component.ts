import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { UserDetailComponent } from '../../user-detail.component';

@Component({
  selector: 'app-disable-user-dialog',
  templateUrl: './disable-user-dialog.component.html',
  styleUrls: ['./disable-user-dialog.component.css']
})
export class DisableUserDialogComponent implements OnInit {

  constructor(
    private dialogRef: MatDialogRef<UserDetailComponent>,
  ) { 
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

  onNoClick(){
    this.dialogRef.close();
  }


}
