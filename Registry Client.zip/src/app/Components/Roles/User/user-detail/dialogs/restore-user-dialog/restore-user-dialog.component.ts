import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import {UserDetailComponent} from '../../user-detail.component';

@Component({
  selector: 'app-restore-user-dialog',
  templateUrl: './restore-user-dialog.component.html',
  styleUrls: ['./restore-user-dialog.component.css']
})
export class RestoreUserDialogComponent implements OnInit {

  constructor(
    private dialogRef: MatDialogRef<UserDetailComponent>,
  ) { 
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

  onNoClick(){
    this.dialogRef.close();
  }


}
