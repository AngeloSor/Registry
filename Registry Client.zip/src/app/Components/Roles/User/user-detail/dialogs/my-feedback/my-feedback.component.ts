import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import {MatIconModule} from '@angular/material/icon';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { UserDetailComponent } from '../../user-detail.component';
import { FeedbackService } from 'src/app/Services/Apis/Net/Feedback/feedback.service';
import { ActivatedRoute, Router } from '@angular/router';
import { InterviewFeedbackDTO } from 'src/app/Models/DTOs/InterviewFeedback/interviewFeedbackDTO';

@Component({
  selector: 'app-my-feedback',
  templateUrl: './my-feedback.component.html',
  styleUrls: ['./my-feedback.component.css']
})
export class MyFeedbackComponent implements OnInit {

  technicianId: number;
  feedbackList: InterviewFeedbackDTO[] = [];
  panelOpenState = false;
  loaded: boolean = null;

  constructor(
    private route: ActivatedRoute,
    private feedbackService: FeedbackService,
    private router: Router,
    private dialogRef: MatDialogRef<MyFeedbackComponent>,
    ) {
      dialogRef.disableClose = true;
    }
    @HostListener('window:keyup.esc') onKeyUp() {
      this.dialogRef.close();
    }


  ngOnInit(): void {
    this.loaded = false
    this.getId();
    this.getInterviews();
  }

    //#region getId
    getId(){
      const currentUrl = window.location.href;
      const id = currentUrl.match(/\/(\d+)$/)[1];
      localStorage.setItem('id', id);
    }

    onCancel(){
      this.dialogRef.close();
    }

    viewFeedback(id: number) {
      this.router.navigate(['yourFeedback', id]);
      this.dialogRef.close();
    }
    //#endregion

    getInterviews(): void {
      this.technicianId = JSON.parse(localStorage.getItem('id'));
      console.debug(this.technicianId);
      this.feedbackService.getFeedbackByTechnicianId(this.technicianId).subscribe(
        data => {
          this.loaded = false
          this.feedbackList = data;
          console.debug(this.feedbackList);
          this.loaded = true
        },
        error => {
          console.log(error);
        }
      );
    }

    getResultIcon(isPassed: boolean){
      if(isPassed){
        return "check_circle"
      }
      return "cancel"
    }
}
