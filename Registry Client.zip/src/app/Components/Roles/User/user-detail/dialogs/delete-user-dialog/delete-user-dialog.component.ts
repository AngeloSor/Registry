import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { UserDetailComponent } from '../../user-detail.component';

@Component({
  selector: 'app-delete-user-dialog',
  templateUrl: './delete-user-dialog.component.html',
  styleUrls: ['./delete-user-dialog.component.css']
})
export class DeleteUserDialogComponent implements OnInit {

  constructor(
    private dialogRef: MatDialogRef<UserDetailComponent>,
  ) { 
    dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

  onNoClick(){
    this.dialogRef.close();
  }


}
