import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestoreUserDialogComponent } from './restore-user-dialog.component';

describe('RestoreUserDialogComponent', () => {
  let component: RestoreUserDialogComponent;
  let fixture: ComponentFixture<RestoreUserDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestoreUserDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RestoreUserDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
