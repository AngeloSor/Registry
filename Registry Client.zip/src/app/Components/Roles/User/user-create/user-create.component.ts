import { MatDialogRef } from '@angular/material/dialog';
import { DictionaryService } from './../../../../Services/General/Dictionary/dictionary.service';
import { KeyCloakGroupDTO } from './../../../../Models/DTOs/KeyCloakGroups/keycloakGroup';

import { Component, HostListener, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  SelectControlValueAccessor,
  Validators,
} from '@angular/forms';

import { Router } from '@angular/router';
import { Genders, UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { KeyCLoakService } from 'src/app/Services/Apis/KeyCloak/key-cloak.service';
import { MyErrorStateMatcher } from 'src/app/Models/Entities/MyErrorStateMatcher/MyErrorStateMatcher';
import { KeyCloakUserDTO } from 'src/app/Models/DTOs/User/keycloak-user-dto';
import { ImageDTO } from 'src/app/Models/DTOs/User/image-dto';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { AdminDashboardComponent } from '../../Admin/admin-dashboard/admin-dashboard.component';
import { DatepickerRangeService } from 'src/app/Services/General/DatepickerRange/datepicker-range.service';
import { ConditionDTO } from 'src/app/Models/DTOs/User/condition-dto';

/** Error when invalid control is dirty, touched, or submitted. */
@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrls: ['./user-create.component.css'],
})
export class UserCreateComponent implements OnInit {
  errorMatcher = new MyErrorStateMatcher();

  addUserForm = new FormGroup({
    name: new FormControl('', [ Validators.required, Validators.maxLength(20)]),
    surname: new FormControl('', [
      Validators.required,
      Validators.maxLength(20),
    ]),
    email: new FormControl('', [Validators.required, Validators.email]),
    birthdate: new FormControl<Date>(null, Validators.required),
    fiscalCode: new FormControl('', [
      Validators.required,
      Validators.maxLength(16),
      Validators.pattern(
        '^[A-Za-z]{6}[0-9]{2}[A-Za-z]{1}[0-9]{2}[A-Za-z]{1}[0-9]{3}[A-Za-z]{1}$'
      ),
    ]),
    city: new FormControl('', [Validators.required, Validators.maxLength(30)]),
    province: new FormControl('', [
      Validators.required,
      Validators.maxLength(2),
      // Validators.pattern("[A-Z ]*")
    ]),
    street: new FormControl('', [
      Validators.required,
      Validators.maxLength(100),
    ]),
    streetNumber: new FormControl<string>('', [
      Validators.required,
      Validators.maxLength(6),
      Validators.pattern('^[0-9]{1,3}(/?[A-z]{1,2})?$'),
    ]), // ^[A-Za-z0-9]*$
    zipCode: new FormControl<number>(null, [
      Validators.required,
      Validators.min(0),
      Validators.max(99999),
      Validators.minLength(5),
    ]),
    gender: new FormControl<number>(null, Validators.required),
    businessManager: new FormControl('', [
      Validators.required,
      Validators.maxLength(50),
    ]),
    conditionId: new FormControl<number>(null, Validators.required),
    password: new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.pattern(
        '(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-zd$@$!%*?&].{8,}'
      ),
    ]),
    role: new FormControl(false),
  });

  genders = Genders;
  conditions: ConditionDTO[] = [];
  groups: KeyCloakGroupDTO[] = [];
  accountImage: any;
  date = Date.now();
  max_date = new Date();
  min_date = new Date();

  constructor(
    private router: Router,
    private _keyCloakService: KeyCLoakService,
    private _dotNetService: DotNetService,
    private _snackBar: SnackbarService,
    private _dictionaryService: DictionaryService,
    private dialogRef: MatDialogRef<AdminDashboardComponent>,
    private _datePickerRange: DatepickerRangeService
  ) {
    this.dialogRef.disableClose = true;
  }
  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.min_date = this._datePickerRange.min_dob;
    this.max_date = this._datePickerRange.max_dob;
    this.GetConditions();
    this.GetGroups();
    this.conditionValidate();
  }

  GetConditions() {
    this._dotNetService.GetAllConditions().subscribe({
      next: (res) => {
        console.log(res.body);
        this.conditions = res.body;
      },
      error: (error) => {
        this._dotNetService.DisplayError(error.error);
      },
    });
  }

  GetGroups() {
    this._keyCloakService.GetGroupId().subscribe({
      next: (res) => {
        console.log(res.body);
        this.groups = res.body;
      },
    });
  }

  createUser() {
    let userControls = this.addUserForm.value
    console.debug(userControls);
    console.log(this.addUserForm);

    let user: UserDTO = {
      email: userControls.email,
      name: userControls.name,
      surname: userControls.surname,
      birthDate: userControls.birthdate,
      fiscalCode: userControls.fiscalCode,
      city: userControls.city,
      province: userControls.province,
      street: userControls.street,
      streetNumber: userControls.streetNumber,
      zipCode: userControls.zipCode,
      gender: userControls.gender,
      businessManager: userControls.businessManager,
      conditionId: userControls.conditionId,
      password: userControls.password,
      technician: userControls.role,
    };

    if (userControls.role === true) {
      user.conditionId = 2
    }
    console.log(user);

    let keyCloakUser: KeyCloakUserDTO = {
      username: user.email,
      enabled: true,
      totp: false,
      emailVerified: true,
      firstName: user.name,
      lastName: user.surname,
      email: user.email,
      disableableCredentialTypes: [],
      requiredActions: [],
      notBefore: 0,
      access: {
        manageGroupMembership: true,
        view: true,
        mapRoles: true,
        impersonate: true,
        manage: true,
      },
    };

    //creazione utente su keycloak
    this._keyCloakService.CreateUser(keyCloakUser).subscribe({
      next: (resKc) => {
        //get user su keycloak per ottenere idKeycloak
        this._keyCloakService.GetUser(user.email).subscribe({
          next: (resKcUser) => {
            user.idKeycloak = resKcUser!.body![0].id;
            //set del ruolo utente su keycloak
            this._keyCloakService
              .SetUserRole(
                this.groups.find((x) => x.name == 'user').id,
                user.idKeycloak
              ).subscribe({
                next: (resRole) => {
                  //set password utente su keycloak
                  this._keyCloakService
                    .SetPassword(user.password!, user.idKeycloak!)
                    .subscribe({
                      next: (resPw) => {
                        user.id = 0
                        console.log('password settata con successo');
                        let image: ImageDTO = {
                          id: 0,
                          picture: null,
                          registryId: 0,
                        };
                        if (this.accountImage) {
                          image.picture = this.accountImage
                        }
                        let message = {
                          registryDTO: user,
                          pictureProfileDTO: image,
                        };
                        //creazione utente su db
                        this._dotNetService.CreateUser(message).subscribe({
                          next: (resApi) => {
                            user.id = resApi.body.id
                            console.log('utente inserito nel db');
                            this.dialogRef.close({ user: user })
                            this._snackBar.Show("Utente creato con successo")
                          },
                          error: (error) => {
                            this._keyCloakService
                              .DeleteUser(user.idKeycloak)
                              .subscribe(() =>
                                console.log('utente kc Disabilitato')
                              );
                            this._dictionaryService.DisplayError(error.error);
                            this._snackBar.Show('Errore nel salvataggio utente');
                          },
                        });
                      },
                      error: (error) => {
                        this._keyCloakService
                          .DeleteUser(user.idKeycloak)
                          .subscribe(() =>
                            console.log('utente kc Disabilitato')
                          );
                        this._dictionaryService.DisplayError(error.error);
                        this._snackBar.Show('Errore nel salvataggio utente');
                      },
                    });
                },
                error: (error) => {
                  this._keyCloakService
                    .DeleteUser(user.idKeycloak)
                    .subscribe(() => console.log('utente kc Disabilitato'));
                  this._dictionaryService.DisplayError(error.error);
                  this._snackBar.Show('Errore nel salvataggio utente');
                },
              });
          },
          error: (error) => {
            this._keyCloakService
              .DeleteUser(user.idKeycloak)
              .subscribe(() => console.log('utente kc Disabilitato'));
            this._dictionaryService.DisplayError(error.error);
            this._snackBar.Show('Errore nel salvataggio utente');
          },
        });
      },
      error: (error) => {
        let message: string;
        if (error.status == 409) {
          message = 'Un utente è già presente con la stessa email';
        } else {
          message = 'Errore nel salvataggio utente';
        }
        this._snackBar.Show(message);
        this._dictionaryService.DisplayError(error.error);
      },
    });
  }

  conditionValidate() {
    if (this.addUserForm.controls.role.value == true) {
      this.addUserForm.controls.conditionId.removeValidators([Validators.required]);
    } else {
      this.addUserForm.controls.conditionId.addValidators([Validators.required]);
    }
    this.addUserForm.controls.conditionId.updateValueAndValidity();
    console.debug(this.addUserForm.controls.role);
    console.debug(this.addUserForm.controls.conditionId);
  }

  SetFileToUpload(event) {
    let file = event.target.files[0];
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.accountImage = reader.result;
    };
    reader.onerror = function (error) {
      console.log('Error: ', error);
    };
  }
  onNoClick() {
    this.dialogRef.close();
  }
}
