import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { PageEvent } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { UserCreateComponent } from '../../User/user-create/user-create.component';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { KeyCloakGroupDTO } from 'src/app/Models/DTOs/KeyCloakGroups/keycloakGroup';
import { KeyCLoakService } from 'src/app/Services/Apis/KeyCloak/key-cloak.service';
import { ImageDTO } from 'src/app/Models/DTOs/User/image-dto';
import { SPACE } from '@angular/cdk/keycodes';
import { CookieService } from 'ngx-cookie-service';
import { ConditionDTO } from 'src/app/Models/DTOs/User/condition-dto';

import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
})
export class AdminDashboardComponent implements OnInit {

  users!: UserDTO[];
  usersToShow!: UserDTO[];
  maxId: any;
  component = 'AdminDashboard';
  displayedColumns: string[] = [
    'name',
    'surname',
    'email',
    'businessManager',
    'condition',
    'cv',
    'cg'
  ];

  dashBoardLoadStatus: string;

  pageSize = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25];
  showFirstLastButtons = true;
  isDeleted :boolean;
  groups: KeyCloakGroupDTO[] = []
  conditions : ConditionDTO[] = []

  myFilter = new FormControl('');
  options: string[] = ["user.name","user.surname"];
  filteredOptions: Observable<string[]>;

  constructor(
    private _dotNetService: DotNetService,
    private router: Router,
    private _keyCloakService: KeyCLoakService,
    private _cookieService: CookieService,
    private _dialog: MatDialog
  ) { }

  ngOnInit(): void {
    this.GetConditions()
    this.GetGroups()
    if(sessionStorage.getItem('isDeleted') != null){
      this.isDeleted = JSON.parse(sessionStorage.getItem('isDeleted'))
    }
    else {
      this.isDeleted = false;
    }
    this.GetAllUserData();

    this.filteredOptions = this.myFilter.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  GetConditions(){
    this._dotNetService.GetAllConditions().subscribe({
      next: res => {
        console.log(res.body)
        this.conditions = res.body
      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  GetGroups() {
    this._keyCloakService.GetGroupId().subscribe({
      next: res => {
        console.log(res.body)
        this.groups = res.body
      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  GetAllUserData() {
    this.dashBoardLoadStatus = "Loading"
    setTimeout(() => {
      this._dotNetService.GetAllUsers(this.isDeleted).subscribe({
        next: res => {

          console.log("res.body", res.body)
          if (this.isDeleted) {
            this.users = res.body
          } else {
            console.log(this.conditions)
            this.users = res.body.filter(
              x => x.conditionId != this.conditions.filter(x => x.name == "Pronto per il colloquio")[0]?.id
                && x.email != this._cookieService.get('emailAuth')
            )
          }
          console.log("GetAllUserData()", this.users);
          this.ShowUsers();
          this.dashBoardLoadStatus = "Loaded"
        },error: error => {
          this.dashBoardLoadStatus = "Error";
          this._dotNetService.DisplayError(error.error)
        }
      });
    },500)
  }

  Refresh(): void {
    setTimeout(() => {
      sessionStorage.setItem("isDeleted", this.isDeleted.toString());
      this.GetAllUserData()
      this.pageIndex = 0
    }, 500)
  }

  ShowInfoUser(i: number) {

    this.router.navigate(['user/info', this.usersToShow[i].id]);
  }

  handlePageEvent(event: PageEvent) {
    console.log(this.component + "handlePageEvent: ", event)
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex;
    this.ShowUsers()
  }

  ShowUsers() {
    let startIndex = this.pageIndex * this.pageSize;
    let endIndex = startIndex + this.pageSize;
    let part = this.users.slice(startIndex, endIndex);
    this.usersToShow = part;
  }

  OpenCreateUserDialog() {
    const dialogRef = this._dialog.open(UserCreateComponent, {
      width: '40em',
      height: '80vh'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log("RESULT", result)
        if (result.user.conditionId != this.conditions.filter(x => x.name == "Pronto per il colloquio")[0].id) {
          if (!this.isDeleted) {
            result.user.condition = this.conditions.filter(x => x.id == result.user.conditionId)[0].name
            this.users.push(result.user)
            this.ShowUsers()
          }
        }
      }
    });
  }
}
