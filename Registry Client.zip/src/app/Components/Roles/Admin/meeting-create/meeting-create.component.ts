import { MeetingDTO } from '../../../../Models/DTOs/Meeting/Meeting-dto';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';
import { MatDialog } from '@angular/material/dialog';
import { CodinGameCampaigns, CodinGameInvitation } from 'src/app/Models/DTOs/CodinGame/CodinGame';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { map, Observable, startWith } from 'rxjs';
import { DatepickerRangeService } from 'src/app/Services/General/DatepickerRange/datepicker-range.service';
import { ConditionDTO } from 'src/app/Models/DTOs/User/condition-dto';
import { CodingGameService } from 'src/app/Services/General/CodingGame/codin-game.service';


@Component({
  selector: 'app-meeting-create',
  templateUrl: './meeting-create.component.html',
  styleUrls: ['./meeting-create.component.css']
})
export class MeetingCreateComponent implements OnInit {

  users: UserDTO[] = [];
  technicians: UserDTO[] = [];
  techniciansToShow!: UserDTO[];
  usersToShow!: UserDTO[];
  meeting!: MeetingDTO;
  conditions : ConditionDTO[] = [];
  date: MeetingDTO[] = [];
  time: MeetingDTO[] = [];
  form: FormGroup;
  filteredCategory: Observable<string[]>;
  categorys: string[] = ['FE', 'BE', 'FS', 'ALTRO'];
  campaigns: CodinGameCampaigns[] = [];

  loaded: boolean = null;

  addCodinGame: boolean = false;
  maxId: any;
  displayedColumns: string[] = [
    'name',
    'surname',
    'email',
    'condition',
    'cv',
    'cg'
  ];

  displayedColumnsTec: string[] = [
    'name',
    'surname',
    'email',
  ];

  pageSize = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25];
  showFirstLastButtons = true;
  isDeleted = false;

  meetingForm = new FormGroup({
    userId: new FormControl<UserDTO>(null, Validators.required),
    technicianId: new FormControl<UserDTO>(null, [Validators.required]),
    date: new FormControl<Date>(new Date, Validators.required),
    time: new FormControl<Date>(new Date, Validators.required),
    addCodinGame: new FormControl<boolean>(false),
    campaignId: new FormControl<number>(null),
    campaignCatId : new FormControl(''),
    tagsId: new FormControl<string[]>(null)
  })

  separatorKeysCodes: number[] = [ENTER, COMMA];
  tagsCampaign: string[] = [];

  codinGameInvitation: CodinGameInvitation = {
    candidate_email: '',
    candidate_name: '',
    recruiter_email: '',
    tags: '',
    send_invitation_email: true,
    send_notification_email_on_bounce: true
  }

  testId: number
  max_meeting_date = new Date()
  min_meeting_date = new Date()
  filteredFruits: Observable<CodinGameCampaigns[]>;
  fruits: string[] = [];

  filteredUsers$: Observable<UserDTO[]>;
  selectedUserId: string;
  selectedUser: {id: number, name: string, surname: string, email: string};

  filteredTechnicians$: Observable<UserDTO[]>;
  selectedTechnicianId: string;
  selectedTechnician: {id: number, name: string, surname: string, email: string};

  constructor(
    private _dotNetService: DotNetService,
    private _router: Router,
    private snackBar: SnackbarService,
    private dialog: MatDialog,
    private _datePickerRange: DatepickerRangeService,
    private fb: FormBuilder,
    private codingameService: CodingGameService
  ) { }

  ngOnInit(): void {

    this.loaded = false
    this.GetAllUserData();
    this.filteredUsers$ = this.meetingForm.controls.userId.valueChanges.pipe(
      startWith(''),
      map(value => this._filterU(value.toString() || ''))
    )

    this.filteredTechnicians$ = this.meetingForm.controls.technicianId.valueChanges.pipe(
      startWith(''),
      map(value => this._filterT(value.toString() || ''))
    )


    this.max_meeting_date = this._datePickerRange.max_meeting
    this.form = this.fb.group({
      campaignCatId: ''
    });

    this.filteredCategory = this.form.controls['campaignCatId'].valueChanges
      .pipe(
        startWith(''),
        map(value => this.filterCategory(value))
      );
    this.GetConditions()

  }

  private _filterU(value: string): UserDTO[] {
    if(typeof value !== 'string') {
      return [];
    }
    const filterValue = value.toLowerCase();
    return this.users.filter(option => option.name.toLowerCase().includes(filterValue) || option.surname.toLowerCase().includes(filterValue)
    || String(option.name + " " + option.surname).toLowerCase().includes(filterValue)
    );
  }

  private _filterT(value: string): UserDTO[] {
    if(typeof value !== 'string') {
      return [];
    }
    const filterValue = value.toLowerCase();
    return this.technicians.filter(option => option.name.toLowerCase().includes(filterValue) || option.surname.toLowerCase().includes(filterValue)
    || String(option.name + " " + option.surname).toLowerCase().includes(filterValue)
    );
  }


  GetConditions(){
    this._dotNetService.GetAllConditions().subscribe({
      next: res => {
        console.log(res.body)
        this.conditions = res.body
      }, error: error => {
        this._dotNetService.DisplayError(error.error)
      }
    })
  }

  GetAllUserData() {
    this._dotNetService.GetAllInterviewUsers().subscribe(res => {
      this.users = res.body
      this._dotNetService.GetAllTechnicianUsers().subscribe(res => {
        this.technicians = res.body
        this.loaded = true
      })
    })
  }

  SetValidatorForm() {
    console.log("this.meetingForm", this.meetingForm)
    setTimeout (()=>{
      if (this.meetingForm.value.addCodinGame == true) {
        this.meetingForm.controls.campaignCatId.addValidators([Validators.required])
        this.meetingForm.controls.campaignId.addValidators([Validators.required])

        this.meetingForm.controls.campaignCatId.reset()
        this.meetingForm.controls.campaignId.reset()
      } else {
        this.meetingForm.controls.campaignCatId.removeValidators([Validators.required])
        this.meetingForm.controls.campaignId.removeValidators([Validators.required])

        this.meetingForm.controls.campaignCatId.reset()
        this.meetingForm.controls.campaignId.reset()
      }
    }, 300)
  }

  CreateMeeting() {

    let event = this.meetingForm.value;
    let a = event.time.toString().split(":");
    let hours = Number.parseInt(a[0])
    let minutes = Number.parseInt(a[1])

    if(hours < 8 || hours > 18 || (hours == 18 && minutes > 0)){
      alert("Il colloquio deve avvenire nell'orario compreso tra le 8:00 e le 18:00")
      return
    }

    event.date
    event.date.setHours(hours, minutes, 0)

    let meetingData = {
      userId: this.selectedUser?.id,
      interviewerId: this.selectedTechnician?.id,
      date: event.date,
    }

    this._dotNetService.CreateMeeting(meetingData).subscribe({
      next: res => {
        console.log(res.body)
        if(event.addCodinGame){
          this.CreateInvitation(event)
        } else{
          this._router.navigate(['/admin/dashboard'])
        }
        this.snackBar.Show('Nuovo colloquio creato')
      }, error: error => {
        this.snackBar.Show('Errore nella creazione del meeting')
        this._dotNetService.DisplayError(error.error)

      }
    })
  }

  displayUserFn(user?: UserDTO): string | undefined {
    return user ? user.name + ' ' + user.surname : undefined;
  }

  displayTechnicianFn(technician : UserDTO): string | undefined {
    return technician ? `${technician.name} ${technician.surname}` : undefined;
  }

  getAllCampaignsWithTags(category: string): void {
    this.codingameService.getAllCampaignsWithTags(category).subscribe({
      next: res => {
        this.campaigns = res;
        console.log(this.campaigns);

        console.log( "campaignAvaible is: ",  this.campaigns);
      }, error: error => {
        console.error(error);
      }
    });
  }

  filterCategory(value: string): string[] {
    const filterValue = value.toLowerCase();
    console.log(this.filterCategory);

    return ['BE', 'FE', 'FS', 'ALTRO'].filter(option => option.toLowerCase().includes(filterValue));
  }

  CreateInvitation(form) {

    this.codinGameInvitation = {
      candidate_email: this.selectedUser.email,
      candidate_name:this.selectedUser.name + " " + this.selectedUser.surname,
      recruiter_email: this.selectedTechnician.email,
      tags: this.tagsCampaign.join(),
      send_invitation_email: true,
      send_notification_email_on_bounce: true
    }

    this._dotNetService.CreateInvitation(this.codinGameInvitation, form.campaignId.id).subscribe({
      next: res => {
        console.log("res", res)
        this.testId = res.body.id
        this.snackBar.Show("Invito CodinGame inviato con successo");
        this._router.navigate(['/admin/dashboard'])
      }, error: error => {
        this._dotNetService.DisplayError(error.error);
      }
    })
  }

  remove(tag): void {
    this.tagsCampaign.splice(tag, 1);
  }

  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();
    console.log("value:", value)
    if (value) {
      this.tagsCampaign.push(value);
    }
    event.chipInput!.clear();
  }

  handlePageEvent(event: PageEvent) {
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex;
    // this._dotNetService.GetAllRegistriesPage(this.isDeleted).subscribe(res => {
    //   console.log("res.body", res.body)
    //       if (this.isDeleted) {
    //         this.users = res.body
    //       }
    // })
    this.ShowUsers()
  }

  ShowUsers() {
    let startIndex = this.pageIndex * this.pageSize;
    let endIndex = startIndex + this.pageSize;
    let part = this.users.slice(startIndex, endIndex);
    this.users = part;
  }

  handlePageEventTechnicians(event: PageEvent) {
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex;
    // this._dotNetService.GetAllTechnicianUsersPage().subscribe(res => {
    //   this.technicians = res.body
    // })
    this.ShowTechnicians()
  }

  ShowTechnicians() {
    let startIndex = this.pageIndex * this.pageSize;
    let endIndex = startIndex + this.pageSize;
    let part = this.technicians.slice(startIndex, endIndex);
    this.technicians = part;
  }

  ShowInfoUser(i: number) {
    this._router.navigate(['user/info', this.users[i]?.id]);
  }

  ShowInfoTechnician(i: number) {
    this._router.navigate(['user/info', this.technicians[i]?.id]);
  }


  DisplayFn(campaign: CodinGameCampaigns): string {
    if(campaign){
      return campaign.name
    } else {
      return '';
    }
  }
}
