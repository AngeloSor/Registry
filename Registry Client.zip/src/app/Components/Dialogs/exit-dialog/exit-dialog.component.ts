import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { KeyCLoakService } from 'src/app/Services/Apis/KeyCloak/key-cloak.service';
import { MatDialogRef } from '@angular/material/dialog';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-exit-dialog',
  templateUrl: './exit-dialog.component.html',
  styleUrls: ['./exit-dialog.component.css']
})
export class ExitDialogComponent implements OnInit {

  constructor(
    private router: Router,
    private _keyCloackService: KeyCLoakService,
    private dialogRef: MatDialogRef<AppComponent>,
  ) { }

  ngOnInit(): void {

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
