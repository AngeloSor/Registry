import { NgModule } from "@angular/core";
import { SafePipe } from "./pipe.module";

@NgModule({
imports: [],
declarations: [
  SafePipe
],
exports: [SafePipe],
})

export class ComponentModule {}
