import { AuthenticationService } from './../../../Services/Apis/KeyCloak/Authentication/authentication.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(
    private authenticationService :AuthenticationService,
  ) { }

  ngOnInit(): void {
    this.authenticationService.Logout();
  }

/*   OpenCondigameResultDialog(){
     const dialogRef = this.dialog.open(CodingameResultComponent, {
       width: '80vw',
       height: '80vh',
       disableClose: true
     });
     dialogRef.keydownEvents().subscribe(event => {
       if (event.key === "Escape") {
  dialogRef.close()
}
    });
    dialogRef.afterClosed().subscribe(res => {
    });
  }*/

}
