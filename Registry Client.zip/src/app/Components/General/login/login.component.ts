import { catchError, tap } from 'rxjs/operators';
import { Component, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { KeyCLoakService } from 'src/app/Services/Apis/KeyCloak/key-cloak.service';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { RoleGuard } from 'src/app/Services/Guards/Role/role.guard';
import { SnackbarService } from 'src/app/Services/General/Snackbar/snackbar.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit, OnDestroy {
  component = 'LoginComponent';
  spinner: string;

  loginForm = new FormGroup({
    email: new FormControl('', [Validators.email, Validators.required]),
    password: new FormControl('', Validators.required),
  });

  constructor(
    private _keyCloakService: KeyCLoakService,
    private router: Router,
    private _dotNetService: DotNetService,
    private roleGuard: RoleGuard,
    private snackbarService: SnackbarService,
    private renderer: Renderer2
  ) {}

  ngOnInit(): void {
    this.renderer.addClass(document.body, 'disable-scroll');
    this._keyCloakService.Logout();
  }

  OnSubmit() {
    this.spinner = 'Loading';
    let responseKeyCloak = this._keyCloakService.PostDataKeycloak(
      this.loginForm.value.email!,
      this.loginForm.value.password!
    );
    responseKeyCloak.subscribe({
      next: () => {
        setTimeout(() => {
          this._dotNetService
          .GetUserByEmail(this.loginForm.value.email!)
          .pipe(
            tap((responseData) => {
              this.spinner = 'Loaded';
              console.log(responseData);
              if (this.roleGuard.CheckRole) {
                this.router.navigate(['/admin/dashboard']);
              } else {
                console.log("responseData?.body?.id", responseData?.body?.id)
                this.router.navigate(['/user/info/' + responseData?.body?.id]);
              }
            }),
            catchError((error) => {
              this.spinner = 'Loaded';
              this._dotNetService.DisplayError(error.error);
              return of(null);
            })
          )
          .subscribe();
        },1000)

      },
      error: (error) => {
        this.spinner = 'Loaded';
        this.snackbarService.Show(
          "Le credenziali inserite non sono corrette o l'utente non esiste, riprovare"
        );
      },
    });
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(document.body, 'disable-scroll');
  }
}
