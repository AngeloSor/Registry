import { Location } from '@angular/common';
import { UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { ExitDialogComponent } from './../../Dialogs/exit-dialog/exit-dialog.component';
import { EventEmitter } from '@angular/core';
import { outputAst } from '@angular/compiler';
import { Component, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { filter, Observable, Subscription, switchMap, tap } from 'rxjs';
import { AuthenticationService } from 'src/app/Services/Apis/KeyCloak/Authentication/authentication.service';
import { KeyCLoakService } from 'src/app/Services/Apis/KeyCloak/key-cloak.service';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { DictionaryService } from 'src/app/Services/General/Dictionary/dictionary.service';
import { RoleGuard } from 'src/app/Services/Guards/Role/role.guard';


@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.css']
})
export class ToolbarComponent implements OnInit {
  user: UserDTO;
  isAdmin: boolean;
  fullName: string;
  @Output() subscription = new EventEmitter<Subscription>;
  @Output() isLogged$: Observable<boolean>;
  subscription$ = new Subscription();

  currentPath: string
  constructor(
    private _keyCloakService: KeyCLoakService,
    private roleGuard: RoleGuard,
    private _dialog: MatDialog,
    public _router: Router,
    private cookieService: CookieService,
    private dotNetService: DotNetService,
    private _authenticationService: AuthenticationService,
    private location: Location
  ) {
    this.currentPath = this._router.url;
    this.isLogged$ = this._authenticationService.isLoggedObservable$;
  }


  ngOnInit(): void {
    if(this.cookieService.get('fullName')){
      this.fullName = this.cookieService.get('fullName')
    }
    this.CheckSession()
  }

  CheckSession() {
    this.subscription$.add(
      this.isLogged$.pipe(
      filter((isLogged) => !!isLogged),
      tap((isLogged) => console.log(isLogged)),
      switchMap(() => this.dotNetService.GetUserByEmail(this.cookieService.get('emailAuth'))),
      tap((res) => {
        this.user = res.body
        this.fullName = this.user.name + " " + this.user.surname;
        this.cookieService.set('fullName', this.fullName)
      })
    ).subscribe()
    );

    this.isAdmin = this.roleGuard.CheckRole;

    this.subscription.emit(this.subscription$);
  }

  OpenDialog(): void {
    const dialogRef = this._dialog.open(ExitDialogComponent, {
      width: '250px',
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._keyCloakService.Logout()
        this._router.navigate(['/login'])
      }
    });
  }

  Return(){
    if(!this.cookieService.get('token')){
      this._router.navigate(['login'])
    }
    if(this.roleGuard.CheckRole){
      this._router.navigate(['/admin/dashboard'])
    } else {
      if(window.location.hash == '/notFound/404'){
        this.location.back()
      }else{
        this._router.navigate(['/user/info', this.user.id])
        if(window.location.hash == '/yourFeedback'){
          this.location.back()
        }else{
          this._router.navigate(['/user/info', this.user.id])
        }
      }
    }
  }

}
