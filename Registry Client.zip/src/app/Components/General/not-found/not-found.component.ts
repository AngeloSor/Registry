import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { RoleGuard } from 'src/app/Services/Guards/Role/role.guard';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.css'],
})
export class NotFoundComponent implements OnInit {
  idError: number;
  message: string;

  constructor(
    private router: Router,
    private roleGuard: RoleGuard,
    private location: Location,
    private cookieService: CookieService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params: Params) => {
      console.log(params['id']);
      this.idError = +params['id'];
    });
    setTimeout(() => {
      this.SwitchMessageError();
    }, 500);
  }

  SwitchMessageError() {
    console.log(this.idError);
    switch (this.idError) {
      case 401:
        this.message = 'Non hai i permessi per accedere alla pagina';
        break;
      case 404:
        this.message = 'La pagina cercata non è stata trovata';
        break;
      default:
        this.message = 'Errore sconosciuto';
        break;
    }
    console.log(this.message);
  }

  Redirect(): void {
    let a = this.cookieService.get('token')
    if (a != '') {
      if (this.roleGuard.CheckRole) this.location.back();
    } 
    else this.router.navigate(['/login']);
  }
}
