import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';

@Component({
  selector: 'app-forgot-pw',
  templateUrl: './forgot-pw.component.html',
  styleUrls: ['./forgot-pw.component.css']
})
export class ForgotPwComponent implements OnInit {

  email = new FormControl('', [Validators.email, Validators.required])

  constructor(
    private dotnetService: DotNetService
  ) { }

  ngOnInit(): void {
  }

  SendEmail(){
    this.dotnetService.SendEmail().subscribe({
      next: res => {
        console.info(res)
        console.log('mail inviata con successo');
      },
      error: error => {
        this.dotnetService.DisplayError(error.error);
      }
    })
  }

}
