import { CookieService } from 'ngx-cookie-service';
//Module
import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';


import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatGridListModule } from '@angular/material/grid-list';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatMenuModule } from '@angular/material/menu';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTabsModule } from '@angular/material/tabs';
import { ClipboardModule } from '@angular/cdk/clipboard';


//Interceptor
import { ApiInterceptor } from './Services/Apis/Interceptor/api-interceptor';

//Component
import { AppComponent } from './app.component';
import { ExitDialogComponent } from './Components/Dialogs/exit-dialog/exit-dialog.component';
import { AdminDashboardComponent } from './Components/Roles/Admin/admin-dashboard/admin-dashboard.component';
import { UserDetailComponent } from './Components/Roles/User/user-detail/user-detail.component';
import { UserEditComponent } from './Components/Roles/User/user-edit/user-edit.component';
import { UserCreateComponent } from './Components/Roles/User/user-create/user-create.component';
import { LoginComponent } from './Components/General/login/login.component';
import { FooterComponent } from './Components/General/footer/footer.component';
import { HomepageComponent } from './Components/General/homepage/homepage.component';
import { DeleteUserDialogComponent } from './Components/Roles/User/user-detail/dialogs/delete-user-dialog/delete-user-dialog.component';
import { CvComponent } from './Components/Roles/User/user-detail/cv/cv.component';
import { ComponentModule } from './Components/componentModule.module';
import { MeetingCreateComponent } from './Components/Roles/Admin/meeting-create/meeting-create.component';
import { CvIstructionComponent, CvSkillComponent, CvWorkExperienceComponent, CvUpdateCategoryComponent, CvUpdateSkillComponent, CvConfirmDeletDialogComponent } from './Components/Roles/User/user-detail/cv/cv-dialogs/cv-dialogs.component';
import { NotFoundComponent } from './Components/General/not-found/not-found.component';
import { ForgotPwComponent } from './Components/General/forgot-pw/forgot-pw.component';
import { LoaderComponent } from './Components/General/loader/loader.component';
import { EventScheduledComponent } from './Components/Roles/Technician/event-scheduled/event-scheduled.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { UpdateEventDetailsDialogComponent } from './Components/Roles/Technician/dialogs/update-event-details-dialog/update-event-details-dialog.component';
import { FeedbackComponent } from './Components/Roles/Technician/feedback/feedback.component';
import { RestoreUserDialogComponent } from './Components/Roles/User/user-detail/dialogs/restore-user-dialog/restore-user-dialog.component';
import { CodingameResultComponent } from './Components/Roles/Technician/codingame-result/codingame-result.component';
import { ToolbarComponent } from './Components/General/toolbar/toolbar.component';
import { DisableEventDialogComponent } from './Components/Roles/Technician/dialogs/disable-event-dialog/disable-event-dialog.component';
import { RestoreEventDialogComponent } from './Components/Roles/Technician/dialogs/restore-event-dialog/restore-event-dialog.component';
import { DeleteEventDialogComponent } from './Components/Roles/Technician/dialogs/delete-event-dialog/delete-event-dialog.component';
import { DisableUserDialogComponent } from './Components/Roles/User/user-detail/dialogs/disable-user-dialog/disable-user-dialog.component';
import {MatExpansionModule} from '@angular/material/expansion';


import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { MyFeedbackComponent } from './Components/Roles/User/user-detail/dialogs/my-feedback/my-feedback.component';
import { SingleFeedbackComponent } from './Components/Roles/Technician/singleFeedback/singleFeedback.component';
@NgModule({
  declarations: [
    AppComponent,
    ExitDialogComponent,
    AdminDashboardComponent,
    UserDetailComponent,
    UserEditComponent,
    UserCreateComponent,
    LoginComponent,
    FooterComponent,
    HomepageComponent,
    DeleteUserDialogComponent,
    CvComponent,
    CvIstructionComponent,
    CvSkillComponent,
    CvWorkExperienceComponent,
    MeetingCreateComponent,
    CvUpdateCategoryComponent,
    CvUpdateSkillComponent,
    CvConfirmDeletDialogComponent,
    NotFoundComponent,
    LoaderComponent,
    EventScheduledComponent,
    ForgotPwComponent,
    UpdateEventDetailsDialogComponent,
    FeedbackComponent,
    RestoreUserDialogComponent,
    CodingameResultComponent,
    ToolbarComponent,
    DisableEventDialogComponent,
    RestoreEventDialogComponent,
    DeleteEventDialogComponent,
    DisableUserDialogComponent,
    MyFeedbackComponent,
    SingleFeedbackComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatButtonModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatCheckboxModule,
    MatIconModule,
    MatToolbarModule,
    MatSelectModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSnackBarModule,
    MatGridListModule,
    ScrollingModule,
    MatDividerModule,
    MatChipsModule,
    MatAutocompleteModule,
    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSidenavModule,
    MatCardModule,
    MatPaginatorModule,
    MatMenuModule,
    ComponentModule,
    MatProgressSpinnerModule,
    MatTabsModule,
    MatSlideToggleModule,
    ClipboardModule,
    MatExpansionModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'it-IT' },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiInterceptor,
      multi: true,
    }, CookieService,
    ClipboardModule,
    // {provide: LocationStrategy, useClass: HashLocationStrategy}
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
