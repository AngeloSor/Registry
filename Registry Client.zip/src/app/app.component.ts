
import { DictionaryService } from './Services/General/Dictionary/dictionary.service';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { KeyCLoakService } from 'src/app/Services/Apis/KeyCloak/key-cloak.service';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { RoleGuard } from './Services/Guards/Role/role.guard';
import { ExitDialogComponent } from './Components/Dialogs/exit-dialog/exit-dialog.component';
import { CookieService } from 'ngx-cookie-service';
import { DotNetService } from './Services/Apis/Net/dot-net.service';
import { filter, map, switchMap, tap } from 'rxjs/operators';
import { Subscription, Observable } from 'rxjs';
import { AuthenticationService } from './Services/Apis/KeyCloak/Authentication/authentication.service';

export const CACHE_NAME = "app-cache"
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Registry Alten';
  subscription: Subscription;
  idUser: number;

  constructor(
    private _keyCloakService: KeyCLoakService,
    private roleGuard: RoleGuard,
    private _router: Router,
    private cookieService: CookieService,
    private dictionaryService: DictionaryService,
    private dotNetService: DotNetService,
    private _authenticationService: AuthenticationService,
  ) {}

  ngOnInit(): void {
    caches.open(CACHE_NAME).then(
      isOpened => {
        if (isOpened){
          console.log("Opened")
          this.dictionaryService.SetValue('en');
        }else {
          console.log("Not Opened")
        }
      }
    )
  }
}
