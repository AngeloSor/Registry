import { DotNetService } from 'src/app/Services/Apis/Net/dot-net.service';
import { CodingameReport } from './../../../Models/Entities/CodingameReport/codingame-report';
import { CvFile } from './../../../Models/DTOs/RegistryCv/registryCv-dto';
import { ApisRoot } from './../../../../environments/environment';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export const CACHE_NAME = 'app-cache';

export interface CustomErrorInterface {
  name: string
  message: string;
  error: any | null;
  ok: boolean;
}

export interface Dictionary {
  key: number,
  value: string
}

@Injectable({
  providedIn: 'root'
})

export class DictionaryService {
  errorResponse: CustomErrorInterface;
  filesOnCache: (CvFile | CodingameReport)[] = [];

  constructor(
    private http: HttpClient,
    //private dotnetService: DotNetService
  ) { }


  async SetValue(language: string) {

    console.log("Sono entrato nella res");
    caches.open(CACHE_NAME).then(
      res => {
        res.keys().then(requests => {
          if (requests.length == 0) {
            let response = this.http.get<Dictionary[]>(
              ApisRoot.dotnetBaseUrl + `StatusDictionary/GetStatusDictionary?language=${language}`,
              { observe: 'response' });

            response.subscribe({
              next: res => {
                console.log("Dicionary", res.body)
                this.SetCache(res.url)
              }, error: error => {
                this.errorResponse = { name: 'CustomErrorResponse', error: 'Connection Refused', message: 'Api not work', ok: false };
                console.error(this.errorResponse.error + ':', this.errorResponse.message);
              }
            });
          } else {
            console.log("Cache piena")
          }

        })
      }
    );
  }

  // GetCachedFIles(filereference: number) {
  //   let file = this.filesOnCache.find(x => x. == filereference)
  //   if (file) {
  //     return file;
  //   } else {
  //     this.dotnetService.GetCvFile(filereference).subscribe()
  //     this.dotnetService.GetStatusTestPdf(filereference).subscribe();
  //   }
  //   if (this.filesOnCache.length == 10) {
  //     this.filesOnCache.splice(0, 1);
  //   }
  //   this.filesOnCache.push(file);
  // }
  // SetCachedFiles(files: ) {
  // }

  async SetCache(request) {
    caches.open(CACHE_NAME).then(
      cache => {
        console.info("L'hai sentito?")
        cache.add(request);
        console.log(request);
      }
    )
  }

  async DisplayError(key: string) {
    caches.open(CACHE_NAME).then(
      res => {
        JSON.stringify(res).split(',').forEach(x => {
          let e = x.replace(/["'{}]/g, '').split(':');
          if (e[0] == key) {
            console.error(e[1])
          }
        })
      }
    )
  }
}
