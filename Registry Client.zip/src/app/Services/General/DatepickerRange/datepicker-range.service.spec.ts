import { TestBed } from '@angular/core/testing';

import { DatepickerRangeService } from './datepicker-range.service';

describe('DatepickerRangeService', () => {
  let service: DatepickerRangeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatepickerRangeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
