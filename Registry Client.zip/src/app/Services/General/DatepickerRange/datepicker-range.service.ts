import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatepickerRangeService {
  min_dob = new Date()
  max_dob = new Date()
  min_skill = new Date()
  max_skill = new Date()
  min_meeting = new Date()
  max_meeting = new Date()

  constructor() {
    this.max_dob.setFullYear(this.max_dob.getFullYear() - 16)   
    this.min_dob.setFullYear(this.min_dob.getFullYear() - 80)  
    this.max_meeting.setFullYear(this.max_meeting.getFullYear() +1)
  }

  SetMinDateSkill(dob: Date){
    let dateStr = dob.toLocaleString().split("T")[0]
    this.min_skill = new Date(dateStr)
    this.min_skill.setFullYear(this.min_skill.getFullYear() + 12) 
  }
}
