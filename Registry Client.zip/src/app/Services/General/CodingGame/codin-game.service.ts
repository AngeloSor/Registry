import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { Observable } from 'rxjs';
import { CodinGameCampaigns, CodinGameInvitation, Invitation, Result} from 'src/app/Models/DTOs/CodinGame/CodinGame';
import { DictionaryService } from 'src/app/Services/General/Dictionary/dictionary.service';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CodingGameService {

  constructor(
    private http: HttpClient,
    private _dictionaryService: DictionaryService,
    private cookieService: CookieService
  ) { }

  //DictionaryService
  DisplayError(key: string){
    this._dictionaryService.DisplayError(key);
  }

  CreateInvitation(createCodinGameInvitation: CodinGameInvitation, idCampaign: number){
    return this.http.post<Invitation>(ApisRoot.dotnetBaseUrl + 'CodinGame/SendAnInvitation?idCampaign='+idCampaign, createCodinGameInvitation, {observe: 'response'});
  }

  DeleteInvitation(idInvitation: number){
    return this.http.delete<boolean>(ApisRoot.dotnetBaseUrl + '' + idInvitation, {observe: 'response'});
  }

  GetStatusTest(userId: number){
    return this.http.get<Result>(ApisRoot.dotnetBaseUrl + 'CodinGame/GetTestSessionStatus?registryId='+userId, {observe: 'response'});

  }

  GetStatusTestPdf(userId: number){
    return this.http.get<string>(ApisRoot.dotnetBaseUrl + 'CodinGame/GetTestReport?registryId='+ userId, {observe: 'response'})
  }

  getAllCampaignsWithTags(category: string): Observable<CodinGameCampaigns[]> {
    const url = `${ApisRoot.dotnetBaseUrl}CodinGame/GetAllCampaignsWithTags?category=${category}`;
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.cookieService.get('token')}`);
    return this.http.get<CodinGameCampaigns[]>(url, { headers });
  }
}
