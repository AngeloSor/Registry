import { ApisRoot } from './../../../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import jwt_decode from 'jwt-decode';
import { Subject } from 'rxjs';
import { JWT, JwtDecodeToken } from 'src/app/Models/Entities/JWT/JWT';
import { CookieService } from 'ngx-cookie-service';
import { environment } from 'src/environments/environment.feature';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  keyCloakbaseUrlToGetAccessToken = `${ApisRoot.keycloakBaseUrl}realms/${ApisRoot.realm}/protocol/openid-connect/token`;
  isLoggedObservable = new Subject<boolean>();
  isLoggedObservable$ = this.isLoggedObservable.asObservable()

  constructor(
    private http: HttpClient,
    private cookieService: CookieService
  ){}

  get HasValidToken(): boolean {
    const cookie = this.cookieService.get('token');
    if (cookie) {
      return true;
    } else {
      return false;
    }
  }

  Logout() {
    this.isLoggedObservable.next(false);
    this.cookieService.deleteAll('/');
  }

  GetGrantAccess() {
    return this.isLoggedObservable$;
  }

  GetDecodedAccessToken(token: string): JwtDecodeToken | undefined {
    if (token.length <= 0) {
      return undefined;
    }
    return jwt_decode(token);
  }

  IsAuhtenticated() {
    const promise = new Promise(
      (resolve, reject) => {
        setTimeout(() => {
          resolve(this.HasValidToken);
        }, 400)
      }
    );
    return promise;
  }

  GetKeycloakToken(data: string) {
    const res = this.http.post<JWT>(this.keyCloakbaseUrlToGetAccessToken, data, {
      observe: 'response',
    });
    res.subscribe({
      next: res => {
        this.SetTokenCookie(res.body);
        this.SetRefreshCookie(res.body);
        this.SetEmailCookie(res.body)
        this.SetRoleCookie(res.body)
        this.isLoggedObservable.next(true)
      },
      error: res => {
        console.error(res.body)
      }
    })
    return res;
  }

  SetTokenCookie(data: JWT){
    let expire = new Date()
    console.log(expire)
    expire.setSeconds(parseInt(data.expires_in))
    console.log(expire)

    this.cookieService.set('token', data.access_token, {
      expires: expire,
      path: '/',
      sameSite: 'Lax'
    });
  }

  SetRefreshCookie(data: JWT){
    let expire = new Date()
    console.log(expire)
    expire.setSeconds(parseInt(data.refresh_expires_in))
    console.log(expire)
    this.cookieService.set('refreshToken', data.refresh_token, {
      expires: expire,
      path: '/',
      sameSite: 'Lax'
    });
  }

  SetEmailCookie(data: JWT){
    const decodedJwt = jwt_decode<JWT>(data.access_token);
    this.cookieService.set('emailAuth', decodedJwt.email, {
      expires: 0,
      path: '/',
      sameSite: 'Lax'
    })
  }

  SetRoleCookie(data: JWT){
    const decodedJwt = this.GetDecodedAccessToken(data.access_token)
    let roles = decodedJwt.resource_access.RegistryAlten.roles
    this.cookieService.set('role', roles[roles.length - 1], {
      expires: 0,
      path: '/',
      sameSite: 'Lax'
    })
  }
}
