import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { KeyCloakUserDTO } from 'src/app/Models/DTOs/User/keycloak-user-dto';
import { KeyCLoakService } from '../key-cloak.service';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(
    private http: HttpClient
  ) {}

  CreateUser(user: KeyCloakUserDTO) {
    return this.http.post(
      ApisRoot.keycloakBaseUrl + 'admin/realms/' + ApisRoot.realm + '/users',
      user,
      {
        observe: 'response'
      }
    );
  }

  SetPassword(value: string, userId: string) {
    return this.http.put(
      ApisRoot.keycloakBaseUrl +
        'admin/realms/' +
        ApisRoot.realm +
        '/users/' +
        userId +
        '/reset-password',
      {
        type: 'password',
        value: value,
        temporary: false
      },
      {
        observe: 'response'
      }
    );
  }

  GetUser(email: string){
    return this.http.get<KeyCloakUserDTO>(ApisRoot.keycloakBaseUrl + 'admin/realms/' + ApisRoot.realm  + '/users?email=' + email, {
      observe: 'response'
    })
  }

  UpdateUser(user: KeyCloakUserDTO){
    return this.http.put(ApisRoot.keycloakBaseUrl + 'admin/realms/' + ApisRoot.realm + '/users/' + user.id, user, {observe: 'response'});
  }

  DisableUser(id: string){
    return this.http.put(ApisRoot.keycloakBaseUrl + 'admin/realms/' + ApisRoot.realm +'/users/' + id,{
      enabled: false
    },{
      observe: 'response'
    })
  }

  DeleteUser(id: string){
    return this.http.delete(ApisRoot.keycloakBaseUrl + 'admin/realms/' + ApisRoot.realm +'/users/' + id,{
      observe: 'response'
    })
  }

  RestoreUser(id: string){
    return this.http.put(ApisRoot.keycloakBaseUrl + 'admin/realms/' + ApisRoot.realm +'/users/' + id,{
      enabled: true
    },{
      observe: 'response'
    })
  }
}
