import { TestBed } from '@angular/core/testing';

import { KeyCLoakService } from './key-cloak.service';

describe('KeyCLoakService', () => {
  let service: KeyCLoakService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KeyCLoakService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
