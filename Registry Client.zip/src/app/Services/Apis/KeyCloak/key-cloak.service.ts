import { KeycloakRoleService } from './Role/keycloak-role.service';
import { Injectable } from '@angular/core';
import { KeyCloakUserDTO } from 'src/app/Models/DTOs/User/keycloak-user-dto';
import { JwtDecodeToken } from 'src/app/Models/Entities/JWT/JWT';
import { AuthenticationService } from './Authentication/authentication.service';
import { UserService } from './User/user.service';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class KeyCLoakService {

  realm = 'RegistryAlten'


  constructor(
    private _userService: UserService,
    private _authenticationService: AuthenticationService,
    private _keycloakRoleService: KeycloakRoleService,
    private _cookieService: CookieService
  ) { }

  //Authentication service
  get HasValidToken(): boolean {
    return this._authenticationService.HasValidToken;
  }

  Logout(){
    return this._authenticationService.Logout();
  }

  GetGrantAccess(){
    return this._authenticationService.GetGrantAccess()
  }

  PostDataKeycloak(email: string, password: string){
    let requestAccessTokenData = "client_id=RegistryAlten&";
    requestAccessTokenData += "username=" + email + "&";
    requestAccessTokenData += "password=" + password + "&";
    requestAccessTokenData += "client_secret=NPKownt4HmrquKFyMOWc6M9SzojuKGqo" + "&";
    requestAccessTokenData += "grant_type=password";
    return this._authenticationService.GetKeycloakToken(requestAccessTokenData);
  }

  RefreshDataKeycloak(){
    let requestAccessTokenData = "client_id=RegistryAlten&";
    requestAccessTokenData += "refresh_token=" + this._cookieService.get('refreshToken') + "&";
    requestAccessTokenData += "client_secret=NPKownt4HmrquKFyMOWc6M9SzojuKGqo" + "&";
    requestAccessTokenData += "grant_type=refresh_token";
    return this._authenticationService.GetKeycloakToken(requestAccessTokenData);
  }

  GetDecodedAccessToken(token: string): JwtDecodeToken{
    return this._authenticationService.GetDecodedAccessToken(token)!;
  }

  //User service
  CreateUser(user: KeyCloakUserDTO){
    return this._userService.CreateUser(user)
  }

  SetUserRole(groupId: string, userId: string){
    return this._keycloakRoleService.SetUserRole(groupId, userId);
  }

  GetGroupId(){
    return this._keycloakRoleService.GetGroupId();
  }

  SetPassword(value: string, userId: string) {
    return this._userService.SetPassword(value, userId)
  }

  GetUser(email: string){
    return this._userService.GetUser(email)
  }

  UpdateUser(user: KeyCloakUserDTO){
    return this._userService.UpdateUser(user);
  }

  DisableUser(id: string){
    return this._userService.DisableUser(id);
  }

  DeleteUser(id: string){
    return this._userService.DeleteUser(id);
  }

  RestoreUser(id: string){
    return this._userService.RestoreUser(id);
  }
}
