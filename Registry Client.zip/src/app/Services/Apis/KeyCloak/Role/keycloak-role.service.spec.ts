import { TestBed } from '@angular/core/testing';

import { KeycloakRoleService } from './keycloak-role.service';

describe('KeycloakRoleService', () => {
  let service: KeycloakRoleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KeycloakRoleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
