import { KeyCloakGroupDTO } from './../../../../Models/DTOs/KeyCloakGroups/keycloakGroup';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class KeycloakRoleService {

  constructor(private http: HttpClient) { }

  SetUserRole(groupId: string, userId: string){
    return this.http.put(ApisRoot.keycloakBaseUrl + 'admin/realms/' + ApisRoot.realm + '/users/' + userId + '/groups/'+ groupId, {}, {observe: 'response'});
  }

  GetGroupId(){
    return this.http.get<KeyCloakGroupDTO[]>(ApisRoot.keycloakBaseUrl + "admin/realms/" + ApisRoot.realm +"/groups", {observe: 'response'})
  }
}
