import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { WorkExperience } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class WorkExperienceService {

  constructor(
    private http: HttpClient
  ) { }

  CreateWorkExperience(workExperience: WorkExperience){
    return this.http.post<WorkExperience>(ApisRoot.dotnetBaseUrl + "WorkExperience/CreateWorkExperience",
      workExperience,
      {
        observe: 'response'
      }
    )
  }

  GetWorkExperience(id: number){
    return this.http.get<WorkExperience>(ApisRoot.dotnetBaseUrl + "WorkExperience/GetWorkExperienceById?id=" + id,
      {
        observe: 'response'
      }
    )
  }

  PutWorkExperience(workExperience: WorkExperience){
    return this.http.put<WorkExperience>(ApisRoot.dotnetBaseUrl + "WorkExperience/PutWorkExperience",
      workExperience,
      {
        observe: 'response'
      }
    )
  }

  DeleteWorkExperience(id: number){
    return this.http.delete<WorkExperience>(ApisRoot.dotnetBaseUrl + "WorkExperience/DeleteWorkExperienceById?id=" + id,
      {
        observe: 'response'
      }
    )
  }

  
}
