import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApisRoot } from 'src/environments/environment';
import { InterviewFeedbackDTO } from 'src/app/Models/DTOs/InterviewFeedback/interviewFeedbackDTO';


@Injectable({
  providedIn: 'root'
})
export class EmailSenderService {

  constructor(
    private http: HttpClient
  ) { }

  SendEmail(){
    return this.http.post(ApisRoot.dotnetBaseUrl + 'EmailSender/SendEmail', {});
  }

  InterviewFeedBack(interviewFeedback: InterviewFeedbackDTO){
    return this.http.post(ApisRoot.dotnetBaseUrl + 'EmailSender/Send/InterviewFeedback', interviewFeedback, {
      observe: 'response'
    })
  }
}
