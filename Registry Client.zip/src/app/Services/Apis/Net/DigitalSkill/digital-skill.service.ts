import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApisRoot } from 'src/environments/environment';
import { DigitalSkill, DigitalSkillGroupDTO } from 'src/app/Models/DTOs/Skills/SkillGroup/skillGroup';

@Injectable({
  providedIn: 'root'
})
export class DigitalSKillService {

  constructor(
    private http: HttpClient
  ) { }

  CreateDigitalSkill(digitalSkill: DigitalSkill){
    return this.http.post<DigitalSkillGroupDTO[]>(ApisRoot.dotnetBaseUrl + "DefaultDigitalSkill/CreateDefaultDigitalSkill", digitalSkill,{
      observe: 'response'
    })
  }

  UpdateDigitalSkill(digitalSkill: DigitalSkill){
    return this.http.put<DigitalSkillGroupDTO[]>(ApisRoot.dotnetBaseUrl + "DefaultDigitalSkill/UpdateDefaultDigitalSkill", digitalSkill,{
      observe: 'response'
    })
  }

  DeleteDigitalSkill(digitalSkill: DigitalSkill){
    return this.http.delete<DigitalSkillGroupDTO[]>(ApisRoot.dotnetBaseUrl + "DefaultDigitalSkill/DeleteDefaultDigitalSkill", {
      body: digitalSkill,
      observe: 'response'
    })
  }
}
