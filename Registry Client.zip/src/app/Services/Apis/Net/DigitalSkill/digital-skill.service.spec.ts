import { TestBed } from '@angular/core/testing';

import { DigitalSKillService } from './digital-skill.service';

describe('DigitalSKillService', () => {
  let service: DigitalSKillService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DigitalSKillService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
