import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EducationAndTrainingExperience } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EducationServiceService {

  constructor(
    private http: HttpClient
  ) { }

  CreateEducationAndTrainingExperience(education: EducationAndTrainingExperience){
    return this.http.post<EducationAndTrainingExperience>(ApisRoot.dotnetBaseUrl + "EducationAndTrainingExperience/CreateEducationAndTrainingExperience", 
      education,
      {
        observe: 'response'
      }
    )
  }

  GetEducationAndTrainingExperienceById(id: number){
    return this.http.get<EducationAndTrainingExperience>(ApisRoot.dotnetBaseUrl + "EducationAndTrainingExperience/GetEducationAndTrainingExperienceById?id=" + id,
    {
      observe: 'response'
    })
  }

  PutEducationAndTrainingExperience(education: EducationAndTrainingExperience){
    return this.http.put<EducationAndTrainingExperience>(ApisRoot.dotnetBaseUrl + "EducationAndTrainingExperience/PutEducationAndTrainingExperience", 
      education,
      {
        observe: 'response'
      }
    )
  }

  DeleteEducationAndTrainingExperience(id: number){
    return this.http.delete<EducationAndTrainingExperience>(ApisRoot.dotnetBaseUrl + "EducationAndTrainingExperience/DeleteEducationAndTrainingExperienceById?id=" + id,
    {
      observe: 'response'
    })
  }


}
