import { Observable } from 'rxjs';
 import { ApisRoot } from 'src/environments/environment';
import { UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RegistryService {

  path = 'Registry/'

  constructor(
    private http: HttpClient
  ) { }

  GetAllRegistriesPage(isDeleted: boolean){
    return this.http.get<UserDTO[]>(ApisRoot.dotnetBaseUrl + this.path + 'GetAllRegistriesPage?isDeleted=' + isDeleted,{
      observe: 'response'
    });
  }

  GetAllTechnicianUsersPage(){
    return this.http.get<UserDTO[]>(ApisRoot.dotnetBaseUrl + this.path + 'GetAllTechnicianUsersPage' ,{
      observe: 'response'
    });
  }

  GetAllUsers(isDeleted: boolean){
    return this.http.get<UserDTO[]>(ApisRoot.dotnetBaseUrl + this.path + 'GetAllRegistries?isDeleted=' + isDeleted, {observe: 'response'})
  }

  DeleteUser(userId: number) { //200
    return this.http.delete<boolean>(ApisRoot.dotnetBaseUrl + this.path + 'DeletePermanentRegistryById?id=' + userId);
  }

  DisableUser(userId: number) { //200
    return this.http.delete<boolean>(ApisRoot.dotnetBaseUrl + this.path + 'DeleteRegistryById?id=' + userId);
  }

  UpdateUser(user: UserDTO) { //200
    return this.http.put<UserDTO>(ApisRoot.dotnetBaseUrl + this.path + 'PutRegistry', user, {
      observe: 'response'
    })
  }

  GetUserByEmail(email: string){
    return this.http.get<UserDTO>(ApisRoot.dotnetBaseUrl + this.path + 'GetRegistryByEmail?email=' + email, {
      observe: 'response'
    });
  }

  GetRegistryById(id: number) {
    return this.http.get<UserDTO>(ApisRoot.dotnetBaseUrl + this.path + 'GetRegistryById?id=' + id, {observe: 'response'});
  }

  CreateUser(message: any){
    return this.http.post<UserDTO>(ApisRoot.dotnetBaseUrl + this.path + 'CreateRegistry', message, {
      observe: 'response'
    })
  }

  RestoreUser(userId: number) { //200
    return this.http.put<boolean>(ApisRoot.dotnetBaseUrl + this.path + 'RehabilitateRegistryById?id=' + userId, null ,{
      observe: 'response'
    });
  }

  GetAllInterviewUsers() { //200
    return this.http.get<UserDTO[]>(ApisRoot.dotnetBaseUrl + this.path + 'GetAllInterviewUsers' ,{
      observe: 'response'
    });
  }

  GetAllTechnicianUsers() { //200
    return this.http.get<UserDTO[]>(ApisRoot.dotnetBaseUrl + this.path + 'GetAllTechnicianUsers' ,{
      observe: 'response'
    });
  }
}
