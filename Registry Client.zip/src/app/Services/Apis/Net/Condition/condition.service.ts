import { Injectable } from '@angular/core';
 import { ApisRoot } from 'src/environments/environment';
import { UserDTO } from 'src/app/Models/DTOs/User/user-dto';
import { HttpClient } from '@angular/common/http';
import { ConditionDTO } from 'src/app/Models/DTOs/User/condition-dto';

@Injectable({
  providedIn: 'root'
})
export class ConditionService {

  path = 'Condition/'

  constructor(
    private http: HttpClient
  ) { }

  GetAllConditions(){
    return this.http.get<ConditionDTO[]>(ApisRoot.dotnetBaseUrl + this.path + 'GetAllCondition', {observe: 'response'})
  }
}
