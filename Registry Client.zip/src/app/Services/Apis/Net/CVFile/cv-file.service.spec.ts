import { TestBed } from '@angular/core/testing';

import { CvFileService } from './cv-file.service';

describe('CvFileService', () => {
  let service: CvFileService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CvFileService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
