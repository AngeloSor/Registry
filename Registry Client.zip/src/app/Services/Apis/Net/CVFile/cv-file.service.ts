import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CvFile } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CvFileService {

  constructor(
    private http: HttpClient
  ) { }
  GetCvFile(id: number){
    return this.http.get<CvFile>(ApisRoot.dotnetBaseUrl + 'CVFile/GetCVFileById?id='+id, {
      observe: 'response'
    })
  }

  CreateCVFile(cvFile: CvFile){
    console.log(cvFile)
    return this.http.post<CvFile>(ApisRoot.dotnetBaseUrl + 'CVFIle/CreateCVFile', cvFile, {
      observe: 'response'
    })
  }

  DeleteCvFile(id: number){
    return this.http.delete<CvFile>(ApisRoot.dotnetBaseUrl + 'CVFIle/DeleteCvFileById?id=' + id, {
      observe: 'response'
    })
  }
}
