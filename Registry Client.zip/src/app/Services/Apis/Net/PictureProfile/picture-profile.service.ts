import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ImageDTO } from 'src/app/Models/DTOs/User/image-dto';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PictureProfileService {

  constructor(
    private http: HttpClient
  ) { }

  CreatePictureProfile(image : ImageDTO){
    return this.http.post<ImageDTO>(ApisRoot.dotnetBaseUrl + 'PictureProfile/CreatePictureProfile', image, {
      observe: 'response'
    })
  }

  GetPictureProfileById(id: number){
    return this.http.get<ImageDTO>(ApisRoot.dotnetBaseUrl + 'PictureProfile/GetPictureProfileById?id=' + id, {
      observe: 'response'
    });
  }

  GetAllPicturesProfile(){
    return this.http.get<ImageDTO[]>(ApisRoot.dotnetBaseUrl + 'PictureProfile/GetAllPicturesProfile', {
      observe: 'response'
    });
  }

  PutPictureProfile(image: ImageDTO) {
    return this.http.put<ImageDTO>(ApisRoot.dotnetBaseUrl + 'PictureProfile/PutPictureProfile', image , {
      observe: 'response'
    })
  }

  DeletePictureProfileById(id: number){
    return this.http.delete<ImageDTO>(ApisRoot.dotnetBaseUrl + 'PictureProfile/DeletePictureProfileById?id=' + id, {
      observe: 'response'
    });
  }
}
