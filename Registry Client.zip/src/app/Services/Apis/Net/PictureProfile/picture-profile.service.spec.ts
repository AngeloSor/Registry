import { TestBed } from '@angular/core/testing';

import { PictureProfileService } from './picture-profile.service';

describe('PictureProfileService', () => {
  let service: PictureProfileService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PictureProfileService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
