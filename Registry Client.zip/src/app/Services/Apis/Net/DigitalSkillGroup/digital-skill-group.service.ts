import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DigitalSkillGroupDTO } from 'src/app/Models/DTOs/Skills/SkillGroup/skillGroup';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DigitalSkillGroupService {

  constructor(
    private http: HttpClient
  ) { }

  CreateDigitalSkillGroup(skillGroup: DigitalSkillGroupDTO){
    console.log("service", skillGroup)
    return this.http.post<DigitalSkillGroupDTO[]>(ApisRoot.dotnetBaseUrl + "DigitalSkillGroup/CreateDigitalSkillGroup?name=" + skillGroup.name,
    skillGroup
    , {
      observe: 'response'
    })
  }

  GetDigitalSkillGroupList(){
    return this.http.get<DigitalSkillGroupDTO[]>(ApisRoot.dotnetBaseUrl + "DigitalSkillGroup/GetDigitalSkillGroupList", {
      observe: 'response'
    })
  }

  UpdateDigitalSkillGroup(skillGroup: DigitalSkillGroupDTO){
    return this.http.put<DigitalSkillGroupDTO[]>(ApisRoot.dotnetBaseUrl + "DigitalSkillGroup/UpdateDigitalSkillGroup",
      skillGroup
    , {
      observe: 'response'
    })
  }

  DeleteDigitalSkillGroup(skillGroup: DigitalSkillGroupDTO){
    return this.http.delete<DigitalSkillGroupDTO[]>(ApisRoot.dotnetBaseUrl + "DigitalSkillGroup/DeleteDigitalSkillGroup?name=" + skillGroup.name, {
      body: skillGroup,    
      observe: 'response'
    })
  }

  




}
