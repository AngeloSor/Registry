import { TestBed } from '@angular/core/testing';

import { DigitalSkillGroupService } from './digital-skill-group.service';

describe('DigitalSkillGroupService', () => {
  let service: DigitalSkillGroupService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DigitalSkillGroupService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
