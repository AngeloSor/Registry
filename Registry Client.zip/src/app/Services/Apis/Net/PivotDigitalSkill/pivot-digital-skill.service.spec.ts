import { TestBed } from '@angular/core/testing';

import { PivotDigitalSKillService } from './pivot-digital-skill.service';

describe('PivotDigitalSKillService', () => {
  let service: PivotDigitalSKillService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PivotDigitalSKillService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
