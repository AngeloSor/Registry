import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PivotDigitalSkill } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PivotDigitalSKillService {

  constructor(
    private http: HttpClient
  ) { }

  CreatePivotDigitalSkill(pivotSkill: PivotDigitalSkill) {
    return this.http.post<PivotDigitalSkill>(ApisRoot.dotnetBaseUrl + "PivotDigitalSkill/CreatePivotDigitalSkill",
      pivotSkill,
      {
        observe: 'response'
      }
    )

  }

  GetPivotDigitalSkill() {
    return this.http.get<PivotDigitalSkill[]>(ApisRoot.dotnetBaseUrl + "PivotDigitalSkill/GetAllPivotDigitalSkills",
      {
        observe: 'response'
      }
    )

  }
  PutPivotDigitalSkill(pivotSkill: PivotDigitalSkill) {
    return this.http.put<PivotDigitalSkill>(ApisRoot.dotnetBaseUrl + "PivotDigitalSkill/PutPivotDigitalSkill",
      pivotSkill,
      {
        observe: 'response'
      }
    )

  }
  DeletePivotDigitalSkill(id: number) {
    return this.http.delete(ApisRoot.dotnetBaseUrl + "PivotDigitalSkill/DeletePivotDigitalSkill?id=" +id,
      {
        observe: 'response'
      }
    )
  }
}
