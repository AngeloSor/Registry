import { CvFile, EducationAndTrainingExperience, PivotDigitalSkill, WorkExperience } from './../../../Models/DTOs/RegistryCv/registryCv-dto';
import { RegistryCVDTO } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { UserDTO } from './../../../Models/DTOs/User/user-dto';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RegistryService } from './Registry/registry.service';
import { RegistryCVService } from './CVRegistry/cvRegistry.service';
import { DigitalSKillService } from './DigitalSkill/digital-skill.service';
import { DigitalSkill, DigitalSkillGroupDTO } from 'src/app/Models/DTOs/Skills/SkillGroup/skillGroup';
import { DigitalSkillGroupService } from './DigitalSkillGroup/digital-skill-group.service';
import { PivotDigitalSKillService } from './PivotDigitalSkill/pivot-digital-skill.service';
import { WorkExperienceService } from './WorkExperience/work-experience.service';
import { EducationServiceService } from './EducationAndTrainingExprence/education-service.service';
import { EmailSenderService } from './EmailSender/email-sender.service';
import { CvFileService } from './CVFile/cv-file.service';
import { MeetingService } from './Meeting/meeting.service';
import { PictureProfileService } from './PictureProfile/picture-profile.service';
import { ImageDTO } from 'src/app/Models/DTOs/User/image-dto';
import { InterviewFeedbackDTO } from 'src/app/Models/DTOs/InterviewFeedback/interviewFeedbackDTO';
import { CodinGameInvitation } from 'src/app/Models/DTOs/CodinGame/CodinGame';
import { CodingGameService } from '../../General/CodingGame/codin-game.service';
import { DictionaryService } from '../../General/Dictionary/dictionary.service';
import { ConditionService } from './Condition/condition.service';
import { FeedbackService } from './Feedback/feedback.service';


@Injectable({
  providedIn: 'root',
})
export class DotNetService {
  constructor(
    private _registryCvService: RegistryCVService,
    private _registryService: RegistryService,
    private _digitalSkillService: DigitalSKillService,
    private _digitalSkillGroupService: DigitalSkillGroupService,
    private _pivotDigitalSkill: PivotDigitalSKillService,
    private _workExperienceService: WorkExperienceService,
    private _educationAndTrainingExperience: EducationServiceService,
    private _cvFileService: CvFileService,
    private _emailSenderService: EmailSenderService,
    private _pictureProfileService: PictureProfileService,
    private _meetingService: MeetingService,
    private _codingGameService: CodingGameService,
    private _dictionaryService: DictionaryService,
    private _conditionService: ConditionService,
    private _feedbackService: FeedbackService
  ) { }

  DisplayError(error: string){
    this._dictionaryService.DisplayError(error);
  }

  GetAllRegistriesPage(isDeleted: boolean) {
    return this._registryService.GetAllRegistriesPage(isDeleted);
  }

  GetAllTechnicianUsersPage() {
    return this._registryService.GetAllTechnicianUsersPage();
  }

  //User
  GetAllUsers(isDeleted: boolean) {
    return this._registryService.GetAllUsers(isDeleted);
  }

  GetUserByEmail(email: string) {
    return this._registryService.GetUserByEmail(email);
  }

  GetRegistryById(id: number) {
    return this._registryService.GetRegistryById(id);
  }

  CreateUser(message: any) {
    return this._registryService.CreateUser(message);
  }

  DeleteUser(id: number) {
    return this._registryService.DeleteUser(id);
  }

  DisableUser(id: number) {
    return this._registryService.DisableUser(id);
  }


  UpdateUser(user: UserDTO) {
    return this._registryService.UpdateUser(user);
  }

  RestoreUser(id: number){
    return this._registryService.RestoreUser(id);
  }

  //Cv registry
  GetCvFile(id: number){
    return this._cvFileService.GetCvFile(id);
  }
  CreateCV(userId: number) {
    return this._registryCvService.CreateCV(userId)
  }
  GetCVRegistryByIdRegistry(id: number) {
    return this._registryCvService.GetCVByIdRegistry(id);
  }

  //Cv file
  CreateCVFile(cvFile: CvFile){
    return this._cvFileService.CreateCVFile(cvFile);
  }

  DeleteCvFile(id: number){
    return this._cvFileService.DeleteCvFile(id);
  }

  //DigitalSkill

  CreateDigitalSkill(digitalSkill: DigitalSkill) {
    return this._digitalSkillService.CreateDigitalSkill(digitalSkill);
  }

  UpdateDigitalSkill(digitalSkill: DigitalSkill) {
    return this._digitalSkillService.UpdateDigitalSkill(digitalSkill);
  }

  DeleteDigitalSkill(digitalSkill: DigitalSkill) {
    return this._digitalSkillService.DeleteDigitalSkill(digitalSkill);
  }

  //DigitalSkillGroup
  CreateDigitalSkillGroup(skillGroup: DigitalSkillGroupDTO){
    return this._digitalSkillGroupService.CreateDigitalSkillGroup(skillGroup)
  }

  GetDigitalSkillGroupList(){
    return this._digitalSkillGroupService.GetDigitalSkillGroupList()
  }

  UpdateDigitalSkillGroup(skillGroup: DigitalSkillGroupDTO){
    return this._digitalSkillGroupService.UpdateDigitalSkillGroup(skillGroup)
  }

  DeleteDigitalSkillGroup(skillGroup: DigitalSkillGroupDTO){
    return this._digitalSkillGroupService.DeleteDigitalSkillGroup(skillGroup)
  }

  // Pivot Skill
  CreatePivotDigitalSkill(pivotSkill: PivotDigitalSkill) {
    return this._pivotDigitalSkill.CreatePivotDigitalSkill(pivotSkill)

  }

  GetPivotDigitalSkill() {
    return this._pivotDigitalSkill.GetPivotDigitalSkill();
  }

  PutPivotDigitalSkill(pivotSkill: PivotDigitalSkill) {
    return this._pivotDigitalSkill.PutPivotDigitalSkill(pivotSkill)
  }

  DeletePivotDigitalSkill(id: number) {
    return this._pivotDigitalSkill.DeletePivotDigitalSkill(id)
  }

  //Work Experience
  CreateWorkExperience(workExperience: WorkExperience){
    return this._workExperienceService.CreateWorkExperience(workExperience);
  }

  GetWorkExperience(id: number){
    return this._workExperienceService.GetWorkExperience(id);
  }

  PutWorkExperience(workExperience: WorkExperience){
    return this._workExperienceService.PutWorkExperience(workExperience);
  }

  DeleteWorkExperience(id: number){
    return this._workExperienceService.DeleteWorkExperience(id);
  }

  //Education and training Experience
  CreateEducationAndTrainingExperience(education: EducationAndTrainingExperience){
    return this._educationAndTrainingExperience.CreateEducationAndTrainingExperience(education)
  }

  GetEducationAndTrainingExperienceById(id: number){
    return this._educationAndTrainingExperience.GetEducationAndTrainingExperienceById(id)
  }

  PutEducationAndTrainingExperience(education: EducationAndTrainingExperience){
    return this._educationAndTrainingExperience.PutEducationAndTrainingExperience(education)

  }

  DeleteEducationAndTrainingExperience(id: number){
    return this._educationAndTrainingExperience.DeleteEducationAndTrainingExperience(id)
  }

  //Email Sender
  SendEmail(){
    return this._emailSenderService.SendEmail()
  }

  InterviewFeedBack(interviewFeedback: InterviewFeedbackDTO){
    return this._emailSenderService.InterviewFeedBack(interviewFeedback);
  }

  //Meeting
  GetMeetingsByInterviewer(){
    return this._meetingService.GetMeetingsByInterviewer();
  }

  CreateMeeting(meeting){
    return this._meetingService.CreateMeeting(meeting);
  }

  GetAllInterviewUsers(){
    return this._registryService.GetAllInterviewUsers()
  }

  GetAllTechnicianUsers(){
    return this._registryService.GetAllTechnicianUsers()
  }

  //Picture Profile
  CreatePictureProfile(image: ImageDTO){
    return this._pictureProfileService.CreatePictureProfile(image)
  }

  GetPictureProfileById(id: number){
    return this._pictureProfileService.GetPictureProfileById(id)
  }

  GetAllPicturesProfile(){
    return this._pictureProfileService.GetAllPicturesProfile()
  }

  PutPictureProfile(image: ImageDTO) {
    return this._pictureProfileService.PutPictureProfile(image)
  }

  DeletePictureProfileById(id: number){
    return this._pictureProfileService.DeletePictureProfileById(id)
  }

  UpdateMeeting(meeting){
    return this._meetingService.UpdateMeeting(meeting);
  }

  DeleteMeeting(id: number){
    return this._meetingService.DeleteMeeting(id);
  }

  ChangeStatusMeeting(id: number){
    return this._meetingService.ChangeStatusMeeting(id);
  }

  //CodinGame
  CreateInvitation(createCodinGameInvitation: CodinGameInvitation, idCampaign: number){
    return this._codingGameService.CreateInvitation(createCodinGameInvitation, idCampaign);
  }

  DeleteInvitation(idInvitation: number){
    return this._codingGameService.DeleteInvitation(idInvitation);
  }

  GetStatusTest(userId: number){
    return this._codingGameService.GetStatusTest(userId);
  }

  GetStatusTestPdf(userId: number){
    return this._codingGameService.GetStatusTestPdf(userId);
  }

  //Condition
  GetAllConditions(){
    return this._conditionService.GetAllConditions();
  }

  //Feedback
  getFeedbackByTechnicianId(id: number){
    return this._feedbackService.getFeedbackByTechnicianId(id)
  }

}
