import { TestBed } from '@angular/core/testing';

import { RegistryCVService } from './cvRegistryservice';

describe('CVFileService', () => {
  let service: RegistryCVService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RegistryCVService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
