import { CvFile, RegistryCVDTO } from 'src/app/Models/DTOs/RegistryCv/registryCv-dto';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RegistryCVService {

  constructor(
    private http: HttpClient
  ) { }

  CreateCV(userId: number){
    return this.http.post<{id: number, registryId: number}>(ApisRoot.dotnetBaseUrl + 'CVRegistry/CreateCVRegistry',{
      registryId: userId
    },{
      observe: 'response'
    })
  }

  GetCVByIdRegistry(id: number){
    return this.http.get<RegistryCVDTO>(ApisRoot.dotnetBaseUrl + 'CVRegistry/GetCVRegistryByRegistryId?id=' + id, {observe: 'response'});
  }





  CreateCVFile(cvFile: CvFile){
    return this.http.post<CvFile>(ApisRoot.dotnetBaseUrl + 'CVFIle/CreateCVFile', cvFile, {
      observe: 'response'
    })
  }
}
