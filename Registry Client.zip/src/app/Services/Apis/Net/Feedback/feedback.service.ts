import { HttpClient, HttpInterceptor } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { InterviewFeedbackDTO } from 'src/app/Models/DTOs/InterviewFeedback/interviewFeedbackDTO';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  constructor(
    private readonly http: HttpClient
  ) { }

  getFeedbackByTechnicianId(id: number):Observable<InterviewFeedbackDTO[]>{
    return this.http.get<InterviewFeedbackDTO[]>(ApisRoot.dotnetBaseUrl + 'Feedback/GetByTechnicianId?id=' + id);
  }

  getFeedbackById(id: number):Observable<InterviewFeedbackDTO>{
    return this.http.get<InterviewFeedbackDTO>(ApisRoot.dotnetBaseUrl + 'Feedback/GetById?id=' + id);
  }

  getAllFeedback(): Observable<InterviewFeedbackDTO[]>{
    return this.http.get<InterviewFeedbackDTO[]>(ApisRoot.dotnetBaseUrl + 'Feedback/GetAllInterview');
  }

  createFeedback(feedback: InterviewFeedbackDTO): Observable<InterviewFeedbackDTO> {
    return this.http.post<InterviewFeedbackDTO>(ApisRoot.dotnetBaseUrl + 'Feedback/CreateFeedback', feedback);
  }
}
