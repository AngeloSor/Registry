import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MeetingDTO } from 'src/app/Models/DTOs/Meeting/Meeting-dto';
import { ApisRoot } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MeetingService {

  constructor(
    private http: HttpClient
  ) { }

  GetMeetingsByInterviewer(){
    return this.http.get<MeetingDTO[]>(ApisRoot.dotnetBaseUrl + 'Meeting/GetMeetingsByInterviewer', {observe: 'response'});
  }

  CreateMeeting(event){
    return this.http.post<MeetingDTO>(ApisRoot.dotnetBaseUrl + 'Meeting/CreateMeeting', event, {observe: 'response'});
  }

  UpdateMeeting(meeting){
    return this.http.put<MeetingDTO>(ApisRoot.dotnetBaseUrl + 'Meeting/PutMeeting', meeting, {observe: 'response'})
  }

  DeleteMeeting(id: number){
    return this.http.delete(ApisRoot.dotnetBaseUrl + 'Meeting/DeleteMeetingById?id=' + id, {observe: 'response'})
  }

  ChangeStatusMeeting(id: number){
    return this.http.put(ApisRoot.dotnetBaseUrl + 'Meeting/ChangeStatusMeeting?id=' + id, {observe: 'response'})
  }

}
