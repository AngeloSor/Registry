import { CookieService } from 'ngx-cookie-service';
import { HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";

import { catchError, tap } from "rxjs/operators";
import { Router } from '@angular/router';
import { RoleGuard } from '../../Guards/Role/role.guard';
import { ApisRoot } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ApiInterceptor implements HttpInterceptor {

  constructor(
    private _roleGuard: RoleGuard,
    private _router: Router,
    private cookieService: CookieService
  ){}
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    let modified_req = req.clone({
      headers: req.headers.set(
        "Authorization", "Bearer " + this.cookieService.get('token')
      ).set(
        'Content-type', 'application/x-www-form-urlencoded'
      )
    });

    if (req.url.startsWith(ApisRoot.keycloakBaseUrl + 'admin/realms') ||
        req.url.startsWith(ApisRoot.dotnetBaseUrl) ||
        req.url.endsWith('groups')
    ) {
      modified_req = req.clone({
        headers: req.headers.set
          (
            'Content-type', 'application/json'
          ).set(
            "Authorization", "Bearer " + this.cookieService.get('token')
          )
      })
    }

    if(req.url.startsWith(ApisRoot.keycloakBaseUrl + 'realms/' + ApisRoot.realm +'/protocol/openid-connect/token')){
      modified_req = req.clone({
        headers: req.headers.set(
          'Content-type', 'application/x-www-form-urlencoded'
        )
      });
    }

    return next.handle(modified_req).pipe(
      tap(
        evt => {
          if (evt instanceof HttpResponse) {
            console.log(`evt status: ${evt.status} evt url: ${evt.url}`)
            if(!this._roleGuard.CheckRole && modified_req.url.startsWith('/admin')){
              console.log('evt.status nell if', evt.status)
              this._router.navigate(['notFound', evt.status]);
            }
          }
        }
      )
    );
  }
}
