import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, CanDeactivate, CanLoad, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { map, Observable } from 'rxjs';
import { AuthenticationService } from '../../Apis/KeyCloak/Authentication/authentication.service';
import { KeyCLoakService } from '../../Apis/KeyCloak/key-cloak.service';

@Injectable({
  providedIn: 'root'
})

export class AuthGuard implements CanActivate, CanActivateChild, CanDeactivate<unknown>, CanLoad {

  constructor(
    private _keyCloakService: KeyCLoakService,
    private router: Router,
    private cookieService: CookieService,
    private authService: AuthenticationService
  ) { }

  RefreshToken() {
    if (this.cookieService.get('token')) {
      this.authService.isLoggedObservable.next(true);
      return true
    }
    if (this.cookieService.get('refreshToken')) {
      return this._keyCloakService.RefreshDataKeycloak().pipe(
        map(res => {
          if (res.ok) {
            this.authService.isLoggedObservable.next(true);
            return true
          } else {
            this.authService.isLoggedObservable.next(false);
            this._keyCloakService.Logout()
            console.log("logout1")
            this.router.navigate(['/home'])
            return false
          }
        })
      )
    }
    this.authService.isLoggedObservable.next(false);
    this._keyCloakService.Logout()
    console.log("logout2")
    this.router.navigate(['/home'])
    return false

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return this.RefreshToken()
  }

  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return true;
  }

  canDeactivate(
    component: unknown,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return true;
  }

  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return true;
  }
}
