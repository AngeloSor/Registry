export interface RegistryCVDTO {
  id: number,
  registryId: number,
  cvFiles: CvFile[],
  educationAndTrainingExperiences: EducationAndTrainingExperience[],
  workExperiences: WorkExperience[],
  personalSkills?: PersonalSkill[],
  pivotDigitalSkills: PivotDigitalSkill[]
}

export interface WorkExperience {
  id: number,
  workingPosition: string,
  agency: string,
  location: string,
  startDate: Date,
  endDate: Date,
  cvRegistryId: number
}

export interface EducationAndTrainingExperience {
  id: number,
  qualificationAwarded: string,
  organisationOrSchool: string,
  address?: string,
  votesObtained?: number,
  cvRegistryId: number
}

export interface CvFile {
  id: number,
  file: string,
  cvRegistryId: number,
  name: string
}

export interface PersonalSkills{
  id: number,
  motherTongues: PersonalSkill[],
  otherLanguages: PersonalSkill[],
  organizationalAndManagementSkills: PersonalSkill[],
  professionalSkills: PersonalSkill[],
  softSkills: PersonalSkill[],
  driveLicenses: PersonalSkill[],
  cvRegistryId: number
}

export interface PersonalSkill{
  id: number,
  cvRegistryId: number,
  properties: string,
  value: string
}

export interface PivotDigitalSkill{
  id: number,
  name: string,
  startDate: Date,
  endDate: Date,
  cvRegistryId: number
  category: string,
  developRole: number
}

