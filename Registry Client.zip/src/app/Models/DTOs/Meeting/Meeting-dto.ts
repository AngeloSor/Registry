export interface MeetingDTO {
  id?: number,
  interviewerId: number,
  nameInterviewer: string,
  nameUser: string,
  userId: number,
  date: Date,
  time: Date
  isDeleted: boolean
}
