import { ImageDTO } from "./image-dto";

export interface UserDTO {
  pictureProfile?: ImageDTO,
  id?: number,
  idKeycloak?: string,
  email: string,
  name: string,
  surname: string,
  birthDate: Date,
  fiscalCode: string,
  city: string,
  province: string,
  street: string,
  streetNumber: string,
  zipCode: number,
  gender: number,
  cvPresence?: number,
  technician?: boolean,
  businessManager: string,
  conditionId?: number,
  password?: string
  isDeleted?: boolean
  isCGExecuted?: string
  condition?: string
}


export const Genders = [{ value: 0, label: "Uomo" }, { value: 1, label: "Donna" }, { value: 2, label: "Altro" }]

export const Roles = ["administrator", "user"];
