export interface ImageDTO {
    id: number,
    picture: string,
    registryId: number
}