export interface ConditionDTO {
    id: number,
    name: string
}