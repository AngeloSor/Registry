export interface InterviewFeedbackDTO {
  nameUser: string;
  mailMessage: MailMessageDTO;
  isPassed: boolean;
  esperienza: string;
  ruolo: string;
  conclusioni: string;
  designEvaluation: string;
  codeEvaluation: string;
  architectureEvaluation: string;
  dateFeedback: Date,
  feedbackUserId: number,
  feedbackInterviewerId: number,
  id: number;
}

export interface DigitalSkillFeedback {
  name: string;
  category: string;
  developRole: string;
  evaluation: string;
}

export interface Contact {
  name: string;
  address: string;
}

export interface MailMessageDTO {
  from: Contact;
  to: string[];
  cc: string[];
  subject: string;
  body: string;
}

export const profilo = [
  { value: 0, label: 'Frontend' },
  { value: 1, label: 'Backend' },
  { value: 2, label: 'Fullstack' },
];

export const valutazione = [
  { value: 0, label: 'Eccellente' },
  { value: 1, label: 'Ottima' },
  { value: 2, label: 'Buona' },
  { value: 3, label: 'Insufficiente' },
];

export const esperienza = [
  { value: 0, label: 'Junior' },
  { value: 1, label: 'Middle' },
  { value: 2, label: 'Senior' },
  { value: 3, label: 'Architect' },
  { value: 4, label: 'Stagista' },
  { value: 5, label: 'Apprendista' },
];

export const isPassed = [
  { value: 0, label: 'Negativo' },
  { value: 1, label: 'Positivo' },
];
