export interface DigitalSkillGroupDTO {
  id: number,
  name: string,
  digitalSkills: DigitalSkill[]
}

export interface DigitalSkill {
  id: number,
  digitalSkillGroupName: string,
  name: string,
  developRole: number
}

export interface Skill {
  name: string,
  category: string
}

export interface SkillAutocomplete {
  category: string,
  skillsName: string[];
}

export const DevelopeRole = [{ value: 0, label: "Front-End" }, { value: 1, label: "Back-End" }]

