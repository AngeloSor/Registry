export interface CodinGameCampaigns {
  id: number,
  name: string,
  languages: [],
  archived: boolean,
  pinned: boolean
  campaigncat: string,
}

export interface CodinGameInvitation {
  candidate_email: string,
  candidate_name: string,
  recruiter_email: string,
  tags: string,
  send_invitation_email: boolean,
  send_notification_email_on_bounce: boolean
}

export interface Invitation {
  id: number,
  url: string
}

export interface Result {
  status: string,
  url: string,
  report?: {
    duration: number,
    points: number,
    score: number,
    technologies: [{
      name: [{
        name: string,
        points: number,
        score: number,
        skills: [{
          name: {
            name: string
            points: number,
            score: number,
            total_points: number
          }
        }],
        total_points: number,
        comparative_score: number
      }]
    }],
    total_duration: number,
    total_points: number,
    comparative_score: number
  },
  id: number,
  id_test: number,
  campaign_id: number,
  candidate_name: string,
  candidate_email: string,
  tags: string[],
  send_time: number,
  start_time?: number,
  end_time?: number,
  test_url: string,
  candidate_language?: string
}


