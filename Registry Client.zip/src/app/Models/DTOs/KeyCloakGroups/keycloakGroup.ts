export interface KeyCloakGroupDTO     {
  id: string,
  name: string,
  path: string,
  subGroups: []
}
