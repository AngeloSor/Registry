export interface CodingameReport {
  id?: number,
  name: string
  file: string
}
