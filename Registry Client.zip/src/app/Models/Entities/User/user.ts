export interface User{
    
}