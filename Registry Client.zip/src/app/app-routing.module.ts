import { UserDetailComponent } from './Components/Roles/User/user-detail/user-detail.component';
import { RoleGuard } from './Services/Guards/Role/role.guard';
import { AuthGuard } from 'src/app/Services/Guards/Auth/auth.guard';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './Components/General/login/login.component';
import { AdminDashboardComponent } from './Components/Roles/Admin/admin-dashboard/admin-dashboard.component';
import { HomepageComponent } from './Components/General/homepage/homepage.component';
import { MeetingCreateComponent } from './Components/Roles/Admin/meeting-create/meeting-create.component';
import { NotFoundComponent } from './Components/General/not-found/not-found.component';
import { ForgotPwComponent } from './Components/General/forgot-pw/forgot-pw.component';
import { FeedbackComponent } from './Components/Roles/Technician/feedback/feedback.component';
import { SingleFeedbackComponent } from './Components/Roles/Technician/singleFeedback/singleFeedback.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'admin/dashboard', component: AdminDashboardComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'user/info/:id', component: UserDetailComponent, canActivate: [AuthGuard] },
  { path: 'meet-create', component: MeetingCreateComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'forgot-pw', component: ForgotPwComponent },
  { path: 'feedback/:technicianId/:userId', component: FeedbackComponent },
  { path: 'yourFeedback/:id', component: SingleFeedbackComponent },
  { path: 'notFound/:id', component: NotFoundComponent},
  { path: '**', redirectTo: 'notFound/404' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard, RoleGuard]
})
export class AppRoutingModule { }
